(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/2e916_@heroui_dom-animation_dist_index_mjs_91fd73a4._.js"
],
    source: "dynamic"
});
