(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/2e916_@heroui_toast_dist_src-UW24ZMRV_mjs_e20e0467._.js"
],
    source: "dynamic"
});
