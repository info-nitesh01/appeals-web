(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/next-admin-dashboard/node_modules/@heroui/dom-animation/dist/index.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/2e916_dd716951._.js",
  "static/chunks/2e916_@heroui_dom-animation_dist_index_mjs_f439eb75._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/next-admin-dashboard/node_modules/@heroui/dom-animation/dist/index.mjs [app-client] (ecmascript)");
    });
});
}),
]);