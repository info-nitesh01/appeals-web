(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/ar-AE.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$b3427c06585c22a0$exports
]);
var $b3427c06585c22a0$exports = {};
$b3427c06585c22a0$exports = {
    "rangeOverflow": (args)=>"يجب أن تكون القيمة ".concat(args.maxValue, " أو قبل ذلك."),
    "rangeReversed": "تاريخ البدء يجب أن يكون قبل تاريخ الانتهاء.",
    "rangeUnderflow": (args)=>"يجب أن تكون القيمة ".concat(args.minValue, " أو بعد ذلك."),
    "unavailableDate": "البيانات المحددة غير متاحة."
};
;
 //# sourceMappingURL=ar-AE.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/bg-BG.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$d282528f459122b9$exports
]);
var $d282528f459122b9$exports = {};
$d282528f459122b9$exports = {
    "rangeOverflow": (args)=>"Стойността трябва да е ".concat(args.maxValue, " или по-ранна."),
    "rangeReversed": "Началната дата трябва да е преди крайната.",
    "rangeUnderflow": (args)=>"Стойността трябва да е ".concat(args.minValue, " или по-късно."),
    "unavailableDate": "Избраната дата не е налична."
};
;
 //# sourceMappingURL=bg-BG.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/cs-CZ.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$2d5eecd634a9ca45$exports
]);
var $2d5eecd634a9ca45$exports = {};
$2d5eecd634a9ca45$exports = {
    "rangeOverflow": (args)=>"Hodnota musí být ".concat(args.maxValue, " nebo dřívější."),
    "rangeReversed": "Datum zahájení musí předcházet datu ukončení.",
    "rangeUnderflow": (args)=>"Hodnota musí být ".concat(args.minValue, " nebo pozdější."),
    "unavailableDate": "Vybrané datum není k dispozici."
};
;
 //# sourceMappingURL=cs-CZ.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/da-DK.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$c8e2288226c24a67$exports
]);
var $c8e2288226c24a67$exports = {};
$c8e2288226c24a67$exports = {
    "rangeOverflow": (args)=>"Værdien skal være ".concat(args.maxValue, " eller tidligere."),
    "rangeReversed": "Startdatoen skal være før slutdatoen.",
    "rangeUnderflow": (args)=>"Værdien skal være ".concat(args.minValue, " eller nyere."),
    "unavailableDate": "Den valgte dato er ikke tilgængelig."
};
;
 //# sourceMappingURL=da-DK.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/de-DE.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$6f5745e389c346d7$exports
]);
var $6f5745e389c346d7$exports = {};
$6f5745e389c346d7$exports = {
    "rangeOverflow": (args)=>"Der Wert muss ".concat(args.maxValue, " oder früher sein."),
    "rangeReversed": "Das Startdatum muss vor dem Enddatum liegen.",
    "rangeUnderflow": (args)=>"Der Wert muss ".concat(args.minValue, " oder später sein."),
    "unavailableDate": "Das ausgewählte Datum ist nicht verfügbar."
};
;
 //# sourceMappingURL=de-DE.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/el-GR.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$8c882ccf4300d1da$exports
]);
var $8c882ccf4300d1da$exports = {};
$8c882ccf4300d1da$exports = {
    "rangeOverflow": (args)=>"Η τιμή πρέπει να είναι ".concat(args.maxValue, " ή παλαιότερη."),
    "rangeReversed": "Η ημερομηνία έναρξης πρέπει να είναι πριν από την ημερομηνία λήξης.",
    "rangeUnderflow": (args)=>"Η τιμή πρέπει να είναι ".concat(args.minValue, " ή μεταγενέστερη."),
    "unavailableDate": "Η επιλεγμένη ημερομηνία δεν είναι διαθέσιμη."
};
;
 //# sourceMappingURL=el-GR.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/en-US.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$22195056771860be$exports
]);
var $22195056771860be$exports = {};
$22195056771860be$exports = {
    "rangeUnderflow": (args)=>"Value must be ".concat(args.minValue, " or later."),
    "rangeOverflow": (args)=>"Value must be ".concat(args.maxValue, " or earlier."),
    "rangeReversed": "Start date must be before end date.",
    "unavailableDate": "Selected date unavailable."
};
;
 //# sourceMappingURL=en-US.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/es-ES.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$cedfa43b4e2a5906$exports
]);
var $cedfa43b4e2a5906$exports = {};
$cedfa43b4e2a5906$exports = {
    "rangeOverflow": (args)=>"El valor debe ser ".concat(args.maxValue, " o anterior."),
    "rangeReversed": "La fecha de inicio debe ser anterior a la fecha de finalización.",
    "rangeUnderflow": (args)=>"El valor debe ser ".concat(args.minValue, " o posterior."),
    "unavailableDate": "Fecha seleccionada no disponible."
};
;
 //# sourceMappingURL=es-ES.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/et-EE.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$eeeaa8daee3601c7$exports
]);
var $eeeaa8daee3601c7$exports = {};
$eeeaa8daee3601c7$exports = {
    "rangeOverflow": (args)=>"Väärtus peab olema ".concat(args.maxValue, " või varasem."),
    "rangeReversed": "Alguskuupäev peab olema enne lõppkuupäeva.",
    "rangeUnderflow": (args)=>"Väärtus peab olema ".concat(args.minValue, " või hilisem."),
    "unavailableDate": "Valitud kuupäev pole saadaval."
};
;
 //# sourceMappingURL=et-EE.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/fi-FI.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$35e0614a49b3bb40$exports
]);
var $35e0614a49b3bb40$exports = {};
$35e0614a49b3bb40$exports = {
    "rangeOverflow": (args)=>"Arvon on oltava ".concat(args.maxValue, " tai sitä aikaisempi."),
    "rangeReversed": "Aloituspäivän on oltava ennen lopetuspäivää.",
    "rangeUnderflow": (args)=>"Arvon on oltava ".concat(args.minValue, " tai sitä myöhäisempi."),
    "unavailableDate": "Valittu päivämäärä ei ole käytettävissä."
};
;
 //# sourceMappingURL=fi-FI.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/fr-FR.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$929bc63f7705a78f$exports
]);
var $929bc63f7705a78f$exports = {};
$929bc63f7705a78f$exports = {
    "rangeOverflow": (args)=>"La valeur doit être ".concat(args.maxValue, " ou antérieure."),
    "rangeReversed": "La date de début doit être antérieure à la date de fin.",
    "rangeUnderflow": (args)=>"La valeur doit être ".concat(args.minValue, " ou ultérieure."),
    "unavailableDate": "La date sélectionnée n’est pas disponible."
};
;
 //# sourceMappingURL=fr-FR.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/he-IL.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$9a28d073b034d183$exports
]);
var $9a28d073b034d183$exports = {};
$9a28d073b034d183$exports = {
    "rangeOverflow": (args)=>"הערך חייב להיות ".concat(args.maxValue, " או מוקדם יותר."),
    "rangeReversed": "תאריך ההתחלה חייב להיות לפני תאריך הסיום.",
    "rangeUnderflow": (args)=>"הערך חייב להיות ".concat(args.minValue, " או מאוחר יותר."),
    "unavailableDate": "התאריך הנבחר אינו זמין."
};
;
 //# sourceMappingURL=he-IL.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/hr-HR.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$7743e79780ebcca3$exports
]);
var $7743e79780ebcca3$exports = {};
$7743e79780ebcca3$exports = {
    "rangeOverflow": (args)=>"Vrijednost mora biti ".concat(args.maxValue, " ili ranije."),
    "rangeReversed": "Datum početka mora biti prije datuma završetka.",
    "rangeUnderflow": (args)=>"Vrijednost mora biti ".concat(args.minValue, " ili kasnije."),
    "unavailableDate": "Odabrani datum nije dostupan."
};
;
 //# sourceMappingURL=hr-HR.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/hu-HU.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$3351817a04898858$exports
]);
var $3351817a04898858$exports = {};
$3351817a04898858$exports = {
    "rangeOverflow": (args)=>"Az értéknek ".concat(args.maxValue, " vagy korábbinak kell lennie."),
    "rangeReversed": "A kezdő dátumnak a befejező dátumnál korábbinak kell lennie.",
    "rangeUnderflow": (args)=>"Az értéknek ".concat(args.minValue, " vagy későbbinek kell lennie."),
    "unavailableDate": "A kiválasztott dátum nem érhető el."
};
;
 //# sourceMappingURL=hu-HU.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/it-IT.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$4120bdb1d03484db$exports
]);
var $4120bdb1d03484db$exports = {};
$4120bdb1d03484db$exports = {
    "rangeOverflow": (args)=>"Il valore deve essere ".concat(args.maxValue, " o precedente."),
    "rangeReversed": "La data di inizio deve essere antecedente alla data di fine.",
    "rangeUnderflow": (args)=>"Il valore deve essere ".concat(args.minValue, " o successivo."),
    "unavailableDate": "Data selezionata non disponibile."
};
;
 //# sourceMappingURL=it-IT.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/ja-JP.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$65e5e1569f34ea4f$exports
]);
var $65e5e1569f34ea4f$exports = {};
$65e5e1569f34ea4f$exports = {
    "rangeOverflow": (args)=>"値は ".concat(args.maxValue, " 以下にする必要があります。"),
    "rangeReversed": "開始日は終了日より前にする必要があります。",
    "rangeUnderflow": (args)=>"値は ".concat(args.minValue, " 以上にする必要があります。"),
    "unavailableDate": "選択した日付は使用できません。"
};
;
 //# sourceMappingURL=ja-JP.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/ko-KR.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$d34552a7550967e7$exports
]);
var $d34552a7550967e7$exports = {};
$d34552a7550967e7$exports = {
    "rangeOverflow": (args)=>"값은 ".concat(args.maxValue, " 이전이어야 합니다."),
    "rangeReversed": "시작일은 종료일 이전이어야 합니다.",
    "rangeUnderflow": (args)=>"값은 ".concat(args.minValue, " 이상이어야 합니다."),
    "unavailableDate": "선택한 날짜를 사용할 수 없습니다."
};
;
 //# sourceMappingURL=ko-KR.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/lt-LT.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$8f855bffe63f6eca$exports
]);
var $8f855bffe63f6eca$exports = {};
$8f855bffe63f6eca$exports = {
    "rangeOverflow": (args)=>"Reikšmė turi būti ".concat(args.maxValue, " arba ankstesnė."),
    "rangeReversed": "Pradžios data turi būti ankstesnė nei pabaigos data.",
    "rangeUnderflow": (args)=>"Reikšmė turi būti ".concat(args.minValue, " arba naujesnė."),
    "unavailableDate": "Pasirinkta data nepasiekiama."
};
;
 //# sourceMappingURL=lt-LT.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/lv-LV.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$ce40f46d09034645$exports
]);
var $ce40f46d09034645$exports = {};
$ce40f46d09034645$exports = {
    "rangeOverflow": (args)=>"Vērtībai ir jābūt ".concat(args.maxValue, " vai agrākai."),
    "rangeReversed": "Sākuma datumam ir jābūt pirms beigu datuma.",
    "rangeUnderflow": (args)=>"Vērtībai ir jābūt ".concat(args.minValue, " vai vēlākai."),
    "unavailableDate": "Atlasītais datums nav pieejams."
};
;
 //# sourceMappingURL=lv-LV.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/nb-NO.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$dd1a9a73340c793e$exports
]);
var $dd1a9a73340c793e$exports = {};
$dd1a9a73340c793e$exports = {
    "rangeOverflow": (args)=>"Verdien må være ".concat(args.maxValue, " eller tidligere."),
    "rangeReversed": "Startdatoen må være før sluttdatoen.",
    "rangeUnderflow": (args)=>"Verdien må være ".concat(args.minValue, " eller senere."),
    "unavailableDate": "Valgt dato utilgjengelig."
};
;
 //# sourceMappingURL=nb-NO.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/nl-NL.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$4ee1fb3f0cbe6f59$exports
]);
var $4ee1fb3f0cbe6f59$exports = {};
$4ee1fb3f0cbe6f59$exports = {
    "rangeOverflow": (args)=>"Waarde moet ".concat(args.maxValue, " of eerder zijn."),
    "rangeReversed": "De startdatum moet voor de einddatum liggen.",
    "rangeUnderflow": (args)=>"Waarde moet ".concat(args.minValue, " of later zijn."),
    "unavailableDate": "Geselecteerde datum niet beschikbaar."
};
;
 //# sourceMappingURL=nl-NL.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/pl-PL.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$c85829aebb0bc94b$exports
]);
var $c85829aebb0bc94b$exports = {};
$c85829aebb0bc94b$exports = {
    "rangeOverflow": (args)=>"Wartość musi mieć wartość ".concat(args.maxValue, " lub wcześniejszą."),
    "rangeReversed": "Data rozpoczęcia musi być wcześniejsza niż data zakończenia.",
    "rangeUnderflow": (args)=>"Wartość musi mieć wartość ".concat(args.minValue, " lub późniejszą."),
    "unavailableDate": "Wybrana data jest niedostępna."
};
;
 //# sourceMappingURL=pl-PL.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/pt-BR.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$27f5cd2291ca8a02$exports
]);
var $27f5cd2291ca8a02$exports = {};
$27f5cd2291ca8a02$exports = {
    "rangeOverflow": (args)=>"O valor deve ser ".concat(args.maxValue, " ou anterior."),
    "rangeReversed": "A data inicial deve ser anterior à data final.",
    "rangeUnderflow": (args)=>"O valor deve ser ".concat(args.minValue, " ou posterior."),
    "unavailableDate": "Data selecionada indisponível."
};
;
 //# sourceMappingURL=pt-BR.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/pt-PT.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$e046fdccd69bea8e$exports
]);
var $e046fdccd69bea8e$exports = {};
$e046fdccd69bea8e$exports = {
    "rangeOverflow": (args)=>"O valor tem de ser ".concat(args.maxValue, " ou anterior."),
    "rangeReversed": "A data de início deve ser anterior à data de fim.",
    "rangeUnderflow": (args)=>"O valor tem de ser ".concat(args.minValue, " ou posterior."),
    "unavailableDate": "Data selecionada indisponível."
};
;
 //# sourceMappingURL=pt-PT.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/ro-RO.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$fa5f88e804986547$exports
]);
var $fa5f88e804986547$exports = {};
$fa5f88e804986547$exports = {
    "rangeOverflow": (args)=>"Valoarea trebuie să fie ".concat(args.maxValue, " sau anterioară."),
    "rangeReversed": "Data de început trebuie să fie anterioară datei de sfârșit.",
    "rangeUnderflow": (args)=>"Valoarea trebuie să fie ".concat(args.minValue, " sau ulterioară."),
    "unavailableDate": "Data selectată nu este disponibilă."
};
;
 //# sourceMappingURL=ro-RO.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/ru-RU.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$28e4714602d1b568$exports
]);
var $28e4714602d1b568$exports = {};
$28e4714602d1b568$exports = {
    "rangeOverflow": (args)=>"Значение должно быть не позже ".concat(args.maxValue, "."),
    "rangeReversed": "Дата начала должна предшествовать дате окончания.",
    "rangeUnderflow": (args)=>"Значение должно быть не раньше ".concat(args.minValue, "."),
    "unavailableDate": "Выбранная дата недоступна."
};
;
 //# sourceMappingURL=ru-RU.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/sk-SK.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$4e3bc8cf783ad569$exports
]);
var $4e3bc8cf783ad569$exports = {};
$4e3bc8cf783ad569$exports = {
    "rangeOverflow": (args)=>"Hodnota musí byť ".concat(args.maxValue, " alebo skoršia."),
    "rangeReversed": "Dátum začiatku musí byť skorší ako dátum konca.",
    "rangeUnderflow": (args)=>"Hodnota musí byť ".concat(args.minValue, " alebo neskoršia."),
    "unavailableDate": "Vybratý dátum je nedostupný."
};
;
 //# sourceMappingURL=sk-SK.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/sl-SI.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$bee07513333bdc15$exports
]);
var $bee07513333bdc15$exports = {};
$bee07513333bdc15$exports = {
    "rangeOverflow": (args)=>"Vrednost mora biti ".concat(args.maxValue, " ali starejša."),
    "rangeReversed": "Začetni datum mora biti pred končnim datumom.",
    "rangeUnderflow": (args)=>"Vrednost mora biti ".concat(args.minValue, " ali novejša."),
    "unavailableDate": "Izbrani datum ni na voljo."
};
;
 //# sourceMappingURL=sl-SI.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/sr-SP.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$7ed9c6fad16a15ec$exports
]);
var $7ed9c6fad16a15ec$exports = {};
$7ed9c6fad16a15ec$exports = {
    "rangeOverflow": (args)=>"Vrednost mora da bude ".concat(args.maxValue, " ili starija."),
    "rangeReversed": "Datum početka mora biti pre datuma završetka.",
    "rangeUnderflow": (args)=>"Vrednost mora da bude ".concat(args.minValue, " ili novija."),
    "unavailableDate": "Izabrani datum nije dostupan."
};
;
 //# sourceMappingURL=sr-SP.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/sv-SE.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$8bef6d5a236de86c$exports
]);
var $8bef6d5a236de86c$exports = {};
$8bef6d5a236de86c$exports = {
    "rangeOverflow": (args)=>"Värdet måste vara ".concat(args.maxValue, " eller tidigare."),
    "rangeReversed": "Startdatumet måste vara före slutdatumet.",
    "rangeUnderflow": (args)=>"Värdet måste vara ".concat(args.minValue, " eller senare."),
    "unavailableDate": "Det valda datumet är inte tillgängligt."
};
;
 //# sourceMappingURL=sv-SE.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/tr-TR.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$098b9a2d2340cfc5$exports
]);
var $098b9a2d2340cfc5$exports = {};
$098b9a2d2340cfc5$exports = {
    "rangeOverflow": (args)=>"Değer, ".concat(args.maxValue, " veya öncesi olmalıdır."),
    "rangeReversed": "Başlangıç tarihi bitiş tarihinden önce olmalıdır.",
    "rangeUnderflow": (args)=>"Değer, ".concat(args.minValue, " veya sonrası olmalıdır."),
    "unavailableDate": "Seçilen tarih kullanılamıyor."
};
;
 //# sourceMappingURL=tr-TR.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/uk-UA.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$54a862ea7fad7419$exports
]);
var $54a862ea7fad7419$exports = {};
$54a862ea7fad7419$exports = {
    "rangeOverflow": (args)=>"Значення має бути не пізніше ".concat(args.maxValue, "."),
    "rangeReversed": "Дата початку має передувати даті завершення.",
    "rangeUnderflow": (args)=>"Значення має бути не раніше ".concat(args.minValue, "."),
    "unavailableDate": "Вибрана дата недоступна."
};
;
 //# sourceMappingURL=uk-UA.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/zh-CN.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$e6cc491d590dfda5$exports
]);
var $e6cc491d590dfda5$exports = {};
$e6cc491d590dfda5$exports = {
    "rangeOverflow": (args)=>"值必须是 ".concat(args.maxValue, " 或更早日期。"),
    "rangeReversed": "开始日期必须早于结束日期。",
    "rangeUnderflow": (args)=>"值必须是 ".concat(args.minValue, " 或更晚日期。"),
    "unavailableDate": "所选日期不可用。"
};
;
 //# sourceMappingURL=zh-CN.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/zh-TW.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$9aebf53181a474bd$exports
]);
var $9aebf53181a474bd$exports = {};
$9aebf53181a474bd$exports = {
    "rangeOverflow": (args)=>"值必須是 ".concat(args.maxValue, " 或更早。"),
    "rangeReversed": "開始日期必須在結束日期之前。",
    "rangeUnderflow": (args)=>"值必須是 ".concat(args.minValue, " 或更晚。"),
    "unavailableDate": "所選日期無法使用。"
};
;
 //# sourceMappingURL=zh-TW.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/intlStrings.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$452ac34de8c2444e$exports
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$ar$2d$AE$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/ar-AE.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$bg$2d$BG$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/bg-BG.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$cs$2d$CZ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/cs-CZ.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$da$2d$DK$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/da-DK.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$de$2d$DE$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/de-DE.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$el$2d$GR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/el-GR.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$en$2d$US$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/en-US.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$es$2d$ES$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/es-ES.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$et$2d$EE$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/et-EE.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$fi$2d$FI$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/fi-FI.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$fr$2d$FR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/fr-FR.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$he$2d$IL$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/he-IL.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$hr$2d$HR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/hr-HR.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$hu$2d$HU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/hu-HU.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$it$2d$IT$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/it-IT.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$ja$2d$JP$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/ja-JP.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$ko$2d$KR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/ko-KR.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$lt$2d$LT$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/lt-LT.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$lv$2d$LV$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/lv-LV.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$nb$2d$NO$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/nb-NO.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$nl$2d$NL$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/nl-NL.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$pl$2d$PL$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/pl-PL.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$pt$2d$BR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/pt-BR.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$pt$2d$PT$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/pt-PT.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$ro$2d$RO$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/ro-RO.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$ru$2d$RU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/ru-RU.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$sk$2d$SK$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/sk-SK.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$sl$2d$SI$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/sl-SI.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$sr$2d$SP$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/sr-SP.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$sv$2d$SE$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/sv-SE.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$tr$2d$TR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/tr-TR.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$uk$2d$UA$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/uk-UA.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$zh$2d$CN$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/zh-CN.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$zh$2d$TW$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/zh-TW.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var $452ac34de8c2444e$exports = {};
$452ac34de8c2444e$exports = {
    "ar-AE": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$ar$2d$AE$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "bg-BG": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$bg$2d$BG$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "cs-CZ": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$cs$2d$CZ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "da-DK": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$da$2d$DK$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "de-DE": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$de$2d$DE$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "el-GR": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$el$2d$GR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "en-US": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$en$2d$US$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "es-ES": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$es$2d$ES$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "et-EE": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$et$2d$EE$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "fi-FI": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$fi$2d$FI$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "fr-FR": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$fr$2d$FR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "he-IL": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$he$2d$IL$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "hr-HR": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$hr$2d$HR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "hu-HU": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$hu$2d$HU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "it-IT": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$it$2d$IT$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "ja-JP": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$ja$2d$JP$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "ko-KR": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$ko$2d$KR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "lt-LT": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$lt$2d$LT$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "lv-LV": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$lv$2d$LV$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "nb-NO": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$nb$2d$NO$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "nl-NL": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$nl$2d$NL$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "pl-PL": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$pl$2d$PL$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "pt-BR": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$pt$2d$BR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "pt-PT": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$pt$2d$PT$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "ro-RO": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$ro$2d$RO$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "ru-RU": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$ru$2d$RU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "sk-SK": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$sk$2d$SK$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "sl-SI": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$sl$2d$SI$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "sr-SP": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$sr$2d$SP$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "sv-SE": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$sv$2d$SE$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "tr-TR": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$tr$2d$TR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "uk-UA": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$uk$2d$UA$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "zh-CN": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$zh$2d$CN$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "zh-TW": __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$zh$2d$TW$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
};
;
 //# sourceMappingURL=intlStrings.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/utils.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "convertValue",
    ()=>$35a22f14a1f04b11$export$61a490a80c552550,
    "createPlaceholderDate",
    ()=>$35a22f14a1f04b11$export$66aa2b09de4b1ea5,
    "getFormatOptions",
    ()=>$35a22f14a1f04b11$export$7e319ea407e63bc0,
    "getPlaceholderTime",
    ()=>$35a22f14a1f04b11$export$c5221a78ef73c5e9,
    "getRangeValidationResult",
    ()=>$35a22f14a1f04b11$export$80ff8fc0ae339c13,
    "getValidationResult",
    ()=>$35a22f14a1f04b11$export$f18627323ab57ac0,
    "useDefaultProps",
    ()=>$35a22f14a1f04b11$export$2440da353cedad43
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$intlStrings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/intlStrings.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/DateFormatter.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$CalendarDate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/CalendarDate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/conversion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$queries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/queries.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$string$2f$dist$2f$LocalizedStringDictionary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/string/dist/LocalizedStringDictionary.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$string$2f$dist$2f$LocalizedStringFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/string/dist/LocalizedStringFormatter.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$form$2f$dist$2f$useFormValidationState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/form/dist/useFormValidationState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
;
function $parcel$interopDefault(a) {
    return a && a.__esModule ? a.default : a;
}
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ const $35a22f14a1f04b11$var$dictionary = new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$string$2f$dist$2f$LocalizedStringDictionary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocalizedStringDictionary"])((0, $parcel$interopDefault(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$intlStrings$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])));
function $35a22f14a1f04b11$var$getLocale() {
    // Match browser language setting here, NOT react-aria's I18nProvider, so that we match other browser-provided
    // validation messages, which to not respect our provider's language.
    // @ts-ignore
    let locale = typeof navigator !== 'undefined' && (navigator.language || navigator.userLanguage) || 'en-US';
    try {
        Intl.DateTimeFormat.supportedLocalesOf([
            locale
        ]);
    } catch (e) {
        locale = 'en-US';
    }
    return locale;
}
function $35a22f14a1f04b11$export$f18627323ab57ac0(value, minValue, maxValue, isDateUnavailable, options) {
    let rangeOverflow = value != null && maxValue != null && value.compare(maxValue) > 0;
    let rangeUnderflow = value != null && minValue != null && value.compare(minValue) < 0;
    let isUnavailable = value != null && (isDateUnavailable === null || isDateUnavailable === void 0 ? void 0 : isDateUnavailable(value)) || false;
    let isInvalid = rangeOverflow || rangeUnderflow || isUnavailable;
    let errors = [];
    if (isInvalid) {
        let locale = $35a22f14a1f04b11$var$getLocale();
        let strings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$string$2f$dist$2f$LocalizedStringDictionary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocalizedStringDictionary"]).getGlobalDictionaryForPackage('@react-stately/datepicker') || $35a22f14a1f04b11$var$dictionary;
        let formatter = new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$string$2f$dist$2f$LocalizedStringFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocalizedStringFormatter"])(locale, strings);
        let dateFormatter = new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DateFormatter"])(locale, $35a22f14a1f04b11$export$7e319ea407e63bc0({}, options));
        let timeZone = dateFormatter.resolvedOptions().timeZone;
        if (rangeUnderflow && minValue != null) errors.push(formatter.format('rangeUnderflow', {
            minValue: dateFormatter.format(minValue.toDate(timeZone))
        }));
        if (rangeOverflow && maxValue != null) errors.push(formatter.format('rangeOverflow', {
            maxValue: dateFormatter.format(maxValue.toDate(timeZone))
        }));
        if (isUnavailable) errors.push(formatter.format('unavailableDate'));
    }
    return {
        isInvalid: isInvalid,
        validationErrors: errors,
        validationDetails: {
            badInput: isUnavailable,
            customError: false,
            patternMismatch: false,
            rangeOverflow: rangeOverflow,
            rangeUnderflow: rangeUnderflow,
            stepMismatch: false,
            tooLong: false,
            tooShort: false,
            typeMismatch: false,
            valueMissing: false,
            valid: !isInvalid
        }
    };
}
function $35a22f14a1f04b11$export$80ff8fc0ae339c13(value, minValue, maxValue, isDateUnavailable, options) {
    var _value_start;
    let startValidation = $35a22f14a1f04b11$export$f18627323ab57ac0((_value_start = value === null || value === void 0 ? void 0 : value.start) !== null && _value_start !== void 0 ? _value_start : null, minValue, maxValue, isDateUnavailable, options);
    var _value_end;
    let endValidation = $35a22f14a1f04b11$export$f18627323ab57ac0((_value_end = value === null || value === void 0 ? void 0 : value.end) !== null && _value_end !== void 0 ? _value_end : null, minValue, maxValue, isDateUnavailable, options);
    let result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$form$2f$dist$2f$useFormValidationState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeValidation"])(startValidation, endValidation);
    if ((value === null || value === void 0 ? void 0 : value.end) != null && value.start != null && value.end.compare(value.start) < 0) {
        let strings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$string$2f$dist$2f$LocalizedStringDictionary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocalizedStringDictionary"]).getGlobalDictionaryForPackage('@react-stately/datepicker') || $35a22f14a1f04b11$var$dictionary;
        result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$form$2f$dist$2f$useFormValidationState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeValidation"])(result, {
            isInvalid: true,
            validationErrors: [
                strings.getStringForLocale('rangeReversed', $35a22f14a1f04b11$var$getLocale())
            ],
            validationDetails: {
                ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$form$2f$dist$2f$useFormValidationState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_VALIDITY_STATE"]),
                rangeUnderflow: true,
                rangeOverflow: true,
                valid: false
            }
        });
    }
    return result;
}
const $35a22f14a1f04b11$var$DEFAULT_FIELD_OPTIONS = {
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    second: '2-digit'
};
const $35a22f14a1f04b11$var$TWO_DIGIT_FIELD_OPTIONS = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
};
function $35a22f14a1f04b11$export$7e319ea407e63bc0(fieldOptions, options) {
    let defaultFieldOptions = options.shouldForceLeadingZeros ? $35a22f14a1f04b11$var$TWO_DIGIT_FIELD_OPTIONS : $35a22f14a1f04b11$var$DEFAULT_FIELD_OPTIONS;
    fieldOptions = {
        ...defaultFieldOptions,
        ...fieldOptions
    };
    let granularity = options.granularity || 'minute';
    let keys = Object.keys(fieldOptions);
    var _options_maxGranularity;
    let startIdx = keys.indexOf((_options_maxGranularity = options.maxGranularity) !== null && _options_maxGranularity !== void 0 ? _options_maxGranularity : 'year');
    if (startIdx < 0) startIdx = 0;
    let endIdx = keys.indexOf(granularity);
    if (endIdx < 0) endIdx = 2;
    if (startIdx > endIdx) throw new Error('maxGranularity must be greater than granularity');
    let opts = keys.slice(startIdx, endIdx + 1).reduce((opts, key)=>{
        opts[key] = fieldOptions[key];
        return opts;
    }, {});
    if (options.hourCycle != null) opts.hour12 = options.hourCycle === 12;
    opts.timeZone = options.timeZone || 'UTC';
    let hasTime = granularity === 'hour' || granularity === 'minute' || granularity === 'second';
    if (hasTime && options.timeZone && !options.hideTimeZone) opts.timeZoneName = 'short';
    if (options.showEra && startIdx === 0) opts.era = 'short';
    return opts;
}
function $35a22f14a1f04b11$export$c5221a78ef73c5e9(placeholderValue) {
    if (placeholderValue && 'hour' in placeholderValue) return placeholderValue;
    return new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$CalendarDate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Time"])();
}
function $35a22f14a1f04b11$export$61a490a80c552550(value, calendar) {
    if (value === null) return null;
    if (!value) return undefined;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendar"])(value, calendar);
}
function $35a22f14a1f04b11$export$66aa2b09de4b1ea5(placeholderValue, granularity, calendar, timeZone) {
    if (placeholderValue) return $35a22f14a1f04b11$export$61a490a80c552550(placeholderValue, calendar);
    let date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendar"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$queries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["now"])(timeZone !== null && timeZone !== void 0 ? timeZone : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$queries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocalTimeZone"])()).set({
        hour: 0,
        minute: 0,
        second: 0,
        millisecond: 0
    }), calendar);
    if (granularity === 'year' || granularity === 'month' || granularity === 'day') return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendarDate"])(date);
    if (!timeZone) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendarDateTime"])(date);
    return date;
}
function $35a22f14a1f04b11$export$2440da353cedad43(v, granularity) {
    // Compute default granularity and time zone from the value. If the value becomes null, keep the last values.
    let defaultTimeZone = v && 'timeZone' in v ? v.timeZone : undefined;
    let defaultGranularity = v && 'minute' in v ? 'minute' : 'day';
    // props.granularity must actually exist in the value if one is provided.
    if (v && granularity && !(granularity in v)) throw new Error('Invalid granularity ' + granularity + ' for value ' + v.toString());
    let [lastValue, setLastValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        defaultGranularity,
        defaultTimeZone
    ]);
    // If the granularity or time zone changed, update the last value.
    if (v && (lastValue[0] !== defaultGranularity || lastValue[1] !== defaultTimeZone)) setLastValue([
        defaultGranularity,
        defaultTimeZone
    ]);
    if (!granularity) granularity = v ? defaultGranularity : lastValue[0];
    let timeZone = v ? defaultTimeZone : lastValue[1];
    return [
        granularity,
        timeZone
    ];
}
;
 //# sourceMappingURL=utils.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/placeholders.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getPlaceholder",
    ()=>$3e3ed55ab2966714$export$d3f5c5e0a5023fa0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$string$2f$dist$2f$LocalizedStringDictionary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/string/dist/LocalizedStringDictionary.mjs [app-client] (ecmascript)");
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ // These placeholders are based on the strings used by the <input type="date">
// implementations in Chrome and Firefox. Additional languages are supported
// here than React Spectrum's typical translations.
const $3e3ed55ab2966714$var$placeholders = new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$string$2f$dist$2f$LocalizedStringDictionary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocalizedStringDictionary"])({
    ach: {
        year: 'mwaka',
        month: 'dwe',
        day: 'nino'
    },
    af: {
        year: 'jjjj',
        month: 'mm',
        day: 'dd'
    },
    am: {
        year: "\u12D3\u12D3\u12D3\u12D3",
        month: "\u121A\u121C",
        day: "\u1240\u1240"
    },
    an: {
        year: 'aaaa',
        month: 'mm',
        day: 'dd'
    },
    ar: {
        year: "\u0633\u0646\u0629",
        month: "\u0634\u0647\u0631",
        day: "\u064A\u0648\u0645"
    },
    ast: {
        year: 'aaaa',
        month: 'mm',
        day: 'dd'
    },
    az: {
        year: 'iiii',
        month: 'aa',
        day: 'gg'
    },
    be: {
        year: "\u0433\u0433\u0433\u0433",
        month: "\u043C\u043C",
        day: "\u0434\u0434"
    },
    bg: {
        year: "\u0433\u0433\u0433\u0433",
        month: "\u043C\u043C",
        day: "\u0434\u0434"
    },
    bn: {
        year: 'yyyy',
        month: "\u09AE\u09BF\u09AE\u09BF",
        day: 'dd'
    },
    br: {
        year: 'bbbb',
        month: 'mm',
        day: 'dd'
    },
    bs: {
        year: 'gggg',
        month: 'mm',
        day: 'dd'
    },
    ca: {
        year: 'aaaa',
        month: 'mm',
        day: 'dd'
    },
    cak: {
        year: 'jjjj',
        month: 'ii',
        day: "q'q'"
    },
    ckb: {
        year: "\u0633\u0627\u06B5",
        month: "\u0645\u0627\u0646\u06AF",
        day: "\u0695\u06C6\u0698"
    },
    cs: {
        year: 'rrrr',
        month: 'mm',
        day: 'dd'
    },
    cy: {
        year: 'bbbb',
        month: 'mm',
        day: 'dd'
    },
    da: {
        year: "\xe5\xe5\xe5\xe5",
        month: 'mm',
        day: 'dd'
    },
    de: {
        year: 'jjjj',
        month: 'mm',
        day: 'tt'
    },
    dsb: {
        year: 'llll',
        month: 'mm',
        day: "\u017A\u017A"
    },
    el: {
        year: "\u03B5\u03B5\u03B5\u03B5",
        month: "\u03BC\u03BC",
        day: "\u03B7\u03B7"
    },
    en: {
        year: 'yyyy',
        month: 'mm',
        day: 'dd'
    },
    eo: {
        year: 'jjjj',
        month: 'mm',
        day: 'tt'
    },
    es: {
        year: 'aaaa',
        month: 'mm',
        day: 'dd'
    },
    et: {
        year: 'aaaa',
        month: 'kk',
        day: 'pp'
    },
    eu: {
        year: 'uuuu',
        month: 'hh',
        day: 'ee'
    },
    fa: {
        year: "\u0633\u0627\u0644",
        month: "\u0645\u0627\u0647",
        day: "\u0631\u0648\u0632"
    },
    ff: {
        year: 'hhhh',
        month: 'll',
        day: "\xf1\xf1"
    },
    fi: {
        year: 'vvvv',
        month: 'kk',
        day: 'pp'
    },
    fr: {
        year: 'aaaa',
        month: 'mm',
        day: 'jj'
    },
    fy: {
        year: 'jjjj',
        month: 'mm',
        day: 'dd'
    },
    ga: {
        year: 'bbbb',
        month: 'mm',
        day: 'll'
    },
    gd: {
        year: 'bbbb',
        month: 'mm',
        day: 'll'
    },
    gl: {
        year: 'aaaa',
        month: 'mm',
        day: 'dd'
    },
    he: {
        year: "\u05E9\u05E0\u05D4",
        month: "\u05D7\u05D5\u05D3\u05E9",
        day: "\u05D9\u05D5\u05DD"
    },
    hr: {
        year: 'gggg',
        month: 'mm',
        day: 'dd'
    },
    hsb: {
        year: 'llll',
        month: 'mm',
        day: 'dd'
    },
    hu: {
        year: "\xe9\xe9\xe9\xe9",
        month: 'hh',
        day: 'nn'
    },
    ia: {
        year: 'aaaa',
        month: 'mm',
        day: 'dd'
    },
    id: {
        year: 'tttt',
        month: 'bb',
        day: 'hh'
    },
    it: {
        year: 'aaaa',
        month: 'mm',
        day: 'gg'
    },
    ja: {
        year: "\u5E74",
        month: "\u6708",
        day: "\u65E5"
    },
    ka: {
        year: "\u10EC\u10EC\u10EC\u10EC",
        month: "\u10D7\u10D7",
        day: "\u10E0\u10E0"
    },
    kk: {
        year: "\u0436\u0436\u0436\u0436",
        month: "\u0430\u0430",
        day: "\u043A\u043A"
    },
    kn: {
        year: "\u0CB5\u0CB5\u0CB5\u0CB5",
        month: "\u0CAE\u0CBF\u0CAE\u0CC0",
        day: "\u0CA6\u0CBF\u0CA6\u0CBF"
    },
    ko: {
        year: "\uC5F0\uB3C4",
        month: "\uC6D4",
        day: "\uC77C"
    },
    lb: {
        year: 'jjjj',
        month: 'mm',
        day: 'dd'
    },
    lo: {
        year: "\u0E9B\u0E9B\u0E9B\u0E9B",
        month: "\u0E94\u0E94",
        day: "\u0EA7\u0EA7"
    },
    lt: {
        year: 'mmmm',
        month: 'mm',
        day: 'dd'
    },
    lv: {
        year: 'gggg',
        month: 'mm',
        day: 'dd'
    },
    meh: {
        year: 'aaaa',
        month: 'mm',
        day: 'dd'
    },
    ml: {
        year: "\u0D35\u0D7C\u0D37\u0D02",
        month: "\u0D2E\u0D3E\u0D38\u0D02",
        day: "\u0D24\u0D40\u0D2F\u0D24\u0D3F"
    },
    ms: {
        year: 'tttt',
        month: 'mm',
        day: 'hh'
    },
    nb: {
        year: "\xe5\xe5\xe5\xe5",
        month: 'mm',
        day: 'dd'
    },
    nl: {
        year: 'jjjj',
        month: 'mm',
        day: 'dd'
    },
    nn: {
        year: "\xe5\xe5\xe5\xe5",
        month: 'mm',
        day: 'dd'
    },
    no: {
        year: "\xe5\xe5\xe5\xe5",
        month: 'mm',
        day: 'dd'
    },
    oc: {
        year: 'aaaa',
        month: 'mm',
        day: 'jj'
    },
    pl: {
        year: 'rrrr',
        month: 'mm',
        day: 'dd'
    },
    pt: {
        year: 'aaaa',
        month: 'mm',
        day: 'dd'
    },
    rm: {
        year: 'oooo',
        month: 'mm',
        day: 'dd'
    },
    ro: {
        year: 'aaaa',
        month: 'll',
        day: 'zz'
    },
    ru: {
        year: "\u0433\u0433\u0433\u0433",
        month: "\u043C\u043C",
        day: "\u0434\u0434"
    },
    sc: {
        year: 'aaaa',
        month: 'mm',
        day: 'dd'
    },
    scn: {
        year: 'aaaa',
        month: 'mm',
        day: 'jj'
    },
    sk: {
        year: 'rrrr',
        month: 'mm',
        day: 'dd'
    },
    sl: {
        year: 'llll',
        month: 'mm',
        day: 'dd'
    },
    sr: {
        year: "\u0433\u0433\u0433\u0433",
        month: "\u043C\u043C",
        day: "\u0434\u0434"
    },
    sv: {
        year: "\xe5\xe5\xe5\xe5",
        month: 'mm',
        day: 'dd'
    },
    szl: {
        year: 'rrrr',
        month: 'mm',
        day: 'dd'
    },
    tg: {
        year: "\u0441\u0441\u0441\u0441",
        month: "\u043C\u043C",
        day: "\u0440\u0440"
    },
    th: {
        year: "\u0E1B\u0E1B\u0E1B\u0E1B",
        month: "\u0E14\u0E14",
        day: "\u0E27\u0E27"
    },
    tr: {
        year: 'yyyy',
        month: 'aa',
        day: 'gg'
    },
    uk: {
        year: "\u0440\u0440\u0440\u0440",
        month: "\u043C\u043C",
        day: "\u0434\u0434"
    },
    'zh-CN': {
        year: "\u5E74",
        month: "\u6708",
        day: "\u65E5"
    },
    'zh-TW': {
        year: "\u5E74",
        month: "\u6708",
        day: "\u65E5"
    }
}, 'en');
function $3e3ed55ab2966714$export$d3f5c5e0a5023fa0(field, value, locale) {
    // Use the actual placeholder value for the era and day period fields.
    if (field === 'era' || field === 'dayPeriod') return value;
    if (field === 'year' || field === 'month' || field === 'day') return $3e3ed55ab2966714$var$placeholders.getStringForLocale(field, locale);
    // For time fields (e.g. hour, minute, etc.), use two dashes as the placeholder.
    return "\u2013\u2013";
}
;
 //# sourceMappingURL=placeholders.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/useDateFieldState.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDateFieldState",
    ()=>$3c0fc76039f1c516$export$60e84778edff6d26
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$placeholders$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/placeholders.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/DateFormatter.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$queries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/queries.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/conversion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$GregorianCalendar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/GregorianCalendar.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$form$2f$dist$2f$useFormValidationState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/form/dist/useFormValidationState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$utils$2f$dist$2f$useControlledState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/utils/dist/useControlledState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ const $3c0fc76039f1c516$var$EDITABLE_SEGMENTS = {
    year: true,
    month: true,
    day: true,
    hour: true,
    minute: true,
    second: true,
    dayPeriod: true,
    era: true
};
const $3c0fc76039f1c516$var$PAGE_STEP = {
    year: 5,
    month: 2,
    day: 7,
    hour: 2,
    minute: 15,
    second: 15
};
const $3c0fc76039f1c516$var$TYPE_MAPPING = {
    // Node seems to convert everything to lowercase...
    dayperiod: 'dayPeriod',
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/DateTimeFormat/formatToParts#named_years
    relatedYear: 'year',
    yearName: 'literal',
    unknown: 'literal'
};
function $3c0fc76039f1c516$export$60e84778edff6d26(props) {
    let { locale: locale, createCalendar: createCalendar, hideTimeZone: hideTimeZone, isDisabled: isDisabled = false, isReadOnly: isReadOnly = false, isRequired: isRequired = false, minValue: minValue, maxValue: maxValue, isDateUnavailable: isDateUnavailable } = props;
    let v = props.value || props.defaultValue || props.placeholderValue || null;
    let [granularity, defaultTimeZone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])(v, props.granularity);
    let timeZone = defaultTimeZone || 'UTC';
    // props.granularity must actually exist in the value if one is provided.
    if (v && !(granularity in v)) throw new Error('Invalid granularity ' + granularity + ' for value ' + v.toString());
    let defaultFormatter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DateFormatter"])(locale), [
        locale
    ]);
    let calendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>createCalendar(defaultFormatter.resolvedOptions().calendar), [
        createCalendar,
        defaultFormatter
    ]);
    var _props_defaultValue;
    let [value, setDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$utils$2f$dist$2f$useControlledState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControlledState"])(props.value, (_props_defaultValue = props.defaultValue) !== null && _props_defaultValue !== void 0 ? _props_defaultValue : null, props.onChange);
    let [initialValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(value);
    let calendarValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        var _convertValue;
        return (_convertValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertValue"])(value, calendar)) !== null && _convertValue !== void 0 ? _convertValue : null;
    }, [
        value,
        calendar
    ]);
    // We keep track of the placeholder date separately in state so that onChange is not called
    // until all segments are set. If the value === null (not undefined), then assume the component
    // is controlled, so use the placeholder as the value until all segments are entered so it doesn't
    // change from uncontrolled to controlled and emit a warning.
    let [placeholderDate, setPlaceholderDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPlaceholderDate"])(props.placeholderValue, granularity, calendar, defaultTimeZone));
    let val = calendarValue || placeholderDate;
    let showEra = calendar.identifier === 'gregory' && val.era === 'BC';
    let formatOpts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        var _props_maxGranularity;
        return {
            granularity: granularity,
            maxGranularity: (_props_maxGranularity = props.maxGranularity) !== null && _props_maxGranularity !== void 0 ? _props_maxGranularity : 'year',
            timeZone: defaultTimeZone,
            hideTimeZone: hideTimeZone,
            hourCycle: props.hourCycle,
            showEra: showEra,
            shouldForceLeadingZeros: props.shouldForceLeadingZeros
        };
    }, [
        props.maxGranularity,
        granularity,
        props.hourCycle,
        props.shouldForceLeadingZeros,
        defaultTimeZone,
        hideTimeZone,
        showEra
    ]);
    let opts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormatOptions"])({}, formatOpts), [
        formatOpts
    ]);
    let dateFormatter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DateFormatter"])(locale, opts), [
        locale,
        opts
    ]);
    let resolvedOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>dateFormatter.resolvedOptions(), [
        dateFormatter
    ]);
    // Determine how many editable segments there are for validation purposes.
    // The result is cached for performance.
    let allSegments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>dateFormatter.formatToParts(new Date()).filter((seg)=>$3c0fc76039f1c516$var$EDITABLE_SEGMENTS[seg.type]).reduce((p, seg)=>(p[$3c0fc76039f1c516$var$TYPE_MAPPING[seg.type] || seg.type] = true, p), {}), [
        dateFormatter
    ]);
    let [validSegments, setValidSegments] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(()=>props.value || props.defaultValue ? {
            ...allSegments
        } : {});
    let clearedSegment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Reset placeholder when calendar changes
    let lastCalendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(calendar);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$queries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEqualCalendar"])(calendar, lastCalendar.current)) {
            lastCalendar.current = calendar;
            setPlaceholderDate((placeholder)=>Object.keys(validSegments).length > 0 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendar"])(placeholder, calendar) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPlaceholderDate"])(props.placeholderValue, granularity, calendar, defaultTimeZone));
        }
    }, [
        calendar,
        granularity,
        validSegments,
        defaultTimeZone,
        props.placeholderValue
    ]);
    // If there is a value prop, and some segments were previously placeholders, mark them all as valid.
    if (value && Object.keys(validSegments).length < Object.keys(allSegments).length) {
        validSegments = {
            ...allSegments
        };
        setValidSegments(validSegments);
    }
    // If the value is set to null and all segments are valid, reset the placeholder.
    if (value == null && Object.keys(validSegments).length === Object.keys(allSegments).length) {
        validSegments = {};
        setValidSegments(validSegments);
        setPlaceholderDate((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPlaceholderDate"])(props.placeholderValue, granularity, calendar, defaultTimeZone));
    }
    // If all segments are valid, use the date from state, otherwise use the placeholder date.
    let displayValue = calendarValue && Object.keys(validSegments).length >= Object.keys(allSegments).length ? calendarValue : placeholderDate;
    let setValue = (newValue)=>{
        if (props.isDisabled || props.isReadOnly) return;
        let validKeys = Object.keys(validSegments);
        let allKeys = Object.keys(allSegments);
        // if all the segments are completed or a timefield with everything but am/pm set the time, also ignore when am/pm cleared
        if (newValue == null) {
            setDate(null);
            setPlaceholderDate((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPlaceholderDate"])(props.placeholderValue, granularity, calendar, defaultTimeZone));
            setValidSegments({});
        } else if (validKeys.length === 0 && clearedSegment.current == null || validKeys.length >= allKeys.length || validKeys.length === allKeys.length - 1 && allSegments.dayPeriod && !validSegments.dayPeriod && clearedSegment.current !== 'dayPeriod') {
            // If the field was empty (no valid segments) or all segments are completed, commit the new value.
            // When committing from an empty state, mark every segment as valid so value is committed.
            if (validKeys.length === 0) {
                validSegments = {
                    ...allSegments
                };
                setValidSegments(validSegments);
            }
            // The display calendar should not have any effect on the emitted value.
            // Emit dates in the same calendar as the original value, if any, otherwise gregorian.
            newValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendar"])(newValue, (v === null || v === void 0 ? void 0 : v.calendar) || new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$GregorianCalendar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GregorianCalendar"])());
            setDate(newValue);
        } else setPlaceholderDate(newValue);
        clearedSegment.current = null;
    };
    let dateValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>displayValue.toDate(timeZone), [
        displayValue,
        timeZone
    ]);
    let segments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>$3c0fc76039f1c516$var$processSegments(dateValue, validSegments, dateFormatter, resolvedOptions, displayValue, calendar, locale, granularity), [
        dateValue,
        validSegments,
        dateFormatter,
        resolvedOptions,
        displayValue,
        calendar,
        locale,
        granularity
    ]);
    // When the era field appears, mark it valid if the year field is already valid.
    // If the era field disappears, remove it from the valid segments.
    if (allSegments.era && validSegments.year && !validSegments.era) {
        validSegments.era = true;
        setValidSegments({
            ...validSegments
        });
    } else if (!allSegments.era && validSegments.era) {
        delete validSegments.era;
        setValidSegments({
            ...validSegments
        });
    }
    let markValid = (part)=>{
        validSegments[part] = true;
        if (part === 'year' && allSegments.era) validSegments.era = true;
        setValidSegments({
            ...validSegments
        });
    };
    let adjustSegment = (type, amount)=>{
        if (!validSegments[type]) {
            markValid(type);
            let validKeys = Object.keys(validSegments);
            let allKeys = Object.keys(allSegments);
            if (validKeys.length >= allKeys.length || validKeys.length === allKeys.length - 1 && allSegments.dayPeriod && !validSegments.dayPeriod) setValue(displayValue);
        } else setValue($3c0fc76039f1c516$var$addSegment(displayValue, type, amount, resolvedOptions));
    };
    let builtinValidation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValidationResult"])(value, minValue, maxValue, isDateUnavailable, formatOpts), [
        value,
        minValue,
        maxValue,
        isDateUnavailable,
        formatOpts
    ]);
    let validation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$form$2f$dist$2f$useFormValidationState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormValidationState"])({
        ...props,
        value: value,
        builtinValidation: builtinValidation
    });
    let isValueInvalid = validation.displayValidation.isInvalid;
    let validationState = props.validationState || (isValueInvalid ? 'invalid' : null);
    var _props_defaultValue1, _props_maxGranularity;
    return {
        ...validation,
        value: calendarValue,
        defaultValue: (_props_defaultValue1 = props.defaultValue) !== null && _props_defaultValue1 !== void 0 ? _props_defaultValue1 : initialValue,
        dateValue: dateValue,
        calendar: calendar,
        setValue: setValue,
        segments: segments,
        dateFormatter: dateFormatter,
        validationState: validationState,
        isInvalid: isValueInvalid,
        granularity: granularity,
        maxGranularity: (_props_maxGranularity = props.maxGranularity) !== null && _props_maxGranularity !== void 0 ? _props_maxGranularity : 'year',
        isDisabled: isDisabled,
        isReadOnly: isReadOnly,
        isRequired: isRequired,
        increment (part) {
            adjustSegment(part, 1);
        },
        decrement (part) {
            adjustSegment(part, -1);
        },
        incrementPage (part) {
            adjustSegment(part, $3c0fc76039f1c516$var$PAGE_STEP[part] || 1);
        },
        decrementPage (part) {
            adjustSegment(part, -($3c0fc76039f1c516$var$PAGE_STEP[part] || 1));
        },
        setSegment (part, v) {
            markValid(part);
            setValue($3c0fc76039f1c516$var$setSegment(displayValue, part, v, resolvedOptions));
        },
        confirmPlaceholder () {
            if (props.isDisabled || props.isReadOnly) return;
            // Confirm the placeholder if only the day period is not filled in.
            let validKeys = Object.keys(validSegments);
            let allKeys = Object.keys(allSegments);
            if (validKeys.length === allKeys.length - 1 && allSegments.dayPeriod && !validSegments.dayPeriod) {
                validSegments = {
                    ...allSegments
                };
                setValidSegments(validSegments);
                setValue(displayValue.copy());
            }
        },
        clearSegment (part) {
            delete validSegments[part];
            clearedSegment.current = part;
            setValidSegments({
                ...validSegments
            });
            let placeholder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPlaceholderDate"])(props.placeholderValue, granularity, calendar, defaultTimeZone);
            let value = displayValue;
            // Reset day period to default without changing the hour.
            if (part === 'dayPeriod' && 'hour' in displayValue && 'hour' in placeholder) {
                let isPM = displayValue.hour >= 12;
                let shouldBePM = placeholder.hour >= 12;
                if (isPM && !shouldBePM) value = displayValue.set({
                    hour: displayValue.hour - 12
                });
                else if (!isPM && shouldBePM) value = displayValue.set({
                    hour: displayValue.hour + 12
                });
            } else if (part === 'hour' && 'hour' in displayValue && displayValue.hour >= 12 && validSegments.dayPeriod) value = displayValue.set({
                hour: placeholder['hour'] + 12
            });
            else if (part in displayValue) value = displayValue.set({
                [part]: placeholder[part]
            });
            setDate(null);
            setValue(value);
        },
        formatValue (fieldOptions) {
            if (!calendarValue) return '';
            let formatOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormatOptions"])(fieldOptions, formatOpts);
            let formatter = new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DateFormatter"])(locale, formatOptions);
            return formatter.format(dateValue);
        },
        getDateFormatter (locale, formatOptions) {
            let newOptions = {
                ...formatOpts,
                ...formatOptions
            };
            let newFormatOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormatOptions"])({}, newOptions);
            return new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DateFormatter"])(locale, newFormatOptions);
        }
    };
}
function $3c0fc76039f1c516$var$processSegments(dateValue, validSegments, dateFormatter, resolvedOptions, displayValue, calendar, locale, granularity) {
    let timeValue = [
        'hour',
        'minute',
        'second'
    ];
    let segments = dateFormatter.formatToParts(dateValue);
    let processedSegments = [];
    for (let segment of segments){
        let type = $3c0fc76039f1c516$var$TYPE_MAPPING[segment.type] || segment.type;
        let isEditable = $3c0fc76039f1c516$var$EDITABLE_SEGMENTS[type];
        if (type === 'era' && calendar.getEras().length === 1) isEditable = false;
        let isPlaceholder = $3c0fc76039f1c516$var$EDITABLE_SEGMENTS[type] && !validSegments[type];
        let placeholder = $3c0fc76039f1c516$var$EDITABLE_SEGMENTS[type] ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$placeholders$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPlaceholder"])(type, segment.value, locale) : null;
        let dateSegment = {
            type: type,
            text: isPlaceholder ? placeholder : segment.value,
            ...$3c0fc76039f1c516$var$getSegmentLimits(displayValue, type, resolvedOptions),
            isPlaceholder: isPlaceholder,
            placeholder: placeholder,
            isEditable: isEditable
        };
        // There is an issue in RTL languages where time fields render (minute:hour) instead of (hour:minute).
        // To force an LTR direction on the time field since, we wrap the time segments in LRI (left-to-right) isolate unicode. See https://www.w3.org/International/questions/qa-bidi-unicode-controls.
        // These unicode characters will be added to the array of processed segments as literals and will mark the start and end of the embedded direction change.
        if (type === 'hour') {
            // This marks the start of the embedded direction change.
            processedSegments.push({
                type: 'literal',
                text: '\u2066',
                ...$3c0fc76039f1c516$var$getSegmentLimits(displayValue, 'literal', resolvedOptions),
                isPlaceholder: false,
                placeholder: '',
                isEditable: false
            });
            processedSegments.push(dateSegment);
            // This marks the end of the embedded direction change in the case that the granularity it set to "hour".
            if (type === granularity) processedSegments.push({
                type: 'literal',
                text: '\u2069',
                ...$3c0fc76039f1c516$var$getSegmentLimits(displayValue, 'literal', resolvedOptions),
                isPlaceholder: false,
                placeholder: '',
                isEditable: false
            });
        } else if (timeValue.includes(type) && type === granularity) {
            processedSegments.push(dateSegment);
            // This marks the end of the embedded direction change.
            processedSegments.push({
                type: 'literal',
                text: '\u2069',
                ...$3c0fc76039f1c516$var$getSegmentLimits(displayValue, 'literal', resolvedOptions),
                isPlaceholder: false,
                placeholder: '',
                isEditable: false
            });
        } else processedSegments.push(dateSegment);
    }
    return processedSegments;
}
function $3c0fc76039f1c516$var$getSegmentLimits(date, type, options) {
    switch(type){
        case 'era':
            {
                let eras = date.calendar.getEras();
                return {
                    value: eras.indexOf(date.era),
                    minValue: 0,
                    maxValue: eras.length - 1
                };
            }
        case 'year':
            return {
                value: date.year,
                minValue: 1,
                maxValue: date.calendar.getYearsInEra(date)
            };
        case 'month':
            return {
                value: date.month,
                minValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$queries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMinimumMonthInYear"])(date),
                maxValue: date.calendar.getMonthsInYear(date)
            };
        case 'day':
            return {
                value: date.day,
                minValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$queries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMinimumDayInMonth"])(date),
                maxValue: date.calendar.getDaysInMonth(date)
            };
    }
    if ('hour' in date) switch(type){
        case 'dayPeriod':
            return {
                value: date.hour >= 12 ? 12 : 0,
                minValue: 0,
                maxValue: 12
            };
        case 'hour':
            if (options.hour12) {
                let isPM = date.hour >= 12;
                return {
                    value: date.hour,
                    minValue: isPM ? 12 : 0,
                    maxValue: isPM ? 23 : 11
                };
            }
            return {
                value: date.hour,
                minValue: 0,
                maxValue: 23
            };
        case 'minute':
            return {
                value: date.minute,
                minValue: 0,
                maxValue: 59
            };
        case 'second':
            return {
                value: date.second,
                minValue: 0,
                maxValue: 59
            };
    }
    return {};
}
function $3c0fc76039f1c516$var$addSegment(value, part, amount, options) {
    switch(part){
        case 'era':
        case 'year':
        case 'month':
        case 'day':
            return value.cycle(part, amount, {
                round: part === 'year'
            });
    }
    if ('hour' in value) switch(part){
        case 'dayPeriod':
            {
                let hours = value.hour;
                let isPM = hours >= 12;
                return value.set({
                    hour: isPM ? hours - 12 : hours + 12
                });
            }
        case 'hour':
        case 'minute':
        case 'second':
            return value.cycle(part, amount, {
                round: part !== 'hour',
                hourCycle: options.hour12 ? 12 : 24
            });
    }
    throw new Error('Unknown segment: ' + part);
}
function $3c0fc76039f1c516$var$setSegment(value, part, segmentValue, options) {
    switch(part){
        case 'day':
        case 'month':
        case 'year':
        case 'era':
            return value.set({
                [part]: segmentValue
            });
    }
    if ('hour' in value && typeof segmentValue === 'number') switch(part){
        case 'dayPeriod':
            {
                let hours = value.hour;
                let wasPM = hours >= 12;
                let isPM = segmentValue >= 12;
                if (isPM === wasPM) return value;
                return value.set({
                    hour: wasPM ? hours - 12 : hours + 12
                });
            }
        case 'hour':
            // In 12 hour time, ensure that AM/PM does not change
            if (options.hour12) {
                let hours = value.hour;
                let wasPM = hours >= 12;
                if (!wasPM && segmentValue === 12) segmentValue = 0;
                if (wasPM && segmentValue < 12) segmentValue += 12;
            }
        // fallthrough
        case 'minute':
        case 'second':
            return value.set({
                [part]: segmentValue
            });
    }
    throw new Error('Unknown segment: ' + part);
}
;
 //# sourceMappingURL=useDateFieldState.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/useTimeFieldState.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTimeFieldState",
    ()=>$eff5d8ee529ac4bb$export$fd53cef0cc796101
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$useDateFieldState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/useDateFieldState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$CalendarDate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/CalendarDate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/conversion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$GregorianCalendar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/GregorianCalendar.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$queries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/queries.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$utils$2f$dist$2f$useControlledState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/utils/dist/useControlledState.mjs [app-client] (ecmascript)");
;
;
;
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ function $eff5d8ee529ac4bb$export$fd53cef0cc796101(props) {
    let { placeholderValue: placeholderValue = new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$CalendarDate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Time"])(), minValue: minValue, maxValue: maxValue, defaultValue: defaultValue, granularity: granularity, validate: validate } = props;
    let [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$utils$2f$dist$2f$useControlledState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControlledState"])(props.value, defaultValue !== null && defaultValue !== void 0 ? defaultValue : null, props.onChange);
    let v = value || placeholderValue;
    let day = v && 'day' in v ? v : undefined;
    let defaultValueTimeZone = defaultValue && 'timeZone' in defaultValue ? defaultValue.timeZone : undefined;
    let placeholderDate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        let valueTimeZone = v && 'timeZone' in v ? v.timeZone : undefined;
        return (valueTimeZone || defaultValueTimeZone) && placeholderValue ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toZoned"])($eff5d8ee529ac4bb$var$convertValue(placeholderValue), valueTimeZone || defaultValueTimeZone) : $eff5d8ee529ac4bb$var$convertValue(placeholderValue);
    }, [
        placeholderValue,
        v,
        defaultValueTimeZone
    ]);
    let minDate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>$eff5d8ee529ac4bb$var$convertValue(minValue, day), [
        minValue,
        day
    ]);
    let maxDate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>$eff5d8ee529ac4bb$var$convertValue(maxValue, day), [
        maxValue,
        day
    ]);
    let timeValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>value && 'day' in value ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTime"])(value) : value, [
        value
    ]);
    let dateTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>value == null ? null : $eff5d8ee529ac4bb$var$convertValue(value), [
        value
    ]);
    let defaultDateTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>defaultValue == null ? null : $eff5d8ee529ac4bb$var$convertValue(defaultValue), [
        defaultValue
    ]);
    let onChange = (newValue)=>{
        setValue(day || defaultValueTimeZone ? newValue : newValue && (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTime"])(newValue));
    };
    let state = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$useDateFieldState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDateFieldState"])({
        ...props,
        value: dateTime,
        defaultValue: defaultDateTime,
        minValue: minDate,
        maxValue: maxDate,
        onChange: onChange,
        granularity: granularity || 'minute',
        maxGranularity: 'hour',
        placeholderValue: placeholderDate !== null && placeholderDate !== void 0 ? placeholderDate : undefined,
        // Calendar should not matter for time fields.
        createCalendar: ()=>new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$GregorianCalendar$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GregorianCalendar"])(),
        validate: (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>validate === null || validate === void 0 ? void 0 : validate(value), [
            validate,
            value
        ])
    });
    return {
        ...state,
        timeValue: timeValue
    };
}
function $eff5d8ee529ac4bb$var$convertValue(value) {
    let date = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$queries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["today"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$queries$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocalTimeZone"])());
    if (!value) return null;
    if ('day' in value) return value;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendarDateTime"])(date, value);
}
;
 //# sourceMappingURL=useTimeFieldState.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/useDatePickerState.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDatePickerState",
    ()=>$ab5bf3f618090389$export$87194bb378cc3ac2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/conversion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/DateFormatter.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$form$2f$dist$2f$useFormValidationState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/form/dist/useFormValidationState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$overlays$2f$dist$2f$useOverlayTriggerState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/overlays/dist/useOverlayTriggerState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$utils$2f$dist$2f$useControlledState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/utils/dist/useControlledState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ function $ab5bf3f618090389$export$87194bb378cc3ac2(props) {
    let overlayState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$overlays$2f$dist$2f$useOverlayTriggerState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOverlayTriggerState"])(props);
    let [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$utils$2f$dist$2f$useControlledState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControlledState"])(props.value, props.defaultValue || null, props.onChange);
    let [initialValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(value);
    let v = value || props.placeholderValue || null;
    let [granularity, defaultTimeZone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])(v, props.granularity);
    let dateValue = value != null ? value.toDate(defaultTimeZone !== null && defaultTimeZone !== void 0 ? defaultTimeZone : 'UTC') : null;
    let hasTime = granularity === 'hour' || granularity === 'minute' || granularity === 'second';
    var _props_shouldCloseOnSelect;
    let shouldCloseOnSelect = (_props_shouldCloseOnSelect = props.shouldCloseOnSelect) !== null && _props_shouldCloseOnSelect !== void 0 ? _props_shouldCloseOnSelect : true;
    let [selectedDate, setSelectedDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let [selectedTime, setSelectedTime] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    if (value) {
        selectedDate = value;
        if ('hour' in value) selectedTime = value;
    }
    // props.granularity must actually exist in the value if one is provided.
    if (v && !(granularity in v)) throw new Error('Invalid granularity ' + granularity + ' for value ' + v.toString());
    let showEra = (value === null || value === void 0 ? void 0 : value.calendar.identifier) === 'gregory' && value.era === 'BC';
    let formatOpts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            granularity: granularity,
            timeZone: defaultTimeZone,
            hideTimeZone: props.hideTimeZone,
            hourCycle: props.hourCycle,
            shouldForceLeadingZeros: props.shouldForceLeadingZeros,
            showEra: showEra
        }), [
        granularity,
        props.hourCycle,
        props.shouldForceLeadingZeros,
        defaultTimeZone,
        props.hideTimeZone,
        showEra
    ]);
    let { minValue: minValue, maxValue: maxValue, isDateUnavailable: isDateUnavailable } = props;
    let builtinValidation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValidationResult"])(value, minValue, maxValue, isDateUnavailable, formatOpts), [
        value,
        minValue,
        maxValue,
        isDateUnavailable,
        formatOpts
    ]);
    let validation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$form$2f$dist$2f$useFormValidationState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormValidationState"])({
        ...props,
        value: value,
        builtinValidation: builtinValidation
    });
    let isValueInvalid = validation.displayValidation.isInvalid;
    let validationState = props.validationState || (isValueInvalid ? 'invalid' : null);
    let commitValue = (date, time)=>{
        setValue('timeZone' in time ? time.set((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendarDate"])(date)) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendarDateTime"])(date, time));
        setSelectedDate(null);
        setSelectedTime(null);
        validation.commitValidation();
    };
    // Intercept setValue to make sure the Time section is not changed by date selection in Calendar
    let selectDate = (newValue)=>{
        let shouldClose = typeof shouldCloseOnSelect === 'function' ? shouldCloseOnSelect() : shouldCloseOnSelect;
        if (hasTime) {
            if (selectedTime || shouldClose) commitValue(newValue, selectedTime || (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPlaceholderTime"])(props.defaultValue || props.placeholderValue));
            else setSelectedDate(newValue);
        } else {
            setValue(newValue);
            validation.commitValidation();
        }
        if (shouldClose) overlayState.setOpen(false);
    };
    let selectTime = (newValue)=>{
        if (selectedDate && newValue) commitValue(selectedDate, newValue);
        else setSelectedTime(newValue);
    };
    var _props_defaultValue;
    return {
        ...validation,
        value: value,
        defaultValue: (_props_defaultValue = props.defaultValue) !== null && _props_defaultValue !== void 0 ? _props_defaultValue : initialValue,
        setValue: setValue,
        dateValue: selectedDate,
        timeValue: selectedTime,
        setDateValue: selectDate,
        setTimeValue: selectTime,
        granularity: granularity,
        hasTime: hasTime,
        ...overlayState,
        setOpen (isOpen) {
            // Commit the selected date when the calendar is closed. Use a placeholder time if one wasn't set.
            // If only the time was set and not the date, don't commit. The state will be preserved until
            // the user opens the popover again.
            if (!isOpen && !value && selectedDate && hasTime) commitValue(selectedDate, selectedTime || (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPlaceholderTime"])(props.defaultValue || props.placeholderValue));
            overlayState.setOpen(isOpen);
        },
        validationState: validationState,
        isInvalid: isValueInvalid,
        formatValue (locale, fieldOptions) {
            if (!dateValue) return '';
            let formatOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormatOptions"])(fieldOptions, formatOpts);
            let formatter = new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DateFormatter"])(locale, formatOptions);
            return formatter.format(dateValue);
        },
        getDateFormatter (locale, formatOptions) {
            let newOptions = {
                ...formatOpts,
                ...formatOptions
            };
            let newFormatOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormatOptions"])({}, newOptions);
            return new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DateFormatter"])(locale, newFormatOptions);
        }
    };
}
;
 //# sourceMappingURL=useDatePickerState.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/useDateRangePickerState.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDateRangePickerState",
    ()=>$93c38a5e28be6249$export$e50a61c1de9f574
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/datepicker/dist/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/conversion.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/date/dist/DateFormatter.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$form$2f$dist$2f$useFormValidationState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/form/dist/useFormValidationState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$overlays$2f$dist$2f$useOverlayTriggerState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/overlays/dist/useOverlayTriggerState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$utils$2f$dist$2f$useControlledState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/utils/dist/useControlledState.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ function $93c38a5e28be6249$export$e50a61c1de9f574(props) {
    var _value_start, _value_end;
    let overlayState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$overlays$2f$dist$2f$useOverlayTriggerState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOverlayTriggerState"])(props);
    let [controlledValue, setControlledValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$utils$2f$dist$2f$useControlledState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControlledState"])(props.value, props.defaultValue || null, props.onChange);
    let [initialValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(controlledValue);
    let [placeholderValue, setPlaceholderValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(()=>controlledValue || {
            start: null,
            end: null
        });
    // Reset the placeholder if the value prop is set to null.
    if (controlledValue == null && placeholderValue.start && placeholderValue.end) {
        placeholderValue = {
            start: null,
            end: null
        };
        setPlaceholderValue(placeholderValue);
    }
    let value = controlledValue || placeholderValue;
    let setValue = (newValue)=>{
        value = newValue || {
            start: null,
            end: null
        };
        setPlaceholderValue(value);
        if ($93c38a5e28be6249$var$isCompleteRange(value)) setControlledValue(value);
        else setControlledValue(null);
    };
    let v = (value === null || value === void 0 ? void 0 : value.start) || (value === null || value === void 0 ? void 0 : value.end) || props.placeholderValue || null;
    let [granularity, defaultTimeZone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])(v, props.granularity);
    let hasTime = granularity === 'hour' || granularity === 'minute' || granularity === 'second';
    var _props_shouldCloseOnSelect;
    let shouldCloseOnSelect = (_props_shouldCloseOnSelect = props.shouldCloseOnSelect) !== null && _props_shouldCloseOnSelect !== void 0 ? _props_shouldCloseOnSelect : true;
    let [dateRange, setSelectedDateRange] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let [timeRange, setSelectedTimeRange] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    if (value && $93c38a5e28be6249$var$isCompleteRange(value)) {
        dateRange = value;
        if ('hour' in value.start) timeRange = value;
    }
    let commitValue = (dateRange, timeRange)=>{
        setValue({
            start: 'timeZone' in timeRange.start ? timeRange.start.set((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendarDate"])(dateRange.start)) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendarDateTime"])(dateRange.start, timeRange.start),
            end: 'timeZone' in timeRange.end ? timeRange.end.set((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendarDate"])(dateRange.end)) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$conversion$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCalendarDateTime"])(dateRange.end, timeRange.end)
        });
        setSelectedDateRange(null);
        setSelectedTimeRange(null);
        validation.commitValidation();
    };
    // Intercept setValue to make sure the Time section is not changed by date selection in Calendar
    let setDateRange = (range)=>{
        let shouldClose = typeof shouldCloseOnSelect === 'function' ? shouldCloseOnSelect() : shouldCloseOnSelect;
        if (hasTime) {
            // Set a placeholder time if the popover is closing so we don't leave the field in an incomplete state.
            if ($93c38a5e28be6249$var$isCompleteRange(range) && (shouldClose || (timeRange === null || timeRange === void 0 ? void 0 : timeRange.start) && (timeRange === null || timeRange === void 0 ? void 0 : timeRange.end))) commitValue(range, {
                start: (timeRange === null || timeRange === void 0 ? void 0 : timeRange.start) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPlaceholderTime"])(props.placeholderValue),
                end: (timeRange === null || timeRange === void 0 ? void 0 : timeRange.end) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPlaceholderTime"])(props.placeholderValue)
            });
            else setSelectedDateRange(range);
        } else if ($93c38a5e28be6249$var$isCompleteRange(range)) {
            setValue(range);
            validation.commitValidation();
        } else setSelectedDateRange(range);
        if (shouldClose) overlayState.setOpen(false);
    };
    let setTimeRange = (range)=>{
        if ($93c38a5e28be6249$var$isCompleteRange(dateRange) && $93c38a5e28be6249$var$isCompleteRange(range)) commitValue(dateRange, range);
        else setSelectedTimeRange(range);
    };
    let showEra = (value === null || value === void 0 ? void 0 : (_value_start = value.start) === null || _value_start === void 0 ? void 0 : _value_start.calendar.identifier) === 'gregory' && value.start.era === 'BC' || (value === null || value === void 0 ? void 0 : (_value_end = value.end) === null || _value_end === void 0 ? void 0 : _value_end.calendar.identifier) === 'gregory' && value.end.era === 'BC';
    let formatOpts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            granularity: granularity,
            timeZone: defaultTimeZone,
            hideTimeZone: props.hideTimeZone,
            hourCycle: props.hourCycle,
            shouldForceLeadingZeros: props.shouldForceLeadingZeros,
            showEra: showEra
        }), [
        granularity,
        props.hourCycle,
        props.shouldForceLeadingZeros,
        defaultTimeZone,
        props.hideTimeZone,
        showEra
    ]);
    let { minValue: minValue, maxValue: maxValue, isDateUnavailable: isDateUnavailable } = props;
    let builtinValidation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRangeValidationResult"])(value, minValue, maxValue, isDateUnavailable, formatOpts), [
        value,
        minValue,
        maxValue,
        isDateUnavailable,
        formatOpts
    ]);
    let validation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$form$2f$dist$2f$useFormValidationState$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormValidationState"])({
        ...props,
        value: controlledValue,
        name: (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>[
                props.startName,
                props.endName
            ].filter((n)=>n != null), [
            props.startName,
            props.endName
        ]),
        builtinValidation: builtinValidation
    });
    let isValueInvalid = validation.displayValidation.isInvalid;
    let validationState = props.validationState || (isValueInvalid ? 'invalid' : null);
    var _props_defaultValue;
    return {
        ...validation,
        value: value,
        defaultValue: (_props_defaultValue = props.defaultValue) !== null && _props_defaultValue !== void 0 ? _props_defaultValue : initialValue,
        setValue: setValue,
        dateRange: dateRange,
        timeRange: timeRange,
        granularity: granularity,
        hasTime: hasTime,
        setDate (part, date) {
            var _dateRange_end, _dateRange_start;
            if (part === 'start') setDateRange({
                start: date,
                end: (_dateRange_end = dateRange === null || dateRange === void 0 ? void 0 : dateRange.end) !== null && _dateRange_end !== void 0 ? _dateRange_end : null
            });
            else setDateRange({
                start: (_dateRange_start = dateRange === null || dateRange === void 0 ? void 0 : dateRange.start) !== null && _dateRange_start !== void 0 ? _dateRange_start : null,
                end: date
            });
        },
        setTime (part, time) {
            var _timeRange_end, _timeRange_start;
            if (part === 'start') setTimeRange({
                start: time,
                end: (_timeRange_end = timeRange === null || timeRange === void 0 ? void 0 : timeRange.end) !== null && _timeRange_end !== void 0 ? _timeRange_end : null
            });
            else setTimeRange({
                start: (_timeRange_start = timeRange === null || timeRange === void 0 ? void 0 : timeRange.start) !== null && _timeRange_start !== void 0 ? _timeRange_start : null,
                end: time
            });
        },
        setDateTime (part, dateTime) {
            var _value_end, _value_start;
            if (part === 'start') setValue({
                start: dateTime,
                end: (_value_end = value === null || value === void 0 ? void 0 : value.end) !== null && _value_end !== void 0 ? _value_end : null
            });
            else setValue({
                start: (_value_start = value === null || value === void 0 ? void 0 : value.start) !== null && _value_start !== void 0 ? _value_start : null,
                end: dateTime
            });
        },
        setDateRange: setDateRange,
        setTimeRange: setTimeRange,
        ...overlayState,
        setOpen (isOpen) {
            // Commit the selected date range when the calendar is closed. Use a placeholder time if one wasn't set.
            // If only the time range was set and not the date range, don't commit. The state will be preserved until
            // the user opens the popover again.
            if (!isOpen && !((value === null || value === void 0 ? void 0 : value.start) && (value === null || value === void 0 ? void 0 : value.end)) && $93c38a5e28be6249$var$isCompleteRange(dateRange) && hasTime) commitValue(dateRange, {
                start: (timeRange === null || timeRange === void 0 ? void 0 : timeRange.start) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPlaceholderTime"])(props.placeholderValue),
                end: (timeRange === null || timeRange === void 0 ? void 0 : timeRange.end) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPlaceholderTime"])(props.placeholderValue)
            });
            overlayState.setOpen(isOpen);
        },
        validationState: validationState,
        isInvalid: isValueInvalid,
        formatValue (locale, fieldOptions) {
            if (!value || !value.start || !value.end) return null;
            let startTimeZone = 'timeZone' in value.start ? value.start.timeZone : undefined;
            let startGranularity = props.granularity || (value.start && 'minute' in value.start ? 'minute' : 'day');
            let endTimeZone = 'timeZone' in value.end ? value.end.timeZone : undefined;
            let endGranularity = props.granularity || (value.end && 'minute' in value.end ? 'minute' : 'day');
            let startOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormatOptions"])(fieldOptions, {
                granularity: startGranularity,
                timeZone: startTimeZone,
                hideTimeZone: props.hideTimeZone,
                hourCycle: props.hourCycle,
                showEra: value.start.calendar.identifier === 'gregory' && value.start.era === 'BC' || value.end.calendar.identifier === 'gregory' && value.end.era === 'BC'
            });
            let startDate = value.start.toDate(startTimeZone || 'UTC');
            let endDate = value.end.toDate(endTimeZone || 'UTC');
            let startFormatter = new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DateFormatter"])(locale, startOptions);
            let endFormatter;
            if (startTimeZone === endTimeZone && startGranularity === endGranularity && value.start.compare(value.end) !== 0) {
                // Use formatRange, as it results in shorter output when some of the fields
                // are shared between the start and end dates (e.g. the same month).
                // Formatting will fail if the end date is before the start date. Fall back below when that happens.
                try {
                    let parts = startFormatter.formatRangeToParts(startDate, endDate);
                    // Find the separator between the start and end date. This is determined
                    // by finding the last shared literal before the end range.
                    let separatorIndex = -1;
                    for(let i = 0; i < parts.length; i++){
                        let part = parts[i];
                        if (part.source === 'shared' && part.type === 'literal') separatorIndex = i;
                        else if (part.source === 'endRange') break;
                    }
                    // Now we can combine the parts into start and end strings.
                    let start = '';
                    let end = '';
                    for(let i = 0; i < parts.length; i++){
                        if (i < separatorIndex) start += parts[i].value;
                        else if (i > separatorIndex) end += parts[i].value;
                    }
                    return {
                        start: start,
                        end: end
                    };
                } catch (e) {
                // ignore
                }
                endFormatter = startFormatter;
            } else {
                let endOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormatOptions"])(fieldOptions, {
                    granularity: endGranularity,
                    timeZone: endTimeZone,
                    hideTimeZone: props.hideTimeZone,
                    hourCycle: props.hourCycle
                });
                endFormatter = new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DateFormatter"])(locale, endOptions);
            }
            return {
                start: startFormatter.format(startDate),
                end: endFormatter.format(endDate)
            };
        },
        getDateFormatter (locale, formatOptions) {
            let newOptions = {
                ...formatOpts,
                ...formatOptions
            };
            let newFormatOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$datepicker$2f$dist$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormatOptions"])({}, newOptions);
            return new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$date$2f$dist$2f$DateFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DateFormatter"])(locale, newFormatOptions);
        }
    };
}
function $93c38a5e28be6249$var$isCompleteRange(value) {
    return (value === null || value === void 0 ? void 0 : value.start) != null && value.end != null;
}
;
 //# sourceMappingURL=useDateRangePickerState.module.js.map
}),
]);

//# sourceMappingURL=2e916_%40react-stately_datepicker_dist_d8a2c7dd._.js.map