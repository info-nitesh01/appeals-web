(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/noop.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*#__NO_SIDE_EFFECTS__*/ __turbopack_context__.s([
    "noop",
    ()=>noop
]);
const noop = (any)=>any;
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/format-error-message.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatErrorMessage",
    ()=>formatErrorMessage
]);
function formatErrorMessage(message, errorCode) {
    return errorCode ? "".concat(message, ". For more information and steps for solving, visit https://motion.dev/troubleshooting/").concat(errorCode) : message;
}
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/warn-once.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hasWarned",
    ()=>hasWarned,
    "warnOnce",
    ()=>warnOnce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$format$2d$error$2d$message$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/format-error-message.mjs [app-client] (ecmascript)");
;
const warned = new Set();
function hasWarned(message) {
    return warned.has(message);
}
function warnOnce(condition, message, errorCode) {
    if (condition || warned.has(message)) return;
    console.warn((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$format$2d$error$2d$message$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessage"])(message, errorCode));
    warned.add(message);
}
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/array.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addUniqueItem",
    ()=>addUniqueItem,
    "moveItem",
    ()=>moveItem,
    "removeItem",
    ()=>removeItem
]);
function addUniqueItem(arr, item) {
    if (arr.indexOf(item) === -1) arr.push(item);
}
function removeItem(arr, item) {
    const index = arr.indexOf(item);
    if (index > -1) arr.splice(index, 1);
}
// Adapted from array-move
function moveItem(param, fromIndex, toIndex) {
    let [...arr] = param;
    const startIndex = fromIndex < 0 ? arr.length + fromIndex : fromIndex;
    if (startIndex >= 0 && startIndex < arr.length) {
        const endIndex = toIndex < 0 ? arr.length + toIndex : toIndex;
        const [item] = arr.splice(fromIndex, 1);
        arr.splice(endIndex, 0, item);
    }
    return arr;
}
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/subscription-manager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SubscriptionManager",
    ()=>SubscriptionManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/array.mjs [app-client] (ecmascript)");
;
class SubscriptionManager {
    add(handler) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addUniqueItem"])(this.subscriptions, handler);
        return ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeItem"])(this.subscriptions, handler);
    }
    notify(a, b, c) {
        const numSubscriptions = this.subscriptions.length;
        if (!numSubscriptions) return;
        if (numSubscriptions === 1) {
            /**
             * If there's only a single handler we can just call it without invoking a loop.
             */ this.subscriptions[0](a, b, c);
        } else {
            for(let i = 0; i < numSubscriptions; i++){
                /**
                 * Check whether the handler exists before firing as it's possible
                 * the subscriptions were modified during this loop running.
                 */ const handler = this.subscriptions[i];
                handler && handler(a, b, c);
            }
        }
    }
    getSize() {
        return this.subscriptions.length;
    }
    clear() {
        this.subscriptions.length = 0;
    }
    constructor(){
        this.subscriptions = [];
    }
}
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/velocity-per-second.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
  Convert velocity into velocity per second

  @param [number]: Unit per frame
  @param [number]: Frame duration in ms
*/ __turbopack_context__.s([
    "velocityPerSecond",
    ()=>velocityPerSecond
]);
function velocityPerSecond(velocity, frameDuration) {
    return frameDuration ? velocity * (1000 / frameDuration) : 0;
}
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/errors.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "invariant",
    ()=>invariant,
    "warning",
    ()=>warning
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$format$2d$error$2d$message$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/format-error-message.mjs [app-client] (ecmascript)");
;
let warning = ()=>{};
let invariant = ()=>{};
if ("TURBOPACK compile-time truthy", 1) {
    warning = (check, message, errorCode)=>{
        if (!check && typeof console !== "undefined") {
            console.warn((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$format$2d$error$2d$message$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessage"])(message, errorCode));
        }
    };
    invariant = (check, message, errorCode)=>{
        if (!check) {
            throw new Error((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$format$2d$error$2d$message$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessage"])(message, errorCode));
        }
    };
}
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/pipe.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Pipe
 * Compose other transformers to run linearily
 * pipe(min(20), max(40))
 * @param  {...functions} transformers
 * @return {function}
 */ __turbopack_context__.s([
    "pipe",
    ()=>pipe
]);
const combineFunctions = (a, b)=>(v)=>b(a(v));
const pipe = function() {
    for(var _len = arguments.length, transformers = new Array(_len), _key = 0; _key < _len; _key++){
        transformers[_key] = arguments[_key];
    }
    return transformers.reduce(combineFunctions);
};
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/clamp.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clamp",
    ()=>clamp
]);
const clamp = (min, max, v)=>{
    if (v > max) return max;
    if (v < min) return min;
    return v;
};
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/time-conversion.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Converts seconds to milliseconds
 *
 * @param seconds - Time in seconds.
 * @return milliseconds - Converted time in milliseconds.
 */ /*#__NO_SIDE_EFFECTS__*/ __turbopack_context__.s([
    "millisecondsToSeconds",
    ()=>millisecondsToSeconds,
    "secondsToMilliseconds",
    ()=>secondsToMilliseconds
]);
const secondsToMilliseconds = (seconds)=>seconds * 1000;
/*#__NO_SIDE_EFFECTS__*/ const millisecondsToSeconds = (milliseconds)=>milliseconds / 1000;
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/cubic-bezier.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cubicBezier",
    ()=>cubicBezier
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$noop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/noop.mjs [app-client] (ecmascript)");
;
/*
  Bezier function generator
  This has been modified from Gaëtan Renaudeau's BezierEasing
  https://github.com/gre/bezier-easing/blob/master/src/index.js
  https://github.com/gre/bezier-easing/blob/master/LICENSE
  
  I've removed the newtonRaphsonIterate algo because in benchmarking it
  wasn't noticeably faster than binarySubdivision, indeed removing it
  usually improved times, depending on the curve.
  I also removed the lookup table, as for the added bundle size and loop we're
  only cutting ~4 or so subdivision iterations. I bumped the max iterations up
  to 12 to compensate and this still tended to be faster for no perceivable
  loss in accuracy.
  Usage
    const easeOut = cubicBezier(.17,.67,.83,.67);
    const x = easeOut(0.5); // returns 0.627...
*/ // Returns x(t) given t, x1, and x2, or y(t) given t, y1, and y2.
const calcBezier = (t, a1, a2)=>(((1.0 - 3.0 * a2 + 3.0 * a1) * t + (3.0 * a2 - 6.0 * a1)) * t + 3.0 * a1) * t;
const subdivisionPrecision = 0.0000001;
const subdivisionMaxIterations = 12;
function binarySubdivide(x, lowerBound, upperBound, mX1, mX2) {
    let currentX;
    let currentT;
    let i = 0;
    do {
        currentT = lowerBound + (upperBound - lowerBound) / 2.0;
        currentX = calcBezier(currentT, mX1, mX2) - x;
        if (currentX > 0.0) {
            upperBound = currentT;
        } else {
            lowerBound = currentT;
        }
    }while (Math.abs(currentX) > subdivisionPrecision && ++i < subdivisionMaxIterations)
    return currentT;
}
function cubicBezier(mX1, mY1, mX2, mY2) {
    // If this is a linear gradient, return linear easing
    if (mX1 === mY1 && mX2 === mY2) return __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$noop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"];
    const getTForX = (aX)=>binarySubdivide(aX, 0, 1, mX1, mX2);
    // If animation is at start/end, return t without easing
    return (t)=>t === 0 || t === 1 ? t : calcBezier(getTForX(t), mY1, mY2);
}
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/ease.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "easeIn",
    ()=>easeIn,
    "easeInOut",
    ()=>easeInOut,
    "easeOut",
    ()=>easeOut
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/cubic-bezier.mjs [app-client] (ecmascript)");
;
const easeIn = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cubicBezier"])(0.42, 0, 1, 1);
const easeOut = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cubicBezier"])(0, 0, 0.58, 1);
const easeInOut = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cubicBezier"])(0.42, 0, 0.58, 1);
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/utils/is-easing-array.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isEasingArray",
    ()=>isEasingArray
]);
const isEasingArray = (ease)=>{
    return Array.isArray(ease) && typeof ease[0] !== "number";
};
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/modifiers/mirror.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Accepts an easing function and returns a new one that outputs mirrored values for
// the second half of the animation. Turns easeIn into easeInOut.
__turbopack_context__.s([
    "mirrorEasing",
    ()=>mirrorEasing
]);
const mirrorEasing = (easing)=>(p)=>p <= 0.5 ? easing(2 * p) / 2 : (2 - easing(2 * (1 - p))) / 2;
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/modifiers/reverse.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Accepts an easing function and returns a new one that outputs reversed values.
// Turns easeIn into easeOut.
__turbopack_context__.s([
    "reverseEasing",
    ()=>reverseEasing
]);
const reverseEasing = (easing)=>(p)=>1 - easing(1 - p);
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/back.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "backIn",
    ()=>backIn,
    "backInOut",
    ()=>backInOut,
    "backOut",
    ()=>backOut
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/cubic-bezier.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$mirror$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/modifiers/mirror.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$reverse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/modifiers/reverse.mjs [app-client] (ecmascript)");
;
;
;
const backOut = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cubicBezier"])(0.33, 1.53, 0.69, 0.99);
const backIn = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$reverse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reverseEasing"])(backOut);
const backInOut = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$mirror$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mirrorEasing"])(backIn);
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/anticipate.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "anticipate",
    ()=>anticipate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/back.mjs [app-client] (ecmascript)");
;
const anticipate = (p)=>(p *= 2) < 1 ? 0.5 * (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["backIn"])(p) : 0.5 * (2 - Math.pow(2, -10 * (p - 1)));
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/circ.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "circIn",
    ()=>circIn,
    "circInOut",
    ()=>circInOut,
    "circOut",
    ()=>circOut
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$mirror$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/modifiers/mirror.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$reverse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/modifiers/reverse.mjs [app-client] (ecmascript)");
;
;
const circIn = (p)=>1 - Math.sin(Math.acos(p));
const circOut = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$reverse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reverseEasing"])(circIn);
const circInOut = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$mirror$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mirrorEasing"])(circIn);
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/utils/is-bezier-definition.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isBezierDefinition",
    ()=>isBezierDefinition
]);
const isBezierDefinition = (easing)=>Array.isArray(easing) && typeof easing[0] === "number";
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/utils/map.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "easingDefinitionToFunction",
    ()=>easingDefinitionToFunction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$errors$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/errors.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$noop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/noop.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$anticipate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/anticipate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/back.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$circ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/circ.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/cubic-bezier.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$ease$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/ease.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$utils$2f$is$2d$bezier$2d$definition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/easing/utils/is-bezier-definition.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
const easingLookup = {
    linear: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$noop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"],
    easeIn: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$ease$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["easeIn"],
    easeInOut: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$ease$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["easeInOut"],
    easeOut: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$ease$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["easeOut"],
    circIn: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$circ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["circIn"],
    circInOut: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$circ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["circInOut"],
    circOut: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$circ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["circOut"],
    backIn: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["backIn"],
    backInOut: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["backInOut"],
    backOut: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["backOut"],
    anticipate: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$anticipate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["anticipate"]
};
const isValidEasing = (easing)=>{
    return typeof easing === "string";
};
const easingDefinitionToFunction = (definition)=>{
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$utils$2f$is$2d$bezier$2d$definition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBezierDefinition"])(definition)) {
        // If cubic bezier definition, create bezier curve
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$errors$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(definition.length === 4, "Cubic bezier arrays must contain four numerical values.", "cubic-bezier-length");
        const [x1, y1, x2, y2] = definition;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cubicBezier"])(x1, y1, x2, y2);
    } else if (isValidEasing(definition)) {
        // Else lookup from table
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$errors$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(easingLookup[definition] !== undefined, "Invalid easing type '".concat(definition, "'"), "invalid-easing-type");
        return easingLookup[definition];
    }
    return definition;
};
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/progress.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
  Progress within given range

  Given a lower limit and an upper limit, we return the progress
  (expressed as a number 0-1) represented by the given value, and
  limit that progress to within 0-1.

  @param [number]: Lower limit
  @param [number]: Upper limit
  @param [number]: Value to find progress within given range
  @return [number]: Progress of value within range as expressed 0-1
*/ /*#__NO_SIDE_EFFECTS__*/ __turbopack_context__.s([
    "progress",
    ()=>progress
]);
const progress = (from, to, value)=>{
    const toFromDifference = to - from;
    return toFromDifference === 0 ? 1 : (value - from) / toFromDifference;
};
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/memo.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*#__NO_SIDE_EFFECTS__*/ __turbopack_context__.s([
    "memo",
    ()=>memo
]);
function memo(callback) {
    let result;
    return ()=>{
        if (result === undefined) result = callback();
        return result;
    };
}
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/is-object.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isObject",
    ()=>isObject
]);
function isObject(value) {
    return typeof value === "object" && value !== null;
}
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/is-numerical-string.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Check if value is a numerical string, ie a string that is purely a number eg "100" or "-100.1"
 */ __turbopack_context__.s([
    "isNumericalString",
    ()=>isNumericalString
]);
const isNumericalString = (v)=>/^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(v);
;
}),
"[project]/next-admin-dashboard/node_modules/motion-utils/dist/es/is-zero-value-string.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Check if the value is a zero value string like "0px" or "0%"
 */ __turbopack_context__.s([
    "isZeroValueString",
    ()=>isZeroValueString
]);
const isZeroValueString = (v)=>/^0[^.\s]+$/u.test(v);
;
}),
"[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/chunk-GQLG7IS2.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>a,
    "b",
    ()=>u,
    "c",
    ()=>h,
    "d",
    ()=>x,
    "e",
    ()=>k,
    "f",
    ()=>A,
    "g",
    ()=>d,
    "h",
    ()=>c,
    "i",
    ()=>O,
    "j",
    ()=>g,
    "k",
    ()=>p
]);
var y = /\s+/g, a = (t)=>typeof t != "string" || !t ? t : t.replace(y, " ").trim(), u = function() {
    for(var _len = arguments.length, t = new Array(_len), _key = 0; _key < _len; _key++){
        t[_key] = arguments[_key];
    }
    let r = [], n = (e)=>{
        if (!e && e !== 0 && e !== 0n) return;
        if (Array.isArray(e)) {
            for(let s = 0, o = e.length; s < o; s++)n(e[s]);
            return;
        }
        let f = typeof e;
        if (f === "string" || f === "number" || f === "bigint") {
            if (f === "number" && e !== e) return;
            r.push(String(e));
        } else if (f === "object") {
            let s = Object.keys(e);
            for(let o = 0, i = s.length; o < i; o++){
                let l = s[o];
                e[l] && r.push(l);
            }
        }
    };
    for(let e = 0, f = t.length; e < f; e++){
        let s = t[e];
        s != null && n(s);
    }
    return r.length > 0 ? a(r.join(" ")) : void 0;
}, h = (t)=>t === false ? "false" : t === true ? "true" : t === 0 ? "0" : t, x = (t)=>{
    if (!t || typeof t != "object") return true;
    for(let r in t)return false;
    return true;
}, k = (t, r)=>{
    if (t === r) return true;
    if (!t || !r) return false;
    let n = Object.keys(t), e = Object.keys(r);
    if (n.length !== e.length) return false;
    for(let f = 0; f < n.length; f++){
        let s = n[f];
        if (!e.includes(s) || t[s] !== r[s]) return false;
    }
    return true;
}, A = (t)=>t === true || t === false, d = (t, r)=>{
    for(let n in r)if (Object.prototype.hasOwnProperty.call(r, n)) {
        let e = r[n];
        n in t ? t[n] = u(t[n], e) : t[n] = e;
    }
    return t;
}, c = (t, r)=>{
    for(let n = 0; n < t.length; n++){
        let e = t[n];
        Array.isArray(e) ? c(e, r) : e && r.push(e);
    }
};
function O(t) {
    let r = [];
    return c(t, r), r;
}
var g = function() {
    for(var _len = arguments.length, t = new Array(_len), _key = 0; _key < _len; _key++){
        t[_key] = arguments[_key];
    }
    let r = [];
    c(t, r);
    let n = [];
    for(let e = 0; e < r.length; e++)r[e] && n.push(r[e]);
    return n;
}, p = (t, r)=>{
    let n = {};
    for(let e in t){
        let f = t[e];
        if (e in r) {
            let s = r[e];
            Array.isArray(f) || Array.isArray(s) ? n[e] = g(s, f) : typeof f == "object" && typeof s == "object" && f && s ? n[e] = p(f, s) : n[e] = s + " " + f;
        } else n[e] = f;
    }
    for(let e in r)e in t || (n[e] = r[e]);
    return n;
};
;
}),
"[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/chunk-IFWU2MEM.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>Q,
    "b",
    ()=>S,
    "c",
    ()=>le
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/chunk-GQLG7IS2.js [app-client] (ecmascript)");
;
var Q = {
    twMerge: true,
    twMergeConfig: {},
    responsiveVariants: false
};
function ne() {
    let b = null, w = {}, A = false;
    return {
        get cachedTwMerge () {
            return b;
        },
        set cachedTwMerge (u){
            b = u;
        },
        get cachedTwMergeConfig () {
            return w;
        },
        set cachedTwMergeConfig (u){
            w = u;
        },
        get didTwMergeConfigChange () {
            return A;
        },
        set didTwMergeConfigChange (u){
            A = u;
        },
        reset () {
            b = null, w = {}, A = false;
        }
    };
}
var S = ne();
var le = (b$1)=>{
    let w = (u1, $)=>{
        let { extend: c$1 = null, slots: M = {}, variants: q = {}, compoundVariants: L = [], compoundSlots: v = [], defaultVariants: U = {} } = u1, d$1 = {
            ...Q,
            ...$
        }, x = (c$1 === null || c$1 === void 0 ? void 0 : c$1.base) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(c$1.base, u1 === null || u1 === void 0 ? void 0 : u1.base) : u1 === null || u1 === void 0 ? void 0 : u1.base, p = (c$1 === null || c$1 === void 0 ? void 0 : c$1.variants) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(c$1.variants) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["k"])(q, c$1.variants) : q, E = (c$1 === null || c$1 === void 0 ? void 0 : c$1.defaultVariants) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(c$1.defaultVariants) ? {
            ...c$1.defaultVariants,
            ...U
        } : U;
        !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(d$1.twMergeConfig) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["e"])(d$1.twMergeConfig, S.cachedTwMergeConfig) && (S.didTwMergeConfigChange = true, S.cachedTwMergeConfig = d$1.twMergeConfig);
        let N = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(c$1 === null || c$1 === void 0 ? void 0 : c$1.slots), O = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(M) ? {} : {
            base: (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(u1 === null || u1 === void 0 ? void 0 : u1.base, N && (c$1 === null || c$1 === void 0 ? void 0 : c$1.base)),
            ...M
        }, j$1 = N ? O : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["g"])({
            ...c$1 === null || c$1 === void 0 ? void 0 : c$1.slots
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(O) ? {
            base: u1 === null || u1 === void 0 ? void 0 : u1.base
        } : O), T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(c$1 === null || c$1 === void 0 ? void 0 : c$1.compoundVariants) ? L : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["j"])(c$1 === null || c$1 === void 0 ? void 0 : c$1.compoundVariants, L), y = (h)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(p) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(M) && N) return b$1(x, h === null || h === void 0 ? void 0 : h.class, h === null || h === void 0 ? void 0 : h.className)(d$1);
            if (T && !Array.isArray(T)) throw new TypeError('The "compoundVariants" prop must be an array. Received: '.concat(typeof T));
            if (v && !Array.isArray(v)) throw new TypeError('The "compoundSlots" prop must be an array. Received: '.concat(typeof v));
            let Y = function(t, e) {
                let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [], a$1 = arguments.length > 3 ? arguments[3] : void 0;
                let r = n;
                if (typeof e == "string") {
                    let i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(e).split(" ");
                    for(let l = 0; l < i.length; l++)r.push("".concat(t, ":").concat(i[l]));
                } else if (Array.isArray(e)) for(let s = 0; s < e.length; s++)r.push("".concat(t, ":").concat(e[s]));
                else if (typeof e == "object" && typeof a$1 == "string" && a$1 in e) {
                    let s = e[a$1];
                    if (s && typeof s == "string") {
                        let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(s).split(" "), f = [];
                        for(let o = 0; o < l.length; o++)f.push("".concat(t, ":").concat(l[o]));
                        r[a$1] = r[a$1] ? r[a$1].concat(f) : f;
                    } else if (Array.isArray(s) && s.length > 0) {
                        let i = [];
                        for(let l = 0; l < s.length; l++)i.push("".concat(t, ":").concat(s[l]));
                        r[a$1] = i;
                    }
                }
                return r;
            }, W = function(t) {
                let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : p, n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null;
                let r = e[t];
                if (!r || (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(r)) return null;
                var _a_t;
                let s = (_a_t = a === null || a === void 0 ? void 0 : a[t]) !== null && _a_t !== void 0 ? _a_t : h === null || h === void 0 ? void 0 : h[t];
                if (s === null) return null;
                let i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(s), l = Array.isArray(d$1.responsiveVariants) && d$1.responsiveVariants.length > 0 || d$1.responsiveVariants === true, f = E === null || E === void 0 ? void 0 : E[t], o = [];
                if (typeof i == "object" && l) for (let [C, H] of Object.entries(i)){
                    let te = r[H];
                    if (C === "initial") {
                        f = H;
                        continue;
                    }
                    Array.isArray(d$1.responsiveVariants) && !d$1.responsiveVariants.includes(C) || (o = Y(C, te, o, n));
                }
                let V = i != null && typeof i != "object" ? i : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(f), m = r[V || "false"];
                return typeof o == "object" && typeof n == "string" && o[n] ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["g"])(o, m) : o.length > 0 ? (o.push(m), n === "base" ? o.join(" ") : o) : m;
            }, Z = ()=>{
                if (!p) return null;
                let t = Object.keys(p), e = [];
                for(let n = 0; n < t.length; n++){
                    let a = W(t[n], p);
                    a && e.push(a);
                }
                return e;
            }, _ = (t, e)=>{
                if (!p || typeof p != "object") return null;
                let n = [];
                for(let a in p){
                    let r = W(a, p, t, e), s = t === "base" && typeof r == "string" ? r : r && r[t];
                    s && n.push(s);
                }
                return n;
            }, z = {};
            for(let t in h){
                let e = h[t];
                e !== void 0 && (z[t] = e);
            }
            let D = (t, e)=>{
                var _h_t;
                let n = typeof (h === null || h === void 0 ? void 0 : h[t]) == "object" ? {
                    [t]: (_h_t = h[t]) === null || _h_t === void 0 ? void 0 : _h_t.initial
                } : {};
                return {
                    ...E,
                    ...z,
                    ...n,
                    ...e
                };
            }, G = function() {
                let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], e = arguments.length > 1 ? arguments[1] : void 0;
                let n = [], a = t.length;
                for(let r = 0; r < a; r++){
                    let { class: s, className: i, ...l } = t[r], f = true, o = D(null, e);
                    for(let V in l){
                        let m = l[V], C = o[V];
                        if (Array.isArray(m)) {
                            if (!m.includes(C)) {
                                f = false;
                                break;
                            }
                        } else {
                            if ((m == null || m === false) && (C == null || C === false)) continue;
                            if (C !== m) {
                                f = false;
                                break;
                            }
                        }
                    }
                    f && (s && n.push(s), i && n.push(i));
                }
                return n;
            }, K = (t)=>{
                let e = G(T, t);
                if (!Array.isArray(e)) return e;
                let n = {}, a = b$1;
                for(let r = 0; r < e.length; r++){
                    let s = e[r];
                    if (typeof s == "string") n.base = a(n.base, s)(d$1);
                    else if (typeof s == "object") for(let i in s)n[i] = a(n[i], s[i])(d$1);
                }
                return n;
            }, ee = (t)=>{
                if (v.length < 1) return null;
                let e = {}, n = D(null, t);
                for(let a = 0; a < v.length; a++){
                    let { slots: r = [], class: s, className: i, ...l } = v[a];
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(l)) {
                        let f = true;
                        for(let o in l){
                            let V = n[o], m = l[o];
                            if (V === void 0 || (Array.isArray(m) ? !m.includes(V) : m !== V)) {
                                f = false;
                                break;
                            }
                        }
                        if (!f) continue;
                    }
                    for(let f = 0; f < r.length; f++){
                        let o = r[f];
                        e[o] || (e[o] = []), e[o].push([
                            s,
                            i
                        ]);
                    }
                }
                return e;
            };
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(M) || !N) {
                let t = {};
                if (typeof j$1 == "object" && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(j$1)) {
                    let e = b$1;
                    for(let n in j$1)t[n] = (a)=>{
                        let r = K(a), s = ee(a);
                        return e(j$1[n], _(n, a), ("TURBOPACK compile-time truthy", 1) ? r[n] : "TURBOPACK unreachable", s ? s[n] : void 0, a === null || a === void 0 ? void 0 : a.class, a === null || a === void 0 ? void 0 : a.className)(d$1);
                    };
                }
                return t;
            }
            return b$1(x, Z(), G(T), h === null || h === void 0 ? void 0 : h.class, h === null || h === void 0 ? void 0 : h.className)(d$1);
        }, X = ()=>{
            if (!(!p || typeof p != "object")) return Object.keys(p);
        };
        return y.variantKeys = X(), y.extend = c$1, y.base = x, y.slots = j$1, y.variants = p, y.defaultVariants = E, y.compoundSlots = v, y.compoundVariants = T, y;
    };
    return {
        tv: w,
        createTV: (u1)=>($, c)=>w($, c ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["k"])(u1, c) : u1)
    };
};
;
}),
"[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>i,
    "createTV",
    ()=>C,
    "tv",
    ()=>T
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/chunk-IFWU2MEM.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/chunk-GQLG7IS2.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
;
;
;
var f = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(e) ? __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"] : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extendTailwindMerge"])({
        ...e,
        extend: {
            theme: e.theme,
            classGroups: e.classGroups,
            conflictingClassGroupModifiers: e.conflictingClassGroupModifiers,
            conflictingClassGroups: e.conflictingClassGroups,
            ...e.extend
        }
    }), i = function() {
    for(var _len = arguments.length, e = new Array(_len), _key = 0; _key < _len; _key++){
        e[_key] = arguments[_key];
    }
    return (a)=>{
        let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(e);
        return !t || !a.twMerge ? t : ((!__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"].cachedTwMerge || __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"].didTwMergeConfigChange) && (__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"].didTwMergeConfigChange = false, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"].cachedTwMerge = f(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"].cachedTwMergeConfig)), __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"].cachedTwMerge(t) || void 0);
    };
};
var { createTV: C, tv: T } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(i);
;
}),
"[project]/next-admin-dashboard/node_modules/clsx/dist/clsx.m.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clsx",
    ()=>clsx,
    "default",
    ()=>__TURBOPACK__default__export__
]);
function r(e) {
    var t, f, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e) if (Array.isArray(e)) for(t = 0; t < e.length; t++)e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
    else for(t in e)e[t] && (n && (n += " "), n += t);
    return n;
}
function clsx() {
    for(var e, t, f = 0, n = ""; f < arguments.length;)(e = arguments[f++]) && (t = r(e)) && (n && (n += " "), n += t);
    return n;
}
const __TURBOPACK__default__export__ = clsx;
}),
"[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_class_apply_descriptor_get.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_apply_descriptor_get
]);
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);
    return descriptor.value;
}
;
}),
"[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_extract_field_descriptor
]);
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");
    return privateMap.get(receiver);
}
;
}),
"[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_class_private_field_get.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_private_field_get
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_apply_descriptor_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_class_apply_descriptor_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_extract_field_descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js [app-client] (ecmascript)");
;
;
function _class_private_field_get(receiver, privateMap) {
    var descriptor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_extract_field_descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(receiver, privateMap, "get");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_apply_descriptor_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(receiver, descriptor);
}
;
}),
"[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_check_private_redeclaration.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_check_private_redeclaration
]);
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
;
}),
"[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_class_private_field_init.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_private_field_init
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_check_private_redeclaration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_check_private_redeclaration.js [app-client] (ecmascript)");
;
function _class_private_field_init(obj, privateMap, value) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_check_private_redeclaration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(obj, privateMap);
    privateMap.set(obj, value);
}
;
}),
"[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_class_apply_descriptor_set.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_apply_descriptor_set
]);
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            // This should only throw in strict mode, but class bodies are
            // always strict and private fields can only be used inside
            // class bodies.
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
;
}),
"[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_class_private_field_set.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_private_field_set
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_apply_descriptor_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_class_apply_descriptor_set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_extract_field_descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js [app-client] (ecmascript)");
;
;
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_extract_field_descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(receiver, privateMap, "set");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_apply_descriptor_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(receiver, descriptor, value);
    return value;
}
;
}),
"[project]/next-admin-dashboard/node_modules/compute-scroll-into-view/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "compute",
    ()=>r
]);
const t = (t)=>"object" == typeof t && null != t && 1 === t.nodeType, e = (t, e)=>(!e || "hidden" !== t) && "visible" !== t && "clip" !== t, n = (t, n)=>{
    if (t.clientHeight < t.scrollHeight || t.clientWidth < t.scrollWidth) {
        const o = getComputedStyle(t, null);
        return e(o.overflowY, n) || e(o.overflowX, n) || ((t)=>{
            const e = ((t)=>{
                if (!t.ownerDocument || !t.ownerDocument.defaultView) return null;
                try {
                    return t.ownerDocument.defaultView.frameElement;
                } catch (t) {
                    return null;
                }
            })(t);
            return !!e && (e.clientHeight < t.scrollHeight || e.clientWidth < t.scrollWidth);
        })(t);
    }
    return !1;
}, o = (t, e, n, o, l, r, i, s)=>r < t && i > e || r > t && i < e ? 0 : r <= t && s <= n || i >= e && s >= n ? r - t - o : i > e && s < n || r < t && s > n ? i - e + l : 0, l = (t)=>{
    const e = t.parentElement;
    return null == e ? t.getRootNode().host || null : e;
}, r = (e, r)=>{
    var i, s, d, h;
    if ("undefined" == typeof document) return [];
    const { scrollMode: c, block: f, inline: u, boundary: a, skipOverflowHiddenElements: g } = r, p = "function" == typeof a ? a : (t)=>t !== a;
    if (!t(e)) throw new TypeError("Invalid target");
    const m = document.scrollingElement || document.documentElement, w = [];
    let W = e;
    for(; t(W) && p(W);){
        if (W = l(W), W === m) {
            w.push(W);
            break;
        }
        null != W && W === document.body && n(W) && !n(document.documentElement) || null != W && n(W, g) && w.push(W);
    }
    const b = null != (s = null == (i = window.visualViewport) ? void 0 : i.width) ? s : innerWidth, H = null != (h = null == (d = window.visualViewport) ? void 0 : d.height) ? h : innerHeight, { scrollX: y, scrollY: M } = window, { height: v, width: E, top: x, right: C, bottom: I, left: R } = e.getBoundingClientRect(), { top: T, right: B, bottom: F, left: V } = ((t)=>{
        const e = window.getComputedStyle(t);
        return {
            top: parseFloat(e.scrollMarginTop) || 0,
            right: parseFloat(e.scrollMarginRight) || 0,
            bottom: parseFloat(e.scrollMarginBottom) || 0,
            left: parseFloat(e.scrollMarginLeft) || 0
        };
    })(e);
    let k = "start" === f || "nearest" === f ? x - T : "end" === f ? I + F : x + v / 2 - T + F, D = "center" === u ? R + E / 2 - V + B : "end" === u ? C + B : R - V;
    const L = [];
    for(let t = 0; t < w.length; t++){
        const e = w[t], { height: l, width: r, top: i, right: s, bottom: d, left: h } = e.getBoundingClientRect();
        if ("if-needed" === c && x >= 0 && R >= 0 && I <= H && C <= b && (e === m && !n(e) || x >= i && I <= d && R >= h && C <= s)) return L;
        const a = getComputedStyle(e), g = parseInt(a.borderLeftWidth, 10), p = parseInt(a.borderTopWidth, 10), W = parseInt(a.borderRightWidth, 10), T = parseInt(a.borderBottomWidth, 10);
        let B = 0, F = 0;
        const V = "offsetWidth" in e ? e.offsetWidth - e.clientWidth - g - W : 0, S = "offsetHeight" in e ? e.offsetHeight - e.clientHeight - p - T : 0, X = "offsetWidth" in e ? 0 === e.offsetWidth ? 0 : r / e.offsetWidth : 0, Y = "offsetHeight" in e ? 0 === e.offsetHeight ? 0 : l / e.offsetHeight : 0;
        if (m === e) B = "start" === f ? k : "end" === f ? k - H : "nearest" === f ? o(M, M + H, H, p, T, M + k, M + k + v, v) : k - H / 2, F = "start" === u ? D : "center" === u ? D - b / 2 : "end" === u ? D - b : o(y, y + b, b, g, W, y + D, y + D + E, E), B = Math.max(0, B + M), F = Math.max(0, F + y);
        else {
            B = "start" === f ? k - i - p : "end" === f ? k - d + T + S : "nearest" === f ? o(i, d, l, p, T + S, k, k + v, v) : k - (i + l / 2) + S / 2, F = "start" === u ? D - h - g : "center" === u ? D - (h + r / 2) + V / 2 : "end" === u ? D - s + W + V : o(h, s, r, g, W + V, D, D + E, E);
            const { scrollLeft: t, scrollTop: n } = e;
            B = 0 === Y ? 0 : Math.max(0, Math.min(n + B / Y, e.scrollHeight - l / Y + S)), F = 0 === X ? 0 : Math.max(0, Math.min(t + F / X, e.scrollWidth - r / X + V)), k += n - B, D += t - F;
        }
        L.push({
            el: e,
            top: B,
            left: F
        });
    }
    return L;
};
;
 //# sourceMappingURL=index.js.map
}),
"[project]/next-admin-dashboard/node_modules/scroll-into-view-if-needed/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>t
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$compute$2d$scroll$2d$into$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/compute-scroll-into-view/dist/index.js [app-client] (ecmascript)");
;
const o = (e)=>!1 === e ? {
        block: "end",
        inline: "nearest"
    } : ((e)=>e === Object(e) && 0 !== Object.keys(e).length)(e) ? e : {
        block: "start",
        inline: "nearest"
    };
function t(t, n) {
    if (!t.isConnected || !((e)=>{
        let o = e;
        for(; o && o.parentNode;){
            if (o.parentNode === document) return !0;
            o = o.parentNode instanceof ShadowRoot ? o.parentNode.host : o.parentNode;
        }
        return !1;
    })(t)) return;
    if (((e)=>"object" == typeof e && "function" == typeof e.behavior)(n)) return n.behavior((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$compute$2d$scroll$2d$into$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compute"])(t, n));
    const r = "boolean" == typeof n || null == n ? void 0 : n.behavior;
    for (const { el: i, top: a, left: l } of (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$compute$2d$scroll$2d$into$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compute"])(t, o(n)))i.scroll({
        top: a,
        left: l,
        behavior: r
    });
}
;
 //# sourceMappingURL=index.js.map
}),
"[project]/next-admin-dashboard/node_modules/@internationalized/number/dist/NumberFormatter.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ __turbopack_context__.s([
    "NumberFormatter",
    ()=>$488c6ddbf4ef74c2$export$cc77c4ff7e8673c5,
    "numberFormatSignDisplayPolyfill",
    ()=>$488c6ddbf4ef74c2$export$711b50b3c525e0f2
]);
let $488c6ddbf4ef74c2$var$formatterCache = new Map();
let $488c6ddbf4ef74c2$var$supportsSignDisplay = false;
try {
    $488c6ddbf4ef74c2$var$supportsSignDisplay = new Intl.NumberFormat('de-DE', {
        signDisplay: 'exceptZero'
    }).resolvedOptions().signDisplay === 'exceptZero';
// eslint-disable-next-line no-empty
} catch (e) {}
let $488c6ddbf4ef74c2$var$supportsUnit = false;
try {
    $488c6ddbf4ef74c2$var$supportsUnit = new Intl.NumberFormat('de-DE', {
        style: 'unit',
        unit: 'degree'
    }).resolvedOptions().style === 'unit';
// eslint-disable-next-line no-empty
} catch (e) {}
// Polyfill for units since Safari doesn't support them yet. See https://bugs.webkit.org/show_bug.cgi?id=215438.
// Currently only polyfilling the unit degree in narrow format for ColorSlider in our supported locales.
// Values were determined by switching to each locale manually in Chrome.
const $488c6ddbf4ef74c2$var$UNITS = {
    degree: {
        narrow: {
            default: "\xb0",
            'ja-JP': " \u5EA6",
            'zh-TW': "\u5EA6",
            'sl-SI': " \xb0"
        }
    }
};
class $488c6ddbf4ef74c2$export$cc77c4ff7e8673c5 {
    /** Formats a number value as a string, according to the locale and options provided to the constructor. */ format(value) {
        let res = '';
        if (!$488c6ddbf4ef74c2$var$supportsSignDisplay && this.options.signDisplay != null) res = $488c6ddbf4ef74c2$export$711b50b3c525e0f2(this.numberFormatter, this.options.signDisplay, value);
        else res = this.numberFormatter.format(value);
        if (this.options.style === 'unit' && !$488c6ddbf4ef74c2$var$supportsUnit) {
            var _UNITS_unit;
            let { unit: unit, unitDisplay: unitDisplay = 'short', locale: locale } = this.resolvedOptions();
            if (!unit) return res;
            let values = (_UNITS_unit = $488c6ddbf4ef74c2$var$UNITS[unit]) === null || _UNITS_unit === void 0 ? void 0 : _UNITS_unit[unitDisplay];
            res += values[locale] || values.default;
        }
        return res;
    }
    /** Formats a number to an array of parts such as separators, digits, punctuation, and more. */ formatToParts(value) {
        // TODO: implement signDisplay for formatToParts
        return this.numberFormatter.formatToParts(value);
    }
    /** Formats a number range as a string. */ formatRange(start, end) {
        if (typeof this.numberFormatter.formatRange === 'function') return this.numberFormatter.formatRange(start, end);
        if (end < start) throw new RangeError('End date must be >= start date');
        // Very basic fallback for old browsers.
        return "".concat(this.format(start), " – ").concat(this.format(end));
    }
    /** Formats a number range as an array of parts. */ formatRangeToParts(start, end) {
        if (typeof this.numberFormatter.formatRangeToParts === 'function') return this.numberFormatter.formatRangeToParts(start, end);
        if (end < start) throw new RangeError('End date must be >= start date');
        let startParts = this.numberFormatter.formatToParts(start);
        let endParts = this.numberFormatter.formatToParts(end);
        return [
            ...startParts.map((p)=>({
                    ...p,
                    source: 'startRange'
                })),
            {
                type: 'literal',
                value: " \u2013 ",
                source: 'shared'
            },
            ...endParts.map((p)=>({
                    ...p,
                    source: 'endRange'
                }))
        ];
    }
    /** Returns the resolved formatting options based on the values passed to the constructor. */ resolvedOptions() {
        let options = this.numberFormatter.resolvedOptions();
        if (!$488c6ddbf4ef74c2$var$supportsSignDisplay && this.options.signDisplay != null) options = {
            ...options,
            signDisplay: this.options.signDisplay
        };
        if (!$488c6ddbf4ef74c2$var$supportsUnit && this.options.style === 'unit') options = {
            ...options,
            style: 'unit',
            unit: this.options.unit,
            unitDisplay: this.options.unitDisplay
        };
        return options;
    }
    constructor(locale, options = {}){
        this.numberFormatter = $488c6ddbf4ef74c2$var$getCachedNumberFormatter(locale, options);
        this.options = options;
    }
}
function $488c6ddbf4ef74c2$var$getCachedNumberFormatter(locale) {
    let options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    let { numberingSystem: numberingSystem } = options;
    if (numberingSystem && locale.includes('-nu-')) {
        if (!locale.includes('-u-')) locale += '-u-';
        locale += "-nu-".concat(numberingSystem);
    }
    if (options.style === 'unit' && !$488c6ddbf4ef74c2$var$supportsUnit) {
        var _UNITS_unit;
        let { unit: unit, unitDisplay: unitDisplay = 'short' } = options;
        if (!unit) throw new Error('unit option must be provided with style: "unit"');
        if (!((_UNITS_unit = $488c6ddbf4ef74c2$var$UNITS[unit]) === null || _UNITS_unit === void 0 ? void 0 : _UNITS_unit[unitDisplay])) throw new Error("Unsupported unit ".concat(unit, " with unitDisplay = ").concat(unitDisplay));
        options = {
            ...options,
            style: 'decimal'
        };
    }
    let cacheKey = locale + (options ? Object.entries(options).sort((a, b)=>a[0] < b[0] ? -1 : 1).join() : '');
    if ($488c6ddbf4ef74c2$var$formatterCache.has(cacheKey)) return $488c6ddbf4ef74c2$var$formatterCache.get(cacheKey);
    let numberFormatter = new Intl.NumberFormat(locale, options);
    $488c6ddbf4ef74c2$var$formatterCache.set(cacheKey, numberFormatter);
    return numberFormatter;
}
function $488c6ddbf4ef74c2$export$711b50b3c525e0f2(numberFormat, signDisplay, num) {
    if (signDisplay === 'auto') return numberFormat.format(num);
    else if (signDisplay === 'never') return numberFormat.format(Math.abs(num));
    else {
        let needsPositiveSign = false;
        if (signDisplay === 'always') needsPositiveSign = num > 0 || Object.is(num, 0);
        else if (signDisplay === 'exceptZero') {
            if (Object.is(num, -0) || Object.is(num, 0)) num = Math.abs(num);
            else needsPositiveSign = num > 0;
        }
        if (needsPositiveSign) {
            let negative = numberFormat.format(-num);
            let noSign = numberFormat.format(num);
            // ignore RTL/LTR marker character
            let minus = negative.replace(noSign, '').replace(/\u200e|\u061C/, '');
            if ([
                ...minus
            ].length !== 1) console.warn('@react-aria/i18n polyfill for NumberFormat signDisplay: Unsupported case');
            let positive = negative.replace(noSign, '!!!').replace(minus, '+').replace('!!!', noSign);
            return positive;
        } else return numberFormat.format(num);
    }
}
;
 //# sourceMappingURL=NumberFormatter.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@internationalized/number/dist/NumberParser.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NumberParser",
    ()=>$6c7bd7858deea686$export$cd11ab140839f11d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$number$2f$dist$2f$NumberFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@internationalized/number/dist/NumberFormatter.mjs [app-client] (ecmascript)");
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ const $6c7bd7858deea686$var$CURRENCY_SIGN_REGEX = new RegExp('^.*\\(.*\\).*$');
const $6c7bd7858deea686$var$NUMBERING_SYSTEMS = [
    'latn',
    'arab',
    'hanidec',
    'deva',
    'beng',
    'fullwide'
];
class $6c7bd7858deea686$export$cd11ab140839f11d {
    /**
   * Parses the given string to a number. Returns NaN if a valid number could not be parsed.
   */ parse(value) {
        return $6c7bd7858deea686$var$getNumberParserImpl(this.locale, this.options, value).parse(value);
    }
    /**
   * Returns whether the given string could potentially be a valid number. This should be used to
   * validate user input as the user types. If a `minValue` or `maxValue` is provided, the validity
   * of the minus/plus sign characters can be checked.
   */ isValidPartialNumber(value, minValue, maxValue) {
        return $6c7bd7858deea686$var$getNumberParserImpl(this.locale, this.options, value).isValidPartialNumber(value, minValue, maxValue);
    }
    /**
   * Returns a numbering system for which the given string is valid in the current locale.
   * If no numbering system could be detected, the default numbering system for the current
   * locale is returned.
   */ getNumberingSystem(value) {
        return $6c7bd7858deea686$var$getNumberParserImpl(this.locale, this.options, value).options.numberingSystem;
    }
    constructor(locale, options = {}){
        this.locale = locale;
        this.options = options;
    }
}
const $6c7bd7858deea686$var$numberParserCache = new Map();
function $6c7bd7858deea686$var$getNumberParserImpl(locale, options, value) {
    // First try the default numbering system for the provided locale
    let defaultParser = $6c7bd7858deea686$var$getCachedNumberParser(locale, options);
    // If that doesn't match, and the locale doesn't include a hard coded numbering system,
    // try each of the other supported numbering systems until we find one that matches.
    if (!locale.includes('-nu-') && !defaultParser.isValidPartialNumber(value)) {
        for (let numberingSystem of $6c7bd7858deea686$var$NUMBERING_SYSTEMS)if (numberingSystem !== defaultParser.options.numberingSystem) {
            let parser = $6c7bd7858deea686$var$getCachedNumberParser(locale + (locale.includes('-u-') ? '-nu-' : '-u-nu-') + numberingSystem, options);
            if (parser.isValidPartialNumber(value)) return parser;
        }
    }
    return defaultParser;
}
function $6c7bd7858deea686$var$getCachedNumberParser(locale, options) {
    let cacheKey = locale + (options ? Object.entries(options).sort((a, b)=>a[0] < b[0] ? -1 : 1).join() : '');
    let parser = $6c7bd7858deea686$var$numberParserCache.get(cacheKey);
    if (!parser) {
        parser = new $6c7bd7858deea686$var$NumberParserImpl(locale, options);
        $6c7bd7858deea686$var$numberParserCache.set(cacheKey, parser);
    }
    return parser;
}
// The actual number parser implementation. Instances of this class are cached
// based on the locale, options, and detected numbering system.
class $6c7bd7858deea686$var$NumberParserImpl {
    parse(value) {
        // to parse the number, we need to remove anything that isn't actually part of the number, for example we want '-10.40' not '-10.40 USD'
        let fullySanitizedValue = this.sanitize(value);
        if (this.symbols.group) fullySanitizedValue = $6c7bd7858deea686$var$replaceAll(fullySanitizedValue, this.symbols.group, '');
        if (this.symbols.decimal) fullySanitizedValue = fullySanitizedValue.replace(this.symbols.decimal, '.');
        if (this.symbols.minusSign) fullySanitizedValue = fullySanitizedValue.replace(this.symbols.minusSign, '-');
        fullySanitizedValue = fullySanitizedValue.replace(this.symbols.numeral, this.symbols.index);
        if (this.options.style === 'percent') {
            // javascript is bad at dividing by 100 and maintaining the same significant figures, so perform it on the string before parsing
            let isNegative = fullySanitizedValue.indexOf('-');
            fullySanitizedValue = fullySanitizedValue.replace('-', '');
            fullySanitizedValue = fullySanitizedValue.replace('+', '');
            let index = fullySanitizedValue.indexOf('.');
            if (index === -1) index = fullySanitizedValue.length;
            fullySanitizedValue = fullySanitizedValue.replace('.', '');
            if (index - 2 === 0) fullySanitizedValue = "0.".concat(fullySanitizedValue);
            else if (index - 2 === -1) fullySanitizedValue = "0.0".concat(fullySanitizedValue);
            else if (index - 2 === -2) fullySanitizedValue = '0.00';
            else fullySanitizedValue = "".concat(fullySanitizedValue.slice(0, index - 2), ".").concat(fullySanitizedValue.slice(index - 2));
            if (isNegative > -1) fullySanitizedValue = "-".concat(fullySanitizedValue);
        }
        let newValue = fullySanitizedValue ? +fullySanitizedValue : NaN;
        if (isNaN(newValue)) return NaN;
        if (this.options.style === 'percent') {
            var _this_options_minimumFractionDigits, _this_options_maximumFractionDigits;
            // extra step for rounding percents to what our formatter would output
            let options = {
                ...this.options,
                style: 'decimal',
                minimumFractionDigits: Math.min(((_this_options_minimumFractionDigits = this.options.minimumFractionDigits) !== null && _this_options_minimumFractionDigits !== void 0 ? _this_options_minimumFractionDigits : 0) + 2, 20),
                maximumFractionDigits: Math.min(((_this_options_maximumFractionDigits = this.options.maximumFractionDigits) !== null && _this_options_maximumFractionDigits !== void 0 ? _this_options_maximumFractionDigits : 0) + 2, 20)
            };
            return new $6c7bd7858deea686$export$cd11ab140839f11d(this.locale, options).parse(new (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$internationalized$2f$number$2f$dist$2f$NumberFormatter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NumberFormatter"])(this.locale, options).format(newValue));
        }
        // accounting will always be stripped to a positive number, so if it's accounting and has a () around everything, then we need to make it negative again
        if (this.options.currencySign === 'accounting' && $6c7bd7858deea686$var$CURRENCY_SIGN_REGEX.test(value)) newValue = -1 * newValue;
        return newValue;
    }
    sanitize(value) {
        // Remove literals and whitespace, which are allowed anywhere in the string
        value = value.replace(this.symbols.literals, '');
        // Replace the ASCII minus sign with the minus sign used in the current locale
        // so that both are allowed in case the user's keyboard doesn't have the locale's minus sign.
        if (this.symbols.minusSign) value = value.replace('-', this.symbols.minusSign);
        // In arab numeral system, their decimal character is 1643, but most keyboards don't type that
        // instead they use the , (44) character or apparently the (1548) character.
        if (this.options.numberingSystem === 'arab') {
            if (this.symbols.decimal) {
                value = value.replace(',', this.symbols.decimal);
                value = value.replace(String.fromCharCode(1548), this.symbols.decimal);
            }
            if (this.symbols.group) value = $6c7bd7858deea686$var$replaceAll(value, '.', this.symbols.group);
        }
        // In some locale styles, such as swiss currency, the group character can be a special single quote
        // that keyboards don't typically have. This expands the character to include the easier to type single quote.
        if (this.symbols.group === "\u2019" && value.includes("'")) value = $6c7bd7858deea686$var$replaceAll(value, "'", this.symbols.group);
        // fr-FR group character is narrow non-breaking space, char code 8239 (U+202F), but that's not a key on the french keyboard,
        // so allow space and non-breaking space as a group char as well
        if (this.options.locale === 'fr-FR' && this.symbols.group) {
            value = $6c7bd7858deea686$var$replaceAll(value, ' ', this.symbols.group);
            value = $6c7bd7858deea686$var$replaceAll(value, /\u00A0/g, this.symbols.group);
        }
        return value;
    }
    isValidPartialNumber(value) {
        let minValue = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : -Infinity, maxValue = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Infinity;
        value = this.sanitize(value);
        // Remove minus or plus sign, which must be at the start of the string.
        if (this.symbols.minusSign && value.startsWith(this.symbols.minusSign) && minValue < 0) value = value.slice(this.symbols.minusSign.length);
        else if (this.symbols.plusSign && value.startsWith(this.symbols.plusSign) && maxValue > 0) value = value.slice(this.symbols.plusSign.length);
        // Numbers cannot start with a group separator
        if (this.symbols.group && value.startsWith(this.symbols.group)) return false;
        // Numbers that can't have any decimal values fail if a decimal character is typed
        if (this.symbols.decimal && value.indexOf(this.symbols.decimal) > -1 && this.options.maximumFractionDigits === 0) return false;
        // Remove numerals, groups, and decimals
        if (this.symbols.group) value = $6c7bd7858deea686$var$replaceAll(value, this.symbols.group, '');
        value = value.replace(this.symbols.numeral, '');
        if (this.symbols.decimal) value = value.replace(this.symbols.decimal, '');
        // The number is valid if there are no remaining characters
        return value.length === 0;
    }
    constructor(locale, options = {}){
        this.locale = locale;
        // see https://tc39.es/ecma402/#sec-setnfdigitoptions, when using roundingIncrement, the maximumFractionDigits and minimumFractionDigits must be equal
        // by default, they are 0 and 3 respectively, so we set them to 0 if neither are set
        if (options.roundingIncrement !== 1 && options.roundingIncrement != null) {
            if (options.maximumFractionDigits == null && options.minimumFractionDigits == null) {
                options.maximumFractionDigits = 0;
                options.minimumFractionDigits = 0;
            } else if (options.maximumFractionDigits == null) options.maximumFractionDigits = options.minimumFractionDigits;
            else if (options.minimumFractionDigits == null) options.minimumFractionDigits = options.maximumFractionDigits;
        // if both are specified, let the normal Range Error be thrown
        }
        this.formatter = new Intl.NumberFormat(locale, options);
        this.options = this.formatter.resolvedOptions();
        this.symbols = $6c7bd7858deea686$var$getSymbols(locale, this.formatter, this.options, options);
        var _this_options_minimumFractionDigits, _this_options_maximumFractionDigits;
        if (this.options.style === 'percent' && (((_this_options_minimumFractionDigits = this.options.minimumFractionDigits) !== null && _this_options_minimumFractionDigits !== void 0 ? _this_options_minimumFractionDigits : 0) > 18 || ((_this_options_maximumFractionDigits = this.options.maximumFractionDigits) !== null && _this_options_maximumFractionDigits !== void 0 ? _this_options_maximumFractionDigits : 0) > 18)) console.warn('NumberParser cannot handle percentages with greater than 18 decimal places, please reduce the number in your options.');
    }
}
const $6c7bd7858deea686$var$nonLiteralParts = new Set([
    'decimal',
    'fraction',
    'integer',
    'minusSign',
    'plusSign',
    'group'
]);
// This list is derived from https://www.unicode.org/cldr/charts/43/supplemental/language_plural_rules.html#comparison and includes
// all unique numbers which we need to check in order to determine all the plural forms for a given locale.
// See: https://github.com/adobe/react-spectrum/pull/5134/files#r1337037855 for used script
const $6c7bd7858deea686$var$pluralNumbers = [
    0,
    4,
    2,
    1,
    11,
    20,
    3,
    7,
    100,
    21,
    0.1,
    1.1
];
function $6c7bd7858deea686$var$getSymbols(locale, formatter, intlOptions, originalOptions) {
    var _allParts_find, _posAllParts_find, _decimalParts_find, _allParts_find1;
    // formatter needs access to all decimal places in order to generate the correct literal strings for the plural set
    let symbolFormatter = new Intl.NumberFormat(locale, {
        ...intlOptions,
        // Resets so we get the full range of symbols
        minimumSignificantDigits: 1,
        maximumSignificantDigits: 21,
        roundingIncrement: 1,
        roundingPriority: 'auto',
        roundingMode: 'halfExpand'
    });
    // Note: some locale's don't add a group symbol until there is a ten thousands place
    let allParts = symbolFormatter.formatToParts(-10000.111);
    let posAllParts = symbolFormatter.formatToParts(10000.111);
    let pluralParts = $6c7bd7858deea686$var$pluralNumbers.map((n)=>symbolFormatter.formatToParts(n));
    var _allParts_find_value;
    let minusSign = (_allParts_find_value = (_allParts_find = allParts.find((p)=>p.type === 'minusSign')) === null || _allParts_find === void 0 ? void 0 : _allParts_find.value) !== null && _allParts_find_value !== void 0 ? _allParts_find_value : '-';
    let plusSign = (_posAllParts_find = posAllParts.find((p)=>p.type === 'plusSign')) === null || _posAllParts_find === void 0 ? void 0 : _posAllParts_find.value;
    // Safari does not support the signDisplay option, but our number parser polyfills it.
    // If no plus sign was returned, but the original options contained signDisplay, default to the '+' character.
    if (!plusSign && ((originalOptions === null || originalOptions === void 0 ? void 0 : originalOptions.signDisplay) === 'exceptZero' || (originalOptions === null || originalOptions === void 0 ? void 0 : originalOptions.signDisplay) === 'always')) plusSign = '+';
    // If maximumSignificantDigits is 1 (the minimum) then we won't get decimal characters out of the above formatters
    // Percent also defaults to 0 fractionDigits, so we need to make a new one that isn't percent to get an accurate decimal
    let decimalParts = new Intl.NumberFormat(locale, {
        ...intlOptions,
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).formatToParts(0.001);
    let decimal = (_decimalParts_find = decimalParts.find((p)=>p.type === 'decimal')) === null || _decimalParts_find === void 0 ? void 0 : _decimalParts_find.value;
    let group = (_allParts_find1 = allParts.find((p)=>p.type === 'group')) === null || _allParts_find1 === void 0 ? void 0 : _allParts_find1.value;
    // this set is also for a regex, it's all literals that might be in the string we want to eventually parse that
    // don't contribute to the numerical value
    let allPartsLiterals = allParts.filter((p)=>!$6c7bd7858deea686$var$nonLiteralParts.has(p.type)).map((p)=>$6c7bd7858deea686$var$escapeRegex(p.value));
    let pluralPartsLiterals = pluralParts.flatMap((p)=>p.filter((p)=>!$6c7bd7858deea686$var$nonLiteralParts.has(p.type)).map((p)=>$6c7bd7858deea686$var$escapeRegex(p.value)));
    let sortedLiterals = [
        ...new Set([
            ...allPartsLiterals,
            ...pluralPartsLiterals
        ])
    ].sort((a, b)=>b.length - a.length);
    let literals = sortedLiterals.length === 0 ? new RegExp('[\\p{White_Space}]', 'gu') : new RegExp("".concat(sortedLiterals.join('|'), "|[\\p{White_Space}]"), 'gu');
    // These are for replacing non-latn characters with the latn equivalent
    let numerals = [
        ...new Intl.NumberFormat(intlOptions.locale, {
            useGrouping: false
        }).format(9876543210)
    ].reverse();
    let indexes = new Map(numerals.map((d, i)=>[
            d,
            i
        ]));
    let numeral = new RegExp("[".concat(numerals.join(''), "]"), 'g');
    let index = (d)=>String(indexes.get(d));
    return {
        minusSign: minusSign,
        plusSign: plusSign,
        decimal: decimal,
        group: group,
        literals: literals,
        numeral: numeral,
        index: index
    };
}
function $6c7bd7858deea686$var$replaceAll(str, find, replace) {
    if (str.replaceAll) return str.replaceAll(find, replace);
    return str.split(find).join(replace);
}
function $6c7bd7858deea686$var$escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
;
 //# sourceMappingURL=NumberParser.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@internationalized/string/dist/LocalizedStringDictionary.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Copyright 2022 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ __turbopack_context__.s([
    "LocalizedStringDictionary",
    ()=>$5b160d28a433310d$export$c17fa47878dc55b6
]);
const $5b160d28a433310d$var$localeSymbol = Symbol.for('react-aria.i18n.locale');
const $5b160d28a433310d$var$stringsSymbol = Symbol.for('react-aria.i18n.strings');
let $5b160d28a433310d$var$cachedGlobalStrings = undefined;
class $5b160d28a433310d$export$c17fa47878dc55b6 {
    /** Returns a localized string for the given key and locale. */ getStringForLocale(key, locale) {
        let strings = this.getStringsForLocale(locale);
        let string = strings[key];
        if (!string) throw new Error("Could not find intl message ".concat(key, " in ").concat(locale, " locale"));
        return string;
    }
    /** Returns all localized strings for the given locale. */ getStringsForLocale(locale) {
        let strings = this.strings[locale];
        if (!strings) {
            strings = $5b160d28a433310d$var$getStringsForLocale(locale, this.strings, this.defaultLocale);
            this.strings[locale] = strings;
        }
        return strings;
    }
    static getGlobalDictionaryForPackage(packageName) {
        if (typeof window === 'undefined') return null;
        let locale = window[$5b160d28a433310d$var$localeSymbol];
        if ($5b160d28a433310d$var$cachedGlobalStrings === undefined) {
            let globalStrings = window[$5b160d28a433310d$var$stringsSymbol];
            if (!globalStrings) return null;
            $5b160d28a433310d$var$cachedGlobalStrings = {};
            for(let pkg in globalStrings)$5b160d28a433310d$var$cachedGlobalStrings[pkg] = new $5b160d28a433310d$export$c17fa47878dc55b6({
                [locale]: globalStrings[pkg]
            }, locale);
        }
        let dictionary = $5b160d28a433310d$var$cachedGlobalStrings === null || $5b160d28a433310d$var$cachedGlobalStrings === void 0 ? void 0 : $5b160d28a433310d$var$cachedGlobalStrings[packageName];
        if (!dictionary) throw new Error('Strings for package "'.concat(packageName, '" were not included by LocalizedStringProvider. Please add it to the list passed to createLocalizedStringDictionary.'));
        return dictionary;
    }
    constructor(messages, defaultLocale = 'en-US'){
        // Clone messages so we don't modify the original object.
        // Filter out entries with falsy values which may have been caused by applying optimize-locales-plugin.
        this.strings = Object.fromEntries(Object.entries(messages).filter((param)=>{
            let [, v] = param;
            return v;
        }));
        this.defaultLocale = defaultLocale;
    }
}
function $5b160d28a433310d$var$getStringsForLocale(locale, strings) {
    let defaultLocale = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 'en-US';
    // If there is an exact match, use it.
    if (strings[locale]) return strings[locale];
    // Attempt to find the closest match by language.
    // For example, if the locale is fr-CA (French Canadian), but there is only
    // an fr-FR (France) set of strings, use that.
    // This could be replaced with Intl.LocaleMatcher once it is supported.
    // https://github.com/tc39/proposal-intl-localematcher
    let language = $5b160d28a433310d$var$getLanguage(locale);
    if (strings[language]) return strings[language];
    for(let key in strings){
        if (key.startsWith(language + '-')) return strings[key];
    }
    // Nothing close, use english.
    return strings[defaultLocale];
}
function $5b160d28a433310d$var$getLanguage(locale) {
    // @ts-ignore
    if (Intl.Locale) return new Intl.Locale(locale).language;
    return locale.split('-')[0];
}
;
 //# sourceMappingURL=LocalizedStringDictionary.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@internationalized/string/dist/LocalizedStringFormatter.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Copyright 2022 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ __turbopack_context__.s([
    "LocalizedStringFormatter",
    ()=>$6db58dc88e78b024$export$2f817fcdc4b89ae0
]);
const $6db58dc88e78b024$var$pluralRulesCache = new Map();
const $6db58dc88e78b024$var$numberFormatCache = new Map();
class $6db58dc88e78b024$export$2f817fcdc4b89ae0 {
    /** Formats a localized string for the given key with the provided variables. */ format(key, variables) {
        let message = this.strings.getStringForLocale(key, this.locale);
        return typeof message === 'function' ? message(variables, this) : message;
    }
    plural(count, options) {
        let type = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 'cardinal';
        let opt = options['=' + count];
        if (opt) return typeof opt === 'function' ? opt() : opt;
        let key = this.locale + ':' + type;
        let pluralRules = $6db58dc88e78b024$var$pluralRulesCache.get(key);
        if (!pluralRules) {
            pluralRules = new Intl.PluralRules(this.locale, {
                type: type
            });
            $6db58dc88e78b024$var$pluralRulesCache.set(key, pluralRules);
        }
        let selected = pluralRules.select(count);
        opt = options[selected] || options.other;
        return typeof opt === 'function' ? opt() : opt;
    }
    number(value) {
        let numberFormat = $6db58dc88e78b024$var$numberFormatCache.get(this.locale);
        if (!numberFormat) {
            numberFormat = new Intl.NumberFormat(this.locale);
            $6db58dc88e78b024$var$numberFormatCache.set(this.locale, numberFormat);
        }
        return numberFormat.format(value);
    }
    select(options, value) {
        let opt = options[value] || options.other;
        return typeof opt === 'function' ? opt() : opt;
    }
    constructor(locale, strings){
        this.locale = locale;
        this.strings = strings;
    }
}
;
 //# sourceMappingURL=LocalizedStringFormatter.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>_extends
]);
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : "TURBOPACK unreachable", _extends.apply(null, arguments);
}
;
}),
"[project]/next-admin-dashboard/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>_objectWithoutPropertiesLoose
]);
function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for(var n in r)if (({}).hasOwnProperty.call(r, n)) {
        if (-1 !== e.indexOf(n)) continue;
        t[n] = r[n];
    }
    return t;
}
;
}),
"[project]/next-admin-dashboard/node_modules/use-isomorphic-layout-effect/dist/use-isomorphic-layout-effect.browser.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>index
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var index = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"];
;
}),
"[project]/next-admin-dashboard/node_modules/use-latest/dist/use-latest.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useLatest
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$use$2d$isomorphic$2d$layout$2d$effect$2f$dist$2f$use$2d$isomorphic$2d$layout$2d$effect$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/use-isomorphic-layout-effect/dist/use-isomorphic-layout-effect.browser.esm.js [app-client] (ecmascript)");
;
;
var useLatest = function useLatest(value) {
    var ref = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(value);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$use$2d$isomorphic$2d$layout$2d$effect$2f$dist$2f$use$2d$isomorphic$2d$layout$2d$effect$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "useLatest.useIsomorphicLayoutEffect": function() {
            ref.current = value;
        }
    }["useLatest.useIsomorphicLayoutEffect"]);
    return ref;
};
;
}),
"[project]/next-admin-dashboard/node_modules/use-composed-ref/dist/use-composed-ref.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useComposedRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
// basically Exclude<React.ClassAttributes<T>["ref"], string>
var updateRef = function updateRef(ref, value) {
    if (typeof ref === 'function') {
        ref(value);
        return;
    }
    ref.current = value;
};
var useComposedRef = function useComposedRef(libRef, userRef) {
    var prevUserRef = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef();
    return __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useComposedRef.useCallback": function(instance) {
            libRef.current = instance;
            if (prevUserRef.current) {
                updateRef(prevUserRef.current, null);
            }
            prevUserRef.current = userRef;
            if (!userRef) {
                return;
            }
            updateRef(userRef, instance);
        }
    }["useComposedRef.useCallback"], [
        userRef
    ]);
};
;
}),
"[project]/next-admin-dashboard/node_modules/react-textarea-autosize/dist/react-textarea-autosize.browser.development.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>index
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$use$2d$latest$2f$dist$2f$use$2d$latest$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/use-latest/dist/use-latest.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$use$2d$composed$2d$ref$2f$dist$2f$use$2d$composed$2d$ref$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/use-composed-ref/dist/use-composed-ref.esm.js [app-client] (ecmascript)");
;
;
;
;
;
var HIDDEN_TEXTAREA_STYLE = {
    'min-height': '0',
    'max-height': 'none',
    height: '0',
    visibility: 'hidden',
    overflow: 'hidden',
    position: 'absolute',
    'z-index': '-1000',
    top: '0',
    right: '0',
    display: 'block'
};
var forceHiddenStyles = function forceHiddenStyles(node) {
    Object.keys(HIDDEN_TEXTAREA_STYLE).forEach(function(key) {
        node.style.setProperty(key, HIDDEN_TEXTAREA_STYLE[key], 'important');
    });
};
var forceHiddenStyles$1 = forceHiddenStyles;
var hiddenTextarea = null;
var getHeight = function getHeight(node, sizingData) {
    var height = node.scrollHeight;
    if (sizingData.sizingStyle.boxSizing === 'border-box') {
        // border-box: add border, since height = content + padding + border
        return height + sizingData.borderSize;
    }
    // remove padding, since height = content
    return height - sizingData.paddingSize;
};
function calculateNodeHeight(sizingData, value, minRows, maxRows) {
    if (minRows === void 0) {
        minRows = 1;
    }
    if (maxRows === void 0) {
        maxRows = Infinity;
    }
    if (!hiddenTextarea) {
        hiddenTextarea = document.createElement('textarea');
        hiddenTextarea.setAttribute('tabindex', '-1');
        hiddenTextarea.setAttribute('aria-hidden', 'true');
        forceHiddenStyles$1(hiddenTextarea);
    }
    if (hiddenTextarea.parentNode === null) {
        document.body.appendChild(hiddenTextarea);
    }
    var paddingSize = sizingData.paddingSize, borderSize = sizingData.borderSize, sizingStyle = sizingData.sizingStyle;
    var boxSizing = sizingStyle.boxSizing;
    Object.keys(sizingStyle).forEach(function(_key) {
        var key = _key;
        hiddenTextarea.style[key] = sizingStyle[key];
    });
    forceHiddenStyles$1(hiddenTextarea);
    hiddenTextarea.value = value;
    var height = getHeight(hiddenTextarea, sizingData);
    // Double set and calc due to Firefox bug: https://bugzilla.mozilla.org/show_bug.cgi?id=1795904
    hiddenTextarea.value = value;
    height = getHeight(hiddenTextarea, sizingData);
    // measure height of a textarea with a single row
    hiddenTextarea.value = 'x';
    var rowHeight = hiddenTextarea.scrollHeight - paddingSize;
    var minHeight = rowHeight * minRows;
    if (boxSizing === 'border-box') {
        minHeight = minHeight + paddingSize + borderSize;
    }
    height = Math.max(minHeight, height);
    var maxHeight = rowHeight * maxRows;
    if (boxSizing === 'border-box') {
        maxHeight = maxHeight + paddingSize + borderSize;
    }
    height = Math.min(maxHeight, height);
    return [
        height,
        rowHeight
    ];
}
var noop = function noop() {};
var pick = function pick(props, obj) {
    return props.reduce(function(acc, prop) {
        acc[prop] = obj[prop];
        return acc;
    }, {});
};
var SIZING_STYLE = [
    'borderBottomWidth',
    'borderLeftWidth',
    'borderRightWidth',
    'borderTopWidth',
    'boxSizing',
    'fontFamily',
    'fontSize',
    'fontStyle',
    'fontWeight',
    'letterSpacing',
    'lineHeight',
    'paddingBottom',
    'paddingLeft',
    'paddingRight',
    'paddingTop',
    // non-standard
    'tabSize',
    'textIndent',
    // non-standard
    'textRendering',
    'textTransform',
    'width',
    'wordBreak',
    'wordSpacing',
    'scrollbarGutter'
];
var isIE = !!document.documentElement.currentStyle;
var getSizingData = function getSizingData(node) {
    var style = window.getComputedStyle(node);
    if (style === null) {
        return null;
    }
    var sizingStyle = pick(SIZING_STYLE, style);
    var boxSizing = sizingStyle.boxSizing;
    // probably node is detached from DOM, can't read computed dimensions
    if (boxSizing === '') {
        return null;
    }
    // IE (Edge has already correct behaviour) returns content width as computed width
    // so we need to add manually padding and border widths
    if (isIE && boxSizing === 'border-box') {
        sizingStyle.width = parseFloat(sizingStyle.width) + parseFloat(sizingStyle.borderRightWidth) + parseFloat(sizingStyle.borderLeftWidth) + parseFloat(sizingStyle.paddingRight) + parseFloat(sizingStyle.paddingLeft) + 'px';
    }
    var paddingSize = parseFloat(sizingStyle.paddingBottom) + parseFloat(sizingStyle.paddingTop);
    var borderSize = parseFloat(sizingStyle.borderBottomWidth) + parseFloat(sizingStyle.borderTopWidth);
    return {
        sizingStyle: sizingStyle,
        paddingSize: paddingSize,
        borderSize: borderSize
    };
};
var getSizingData$1 = getSizingData;
function useListener(target, type, listener) {
    var latestListener = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$use$2d$latest$2f$dist$2f$use$2d$latest$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(listener);
    __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"]({
        "useListener.useLayoutEffect": function() {
            var handler = function handler(ev) {
                return latestListener.current(ev);
            };
            // might happen if document.fonts is not defined, for instance
            if (!target) {
                return;
            }
            target.addEventListener(type, handler);
            return ({
                "useListener.useLayoutEffect": function() {
                    return target.removeEventListener(type, handler);
                }
            })["useListener.useLayoutEffect"];
        }
    }["useListener.useLayoutEffect"], []);
}
var useFormResetListener = function useFormResetListener(libRef, listener) {
    useListener(document.body, 'reset', {
        "useFormResetListener.useListener": function(ev) {
            if (libRef.current.form === ev.target) {
                listener(ev);
            }
        }
    }["useFormResetListener.useListener"]);
};
var useWindowResizeListener = function useWindowResizeListener(listener) {
    useListener(window, 'resize', listener);
};
var useFontsLoadedListener = function useFontsLoadedListener(listener) {
    useListener(document.fonts, 'loadingdone', listener);
};
var _excluded = [
    "cacheMeasurements",
    "maxRows",
    "minRows",
    "onChange",
    "onHeightChange"
];
var TextareaAutosize = function TextareaAutosize(_ref, userRef) {
    var cacheMeasurements = _ref.cacheMeasurements, maxRows = _ref.maxRows, minRows = _ref.minRows, _ref$onChange = _ref.onChange, onChange = _ref$onChange === void 0 ? noop : _ref$onChange, _ref$onHeightChange = _ref.onHeightChange, onHeightChange = _ref$onHeightChange === void 0 ? noop : _ref$onHeightChange, props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_ref, _excluded);
    if (props.style) {
        if ('maxHeight' in props.style) {
            throw new Error('Using `style.maxHeight` for <TextareaAutosize/> is not supported. Please use `maxRows`.');
        }
        if ('minHeight' in props.style) {
            throw new Error('Using `style.minHeight` for <TextareaAutosize/> is not supported. Please use `minRows`.');
        }
    }
    var isControlled = props.value !== undefined;
    var libRef = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    var ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$use$2d$composed$2d$ref$2f$dist$2f$use$2d$composed$2d$ref$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(libRef, userRef);
    var heightRef = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](0);
    var measurementsCacheRef = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]();
    var resizeTextarea = function resizeTextarea() {
        var node = libRef.current;
        var nodeSizingData = cacheMeasurements && measurementsCacheRef.current ? measurementsCacheRef.current : getSizingData$1(node);
        if (!nodeSizingData) {
            return;
        }
        measurementsCacheRef.current = nodeSizingData;
        var _calculateNodeHeight = calculateNodeHeight(nodeSizingData, node.value || node.placeholder || 'x', minRows, maxRows), height = _calculateNodeHeight[0], rowHeight = _calculateNodeHeight[1];
        if (heightRef.current !== height) {
            heightRef.current = height;
            node.style.setProperty('height', height + "px", 'important');
            onHeightChange(height, {
                rowHeight: rowHeight
            });
        }
    };
    var handleChange = function handleChange(event) {
        if (!isControlled) {
            resizeTextarea();
        }
        onChange(event);
    };
    {
        __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"](resizeTextarea);
        useFormResetListener(libRef, {
            "TextareaAutosize.useFormResetListener": function() {
                if (!isControlled) {
                    var currentValue = libRef.current.value;
                    requestAnimationFrame({
                        "TextareaAutosize.useFormResetListener": function() {
                            var node = libRef.current;
                            if (node && currentValue !== node.value) {
                                resizeTextarea();
                            }
                        }
                    }["TextareaAutosize.useFormResetListener"]);
                }
            }
        }["TextareaAutosize.useFormResetListener"]);
        useWindowResizeListener(resizeTextarea);
        useFontsLoadedListener(resizeTextarea);
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("textarea", (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, props, {
            onChange: handleChange,
            ref: ref
        }));
    }
};
var index = /* #__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](TextareaAutosize);
;
}),
"[project]/next-admin-dashboard/node_modules/@tanstack/virtual-core/dist/esm/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "approxEqual",
    ()=>approxEqual,
    "debounce",
    ()=>debounce,
    "memo",
    ()=>memo,
    "notUndefined",
    ()=>notUndefined
]);
function memo(getDeps, fn, opts) {
    var _opts_initialDeps;
    let deps = (_opts_initialDeps = opts.initialDeps) !== null && _opts_initialDeps !== void 0 ? _opts_initialDeps : [];
    let result;
    return ()=>{
        var _a, _b, _c, _d;
        let depTime;
        if (opts.key && ((_a = opts.debug) == null ? void 0 : _a.call(opts))) depTime = Date.now();
        const newDeps = getDeps();
        const depsChanged = newDeps.length !== deps.length || newDeps.some((dep, index)=>deps[index] !== dep);
        if (!depsChanged) {
            return result;
        }
        deps = newDeps;
        let resultTime;
        if (opts.key && ((_b = opts.debug) == null ? void 0 : _b.call(opts))) resultTime = Date.now();
        result = fn(...newDeps);
        if (opts.key && ((_c = opts.debug) == null ? void 0 : _c.call(opts))) {
            const depEndTime = Math.round((Date.now() - depTime) * 100) / 100;
            const resultEndTime = Math.round((Date.now() - resultTime) * 100) / 100;
            const resultFpsPercentage = resultEndTime / 16;
            const pad = (str, num)=>{
                str = String(str);
                while(str.length < num){
                    str = " " + str;
                }
                return str;
            };
            console.info("%c⏱ ".concat(pad(resultEndTime, 5), " /").concat(pad(depEndTime, 5), " ms"), "\n            font-size: .6rem;\n            font-weight: bold;\n            color: hsl(".concat(Math.max(0, Math.min(120 - 120 * resultFpsPercentage, 120)), "deg 100% 31%);"), opts == null ? void 0 : opts.key);
        }
        (_d = opts == null ? void 0 : opts.onChange) == null ? void 0 : _d.call(opts, result);
        return result;
    };
}
function notUndefined(value, msg) {
    if (value === void 0) {
        throw new Error("Unexpected undefined".concat(msg ? ": ".concat(msg) : ""));
    } else {
        return value;
    }
}
const approxEqual = (a, b)=>Math.abs(a - b) < 1;
const debounce = (targetWindow, fn, ms)=>{
    let timeoutId;
    return function() {
        for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
            args[_key] = arguments[_key];
        }
        targetWindow.clearTimeout(timeoutId);
        timeoutId = targetWindow.setTimeout(()=>fn.apply(this, args), ms);
    };
};
;
 //# sourceMappingURL=utils.js.map
}),
"[project]/next-admin-dashboard/node_modules/@tanstack/virtual-core/dist/esm/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Virtualizer",
    ()=>Virtualizer,
    "defaultKeyExtractor",
    ()=>defaultKeyExtractor,
    "defaultRangeExtractor",
    ()=>defaultRangeExtractor,
    "elementScroll",
    ()=>elementScroll,
    "measureElement",
    ()=>measureElement,
    "observeElementOffset",
    ()=>observeElementOffset,
    "observeElementRect",
    ()=>observeElementRect,
    "observeWindowOffset",
    ()=>observeWindowOffset,
    "observeWindowRect",
    ()=>observeWindowRect,
    "windowScroll",
    ()=>windowScroll
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@tanstack/virtual-core/dist/esm/utils.js [app-client] (ecmascript)");
;
const defaultKeyExtractor = (index)=>index;
const defaultRangeExtractor = (range)=>{
    const start = Math.max(range.startIndex - range.overscan, 0);
    const end = Math.min(range.endIndex + range.overscan, range.count - 1);
    const arr = [];
    for(let i = start; i <= end; i++){
        arr.push(i);
    }
    return arr;
};
const observeElementRect = (instance, cb)=>{
    const element = instance.scrollElement;
    if (!element) {
        return;
    }
    const targetWindow = instance.targetWindow;
    if (!targetWindow) {
        return;
    }
    const handler = (rect)=>{
        const { width, height } = rect;
        cb({
            width: Math.round(width),
            height: Math.round(height)
        });
    };
    handler(element.getBoundingClientRect());
    if (!targetWindow.ResizeObserver) {
        return ()=>{};
    }
    const observer = new targetWindow.ResizeObserver((entries)=>{
        const entry = entries[0];
        if (entry == null ? void 0 : entry.borderBoxSize) {
            const box = entry.borderBoxSize[0];
            if (box) {
                handler({
                    width: box.inlineSize,
                    height: box.blockSize
                });
                return;
            }
        }
        handler(element.getBoundingClientRect());
    });
    observer.observe(element, {
        box: "border-box"
    });
    return ()=>{
        observer.unobserve(element);
    };
};
const addEventListenerOptions = {
    passive: true
};
const observeWindowRect = (instance, cb)=>{
    const element = instance.scrollElement;
    if (!element) {
        return;
    }
    const handler = ()=>{
        cb({
            width: element.innerWidth,
            height: element.innerHeight
        });
    };
    handler();
    element.addEventListener("resize", handler, addEventListenerOptions);
    return ()=>{
        element.removeEventListener("resize", handler);
    };
};
const supportsScrollend = typeof window == "undefined" ? true : "onscrollend" in window;
const observeElementOffset = (instance, cb)=>{
    const element = instance.scrollElement;
    if (!element) {
        return;
    }
    const targetWindow = instance.targetWindow;
    if (!targetWindow) {
        return;
    }
    let offset = 0;
    const fallback = instance.options.useScrollendEvent && supportsScrollend ? ()=>void 0 : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debounce"])(targetWindow, ()=>{
        cb(offset, false);
    }, instance.options.isScrollingResetDelay);
    const createHandler = (isScrolling)=>()=>{
            const { horizontal, isRtl } = instance.options;
            offset = horizontal ? element["scrollLeft"] * (isRtl && -1 || 1) : element["scrollTop"];
            fallback();
            cb(offset, isScrolling);
        };
    const handler = createHandler(true);
    const endHandler = createHandler(false);
    endHandler();
    element.addEventListener("scroll", handler, addEventListenerOptions);
    element.addEventListener("scrollend", endHandler, addEventListenerOptions);
    return ()=>{
        element.removeEventListener("scroll", handler);
        element.removeEventListener("scrollend", endHandler);
    };
};
const observeWindowOffset = (instance, cb)=>{
    const element = instance.scrollElement;
    if (!element) {
        return;
    }
    const targetWindow = instance.targetWindow;
    if (!targetWindow) {
        return;
    }
    let offset = 0;
    const fallback = instance.options.useScrollendEvent && supportsScrollend ? ()=>void 0 : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debounce"])(targetWindow, ()=>{
        cb(offset, false);
    }, instance.options.isScrollingResetDelay);
    const createHandler = (isScrolling)=>()=>{
            offset = element[instance.options.horizontal ? "scrollX" : "scrollY"];
            fallback();
            cb(offset, isScrolling);
        };
    const handler = createHandler(true);
    const endHandler = createHandler(false);
    endHandler();
    element.addEventListener("scroll", handler, addEventListenerOptions);
    element.addEventListener("scrollend", endHandler, addEventListenerOptions);
    return ()=>{
        element.removeEventListener("scroll", handler);
        element.removeEventListener("scrollend", endHandler);
    };
};
const measureElement = (element, entry, instance)=>{
    if (entry == null ? void 0 : entry.borderBoxSize) {
        const box = entry.borderBoxSize[0];
        if (box) {
            const size = Math.round(box[instance.options.horizontal ? "inlineSize" : "blockSize"]);
            return size;
        }
    }
    return Math.round(element.getBoundingClientRect()[instance.options.horizontal ? "width" : "height"]);
};
const windowScroll = (offset, param, instance)=>{
    let { adjustments = 0, behavior } = param;
    var _a, _b;
    const toOffset = offset + adjustments;
    (_b = (_a = instance.scrollElement) == null ? void 0 : _a.scrollTo) == null ? void 0 : _b.call(_a, {
        [instance.options.horizontal ? "left" : "top"]: toOffset,
        behavior
    });
};
const elementScroll = (offset, param, instance)=>{
    let { adjustments = 0, behavior } = param;
    var _a, _b;
    const toOffset = offset + adjustments;
    (_b = (_a = instance.scrollElement) == null ? void 0 : _a.scrollTo) == null ? void 0 : _b.call(_a, {
        [instance.options.horizontal ? "left" : "top"]: toOffset,
        behavior
    });
};
class Virtualizer {
    constructor(opts){
        var _this = this;
        this.unsubs = [];
        this.scrollElement = null;
        this.targetWindow = null;
        this.isScrolling = false;
        this.scrollToIndexTimeoutId = null;
        this.measurementsCache = [];
        this.itemSizeCache = /* @__PURE__ */ new Map();
        this.pendingMeasuredCacheIndexes = [];
        this.scrollRect = null;
        this.scrollOffset = null;
        this.scrollDirection = null;
        this.scrollAdjustments = 0;
        this.elementsCache = /* @__PURE__ */ new Map();
        this.observer = /* @__PURE__ */ (()=>{
            let _ro = null;
            const get = ()=>{
                if (_ro) {
                    return _ro;
                }
                if (!this.targetWindow || !this.targetWindow.ResizeObserver) {
                    return null;
                }
                return _ro = new this.targetWindow.ResizeObserver((entries)=>{
                    entries.forEach((entry)=>{
                        this._measureElement(entry.target, entry);
                    });
                });
            };
            return {
                disconnect: ()=>{
                    var _a;
                    (_a = get()) == null ? void 0 : _a.disconnect();
                    _ro = null;
                },
                observe: (target)=>{
                    var _a;
                    return (_a = get()) == null ? void 0 : _a.observe(target, {
                        box: "border-box"
                    });
                },
                unobserve: (target)=>{
                    var _a;
                    return (_a = get()) == null ? void 0 : _a.unobserve(target);
                }
            };
        })();
        this.range = null;
        this.setOptions = (opts2)=>{
            Object.entries(opts2).forEach((param)=>{
                let [key, value] = param;
                if (typeof value === "undefined") delete opts2[key];
            });
            this.options = {
                debug: false,
                initialOffset: 0,
                overscan: 1,
                paddingStart: 0,
                paddingEnd: 0,
                scrollPaddingStart: 0,
                scrollPaddingEnd: 0,
                horizontal: false,
                getItemKey: defaultKeyExtractor,
                rangeExtractor: defaultRangeExtractor,
                onChange: ()=>{},
                measureElement,
                initialRect: {
                    width: 0,
                    height: 0
                },
                scrollMargin: 0,
                gap: 0,
                indexAttribute: "data-index",
                initialMeasurementsCache: [],
                lanes: 1,
                isScrollingResetDelay: 150,
                enabled: true,
                isRtl: false,
                useScrollendEvent: true,
                ...opts2
            };
        };
        this.notify = (sync)=>{
            var _a, _b;
            (_b = (_a = this.options).onChange) == null ? void 0 : _b.call(_a, this, sync);
        };
        this.maybeNotify = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(()=>{
            this.calculateRange();
            return [
                this.isScrolling,
                this.range ? this.range.startIndex : null,
                this.range ? this.range.endIndex : null
            ];
        }, (isScrolling)=>{
            this.notify(isScrolling);
        }, {
            key: ("TURBOPACK compile-time value", "development") !== "production" && "maybeNotify",
            debug: ()=>this.options.debug,
            initialDeps: [
                this.isScrolling,
                this.range ? this.range.startIndex : null,
                this.range ? this.range.endIndex : null
            ]
        });
        this.cleanup = ()=>{
            this.unsubs.filter(Boolean).forEach((d)=>d());
            this.unsubs = [];
            this.observer.disconnect();
            this.scrollElement = null;
            this.targetWindow = null;
        };
        this._didMount = ()=>{
            return ()=>{
                this.cleanup();
            };
        };
        this._willUpdate = ()=>{
            var _a;
            const scrollElement = this.options.enabled ? this.options.getScrollElement() : null;
            if (this.scrollElement !== scrollElement) {
                this.cleanup();
                if (!scrollElement) {
                    this.maybeNotify();
                    return;
                }
                this.scrollElement = scrollElement;
                if (this.scrollElement && "ownerDocument" in this.scrollElement) {
                    this.targetWindow = this.scrollElement.ownerDocument.defaultView;
                } else {
                    var _ref;
                    this.targetWindow = (_ref = (_a = this.scrollElement) == null ? void 0 : _a.window) !== null && _ref !== void 0 ? _ref : null;
                }
                this.elementsCache.forEach((cached)=>{
                    this.observer.observe(cached);
                });
                this._scrollToOffset(this.getScrollOffset(), {
                    adjustments: void 0,
                    behavior: void 0
                });
                this.unsubs.push(this.options.observeElementRect(this, (rect)=>{
                    this.scrollRect = rect;
                    this.maybeNotify();
                }));
                this.unsubs.push(this.options.observeElementOffset(this, (offset, isScrolling)=>{
                    this.scrollAdjustments = 0;
                    this.scrollDirection = isScrolling ? this.getScrollOffset() < offset ? "forward" : "backward" : null;
                    this.scrollOffset = offset;
                    this.isScrolling = isScrolling;
                    this.maybeNotify();
                }));
            }
        };
        this.getSize = ()=>{
            if (!this.options.enabled) {
                this.scrollRect = null;
                return 0;
            }
            var _this_scrollRect;
            this.scrollRect = (_this_scrollRect = this.scrollRect) !== null && _this_scrollRect !== void 0 ? _this_scrollRect : this.options.initialRect;
            return this.scrollRect[this.options.horizontal ? "width" : "height"];
        };
        this.getScrollOffset = ()=>{
            if (!this.options.enabled) {
                this.scrollOffset = null;
                return 0;
            }
            var _this_scrollOffset;
            this.scrollOffset = (_this_scrollOffset = this.scrollOffset) !== null && _this_scrollOffset !== void 0 ? _this_scrollOffset : typeof this.options.initialOffset === "function" ? this.options.initialOffset() : this.options.initialOffset;
            return this.scrollOffset;
        };
        this.getFurthestMeasurement = (measurements, index)=>{
            const furthestMeasurementsFound = /* @__PURE__ */ new Map();
            const furthestMeasurements = /* @__PURE__ */ new Map();
            for(let m = index - 1; m >= 0; m--){
                const measurement = measurements[m];
                if (furthestMeasurementsFound.has(measurement.lane)) {
                    continue;
                }
                const previousFurthestMeasurement = furthestMeasurements.get(measurement.lane);
                if (previousFurthestMeasurement == null || measurement.end > previousFurthestMeasurement.end) {
                    furthestMeasurements.set(measurement.lane, measurement);
                } else if (measurement.end < previousFurthestMeasurement.end) {
                    furthestMeasurementsFound.set(measurement.lane, true);
                }
                if (furthestMeasurementsFound.size === this.options.lanes) {
                    break;
                }
            }
            return furthestMeasurements.size === this.options.lanes ? Array.from(furthestMeasurements.values()).sort((a, b)=>{
                if (a.end === b.end) {
                    return a.index - b.index;
                }
                return a.end - b.end;
            })[0] : void 0;
        };
        this.getMeasurementOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(()=>[
                this.options.count,
                this.options.paddingStart,
                this.options.scrollMargin,
                this.options.getItemKey,
                this.options.enabled
            ], (count, paddingStart, scrollMargin, getItemKey, enabled)=>{
            this.pendingMeasuredCacheIndexes = [];
            return {
                count,
                paddingStart,
                scrollMargin,
                getItemKey,
                enabled
            };
        }, {
            key: false
        });
        this.getMeasurements = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(()=>[
                this.getMeasurementOptions(),
                this.itemSizeCache
            ], (param, itemSizeCache)=>{
            let { count, paddingStart, scrollMargin, getItemKey, enabled } = param;
            if (!enabled) {
                this.measurementsCache = [];
                this.itemSizeCache.clear();
                return [];
            }
            if (this.measurementsCache.length === 0) {
                this.measurementsCache = this.options.initialMeasurementsCache;
                this.measurementsCache.forEach((item)=>{
                    this.itemSizeCache.set(item.key, item.size);
                });
            }
            const min = this.pendingMeasuredCacheIndexes.length > 0 ? Math.min(...this.pendingMeasuredCacheIndexes) : 0;
            this.pendingMeasuredCacheIndexes = [];
            const measurements = this.measurementsCache.slice(0, min);
            for(let i = min; i < count; i++){
                const key = getItemKey(i);
                const furthestMeasurement = this.options.lanes === 1 ? measurements[i - 1] : this.getFurthestMeasurement(measurements, i);
                const start = furthestMeasurement ? furthestMeasurement.end + this.options.gap : paddingStart + scrollMargin;
                const measuredSize = itemSizeCache.get(key);
                const size = typeof measuredSize === "number" ? measuredSize : this.options.estimateSize(i);
                const end = start + size;
                const lane = furthestMeasurement ? furthestMeasurement.lane : i % this.options.lanes;
                measurements[i] = {
                    index: i,
                    start,
                    size,
                    end,
                    key,
                    lane
                };
            }
            this.measurementsCache = measurements;
            return measurements;
        }, {
            key: ("TURBOPACK compile-time value", "development") !== "production" && "getMeasurements",
            debug: ()=>this.options.debug
        });
        this.calculateRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(()=>[
                this.getMeasurements(),
                this.getSize(),
                this.getScrollOffset()
            ], (measurements, outerSize, scrollOffset)=>{
            return this.range = measurements.length > 0 && outerSize > 0 ? calculateRange({
                measurements,
                outerSize,
                scrollOffset
            }) : null;
        }, {
            key: ("TURBOPACK compile-time value", "development") !== "production" && "calculateRange",
            debug: ()=>this.options.debug
        });
        this.getIndexes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(()=>{
            let startIndex = null;
            let endIndex = null;
            const range = this.calculateRange();
            if (range) {
                startIndex = range.startIndex;
                endIndex = range.endIndex;
            }
            return [
                this.options.rangeExtractor,
                this.options.overscan,
                this.options.count,
                startIndex,
                endIndex
            ];
        }, (rangeExtractor, overscan, count, startIndex, endIndex)=>{
            return startIndex === null || endIndex === null ? [] : rangeExtractor({
                startIndex,
                endIndex,
                overscan,
                count
            });
        }, {
            key: ("TURBOPACK compile-time value", "development") !== "production" && "getIndexes",
            debug: ()=>this.options.debug
        });
        this.indexFromElement = (node)=>{
            const attributeName = this.options.indexAttribute;
            const indexStr = node.getAttribute(attributeName);
            if (!indexStr) {
                console.warn("Missing attribute name '".concat(attributeName, "={index}' on measured element."));
                return -1;
            }
            return parseInt(indexStr, 10);
        };
        this._measureElement = (node, entry)=>{
            const index = this.indexFromElement(node);
            const item = this.measurementsCache[index];
            if (!item) {
                return;
            }
            const key = item.key;
            const prevNode = this.elementsCache.get(key);
            if (prevNode !== node) {
                if (prevNode) {
                    this.observer.unobserve(prevNode);
                }
                this.observer.observe(node);
                this.elementsCache.set(key, node);
            }
            if (node.isConnected) {
                this.resizeItem(index, this.options.measureElement(node, entry, this));
            }
        };
        this.resizeItem = (index, size)=>{
            const item = this.measurementsCache[index];
            if (!item) {
                return;
            }
            var _this_itemSizeCache_get;
            const itemSize = (_this_itemSizeCache_get = this.itemSizeCache.get(item.key)) !== null && _this_itemSizeCache_get !== void 0 ? _this_itemSizeCache_get : item.size;
            const delta = size - itemSize;
            if (delta !== 0) {
                if (this.shouldAdjustScrollPositionOnItemSizeChange !== void 0 ? this.shouldAdjustScrollPositionOnItemSizeChange(item, delta, this) : item.start < this.getScrollOffset() + this.scrollAdjustments) {
                    if (("TURBOPACK compile-time value", "development") !== "production" && this.options.debug) {
                        console.info("correction", delta);
                    }
                    this._scrollToOffset(this.getScrollOffset(), {
                        adjustments: this.scrollAdjustments += delta,
                        behavior: void 0
                    });
                }
                this.pendingMeasuredCacheIndexes.push(item.index);
                this.itemSizeCache = new Map(this.itemSizeCache.set(item.key, size));
                this.notify(false);
            }
        };
        this.measureElement = (node)=>{
            if (!node) {
                this.elementsCache.forEach((cached, key)=>{
                    if (!cached.isConnected) {
                        this.observer.unobserve(cached);
                        this.elementsCache.delete(key);
                    }
                });
                return;
            }
            this._measureElement(node, void 0);
        };
        this.getVirtualItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(()=>[
                this.getIndexes(),
                this.getMeasurements()
            ], (indexes, measurements)=>{
            const virtualItems = [];
            for(let k = 0, len = indexes.length; k < len; k++){
                const i = indexes[k];
                const measurement = measurements[i];
                virtualItems.push(measurement);
            }
            return virtualItems;
        }, {
            key: ("TURBOPACK compile-time value", "development") !== "production" && "getVirtualItems",
            debug: ()=>this.options.debug
        });
        this.getVirtualItemForOffset = (offset)=>{
            const measurements = this.getMeasurements();
            if (measurements.length === 0) {
                return void 0;
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notUndefined"])(measurements[findNearestBinarySearch(0, measurements.length - 1, (index)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notUndefined"])(measurements[index]).start, offset)]);
        };
        this.getOffsetForAlignment = (toOffset, align)=>{
            const size = this.getSize();
            const scrollOffset = this.getScrollOffset();
            if (align === "auto") {
                if (toOffset >= scrollOffset + size) {
                    align = "end";
                }
            }
            if (align === "end") {
                toOffset -= size;
            }
            const scrollSizeProp = this.options.horizontal ? "scrollWidth" : "scrollHeight";
            const scrollSize = this.scrollElement ? "document" in this.scrollElement ? this.scrollElement.document.documentElement[scrollSizeProp] : this.scrollElement[scrollSizeProp] : 0;
            const maxOffset = scrollSize - size;
            return Math.max(Math.min(maxOffset, toOffset), 0);
        };
        this.getOffsetForIndex = function(index) {
            let align = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "auto";
            index = Math.max(0, Math.min(index, _this.options.count - 1));
            const item = _this.measurementsCache[index];
            if (!item) {
                return void 0;
            }
            const size = _this.getSize();
            const scrollOffset = _this.getScrollOffset();
            if (align === "auto") {
                if (item.end >= scrollOffset + size - _this.options.scrollPaddingEnd) {
                    align = "end";
                } else if (item.start <= scrollOffset + _this.options.scrollPaddingStart) {
                    align = "start";
                } else {
                    return [
                        scrollOffset,
                        align
                    ];
                }
            }
            const centerOffset = item.start - _this.options.scrollPaddingStart + (item.size - size) / 2;
            switch(align){
                case "center":
                    return [
                        _this.getOffsetForAlignment(centerOffset, align),
                        align
                    ];
                case "end":
                    return [
                        _this.getOffsetForAlignment(item.end + _this.options.scrollPaddingEnd, align),
                        align
                    ];
                default:
                    return [
                        _this.getOffsetForAlignment(item.start - _this.options.scrollPaddingStart, align),
                        align
                    ];
            }
        };
        this.isDynamicMode = ()=>this.elementsCache.size > 0;
        this.cancelScrollToIndex = ()=>{
            if (this.scrollToIndexTimeoutId !== null && this.targetWindow) {
                this.targetWindow.clearTimeout(this.scrollToIndexTimeoutId);
                this.scrollToIndexTimeoutId = null;
            }
        };
        this.scrollToOffset = function(toOffset) {
            let { align = "start", behavior } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
            _this.cancelScrollToIndex();
            if (behavior === "smooth" && _this.isDynamicMode()) {
                console.warn("The `smooth` scroll behavior is not fully supported with dynamic size.");
            }
            _this._scrollToOffset(_this.getOffsetForAlignment(toOffset, align), {
                adjustments: void 0,
                behavior
            });
        };
        this.scrollToIndex = function(index) {
            let { align: initialAlign = "auto", behavior } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
            index = Math.max(0, Math.min(index, _this.options.count - 1));
            _this.cancelScrollToIndex();
            if (behavior === "smooth" && _this.isDynamicMode()) {
                console.warn("The `smooth` scroll behavior is not fully supported with dynamic size.");
            }
            const offsetAndAlign = _this.getOffsetForIndex(index, initialAlign);
            if (!offsetAndAlign) return;
            const [offset, align] = offsetAndAlign;
            _this._scrollToOffset(offset, {
                adjustments: void 0,
                behavior
            });
            if (behavior !== "smooth" && _this.isDynamicMode() && _this.targetWindow) {
                _this.scrollToIndexTimeoutId = _this.targetWindow.setTimeout(()=>{
                    _this.scrollToIndexTimeoutId = null;
                    const elementInDOM = _this.elementsCache.has(_this.options.getItemKey(index));
                    if (elementInDOM) {
                        const [latestOffset] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notUndefined"])(_this.getOffsetForIndex(index, align));
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["approxEqual"])(latestOffset, _this.getScrollOffset())) {
                            _this.scrollToIndex(index, {
                                align,
                                behavior
                            });
                        }
                    } else {
                        _this.scrollToIndex(index, {
                            align,
                            behavior
                        });
                    }
                });
            }
        };
        this.scrollBy = function(delta) {
            let { behavior } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
            _this.cancelScrollToIndex();
            if (behavior === "smooth" && _this.isDynamicMode()) {
                console.warn("The `smooth` scroll behavior is not fully supported with dynamic size.");
            }
            _this._scrollToOffset(_this.getScrollOffset() + delta, {
                adjustments: void 0,
                behavior
            });
        };
        this.getTotalSize = ()=>{
            var _a;
            const measurements = this.getMeasurements();
            let end;
            if (measurements.length === 0) {
                end = this.options.paddingStart;
            } else {
                var _ref;
                end = this.options.lanes === 1 ? (_ref = (_a = measurements[measurements.length - 1]) == null ? void 0 : _a.end) !== null && _ref !== void 0 ? _ref : 0 : Math.max(...measurements.slice(-this.options.lanes).map((m)=>m.end));
            }
            return Math.max(end - this.options.scrollMargin + this.options.paddingEnd, 0);
        };
        this._scrollToOffset = (offset, param)=>{
            let { adjustments, behavior } = param;
            this.options.scrollToFn(offset, {
                behavior,
                adjustments
            }, this);
        };
        this.measure = ()=>{
            this.itemSizeCache = /* @__PURE__ */ new Map();
            this.notify(false);
        };
        this.setOptions(opts);
    }
}
const findNearestBinarySearch = (low, high, getCurrentValue, value)=>{
    while(low <= high){
        const middle = (low + high) / 2 | 0;
        const currentValue = getCurrentValue(middle);
        if (currentValue < value) {
            low = middle + 1;
        } else if (currentValue > value) {
            high = middle - 1;
        } else {
            return middle;
        }
    }
    if (low > 0) {
        return low - 1;
    } else {
        return 0;
    }
};
function calculateRange(param) {
    let { measurements, outerSize, scrollOffset } = param;
    const count = measurements.length - 1;
    const getOffset = (index)=>measurements[index].start;
    const startIndex = findNearestBinarySearch(0, count, getOffset, scrollOffset);
    let endIndex = startIndex;
    while(endIndex < count && measurements[endIndex].end < scrollOffset + outerSize){
        endIndex++;
    }
    return {
        startIndex,
        endIndex
    };
}
;
 //# sourceMappingURL=index.js.map
}),
"[project]/next-admin-dashboard/node_modules/@tanstack/react-virtual/dist/esm/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useVirtualizer",
    ()=>useVirtualizer,
    "useWindowVirtualizer",
    ()=>useWindowVirtualizer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@tanstack/virtual-core/dist/esm/index.js [app-client] (ecmascript) <locals>");
;
;
;
;
const useIsomorphicLayoutEffect = typeof document !== "undefined" ? __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"] : __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"];
function useVirtualizerBase(options) {
    const rerender = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"]({
        "useVirtualizerBase.useReducer": ()=>({})
    }["useVirtualizerBase.useReducer"], {})[1];
    const resolvedOptions = {
        ...options,
        onChange: (instance2, sync)=>{
            var _a;
            if (sync) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"])(rerender);
            } else {
                rerender();
            }
            (_a = options.onChange) == null ? void 0 : _a.call(options, instance2, sync);
        }
    };
    const [instance] = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        "useVirtualizerBase.useState": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Virtualizer"](resolvedOptions)
    }["useVirtualizerBase.useState"]);
    instance.setOptions(resolvedOptions);
    useIsomorphicLayoutEffect({
        "useVirtualizerBase.useIsomorphicLayoutEffect": ()=>{
            return instance._didMount();
        }
    }["useVirtualizerBase.useIsomorphicLayoutEffect"], []);
    useIsomorphicLayoutEffect({
        "useVirtualizerBase.useIsomorphicLayoutEffect": ()=>{
            return instance._willUpdate();
        }
    }["useVirtualizerBase.useIsomorphicLayoutEffect"]);
    return instance;
}
function useVirtualizer(options) {
    return useVirtualizerBase({
        observeElementRect: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["observeElementRect"],
        observeElementOffset: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["observeElementOffset"],
        scrollToFn: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["elementScroll"],
        ...options
    });
}
function useWindowVirtualizer(options) {
    return useVirtualizerBase({
        getScrollElement: {
            "useWindowVirtualizer.useVirtualizerBase": ()=>typeof document !== "undefined" ? window : null
        }["useWindowVirtualizer.useVirtualizerBase"],
        observeElementRect: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["observeWindowRect"],
        observeElementOffset: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["observeWindowOffset"],
        scrollToFn: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$tanstack$2f$virtual$2d$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["windowScroll"],
        initialOffset: {
            "useWindowVirtualizer.useVirtualizerBase": ()=>typeof document !== "undefined" ? window.scrollY : 0
        }["useWindowVirtualizer.useVirtualizerBase"],
        ...options
    });
}
;
 //# sourceMappingURL=index.js.map
}),
"[project]/next-admin-dashboard/node_modules/input-otp/dist/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OTPInput",
    ()=>Lt,
    "OTPInputContext",
    ()=>jt,
    "REGEXP_ONLY_CHARS",
    ()=>Jt,
    "REGEXP_ONLY_DIGITS",
    ()=>Kt,
    "REGEXP_ONLY_DIGITS_AND_CHARS",
    ()=>Qt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var Bt = Object.defineProperty, At = Object.defineProperties;
var kt = Object.getOwnPropertyDescriptors;
var Y = Object.getOwnPropertySymbols;
var gt = Object.prototype.hasOwnProperty, Et = Object.prototype.propertyIsEnumerable;
var vt = (r, s, e)=>s in r ? Bt(r, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[s] = e, St = (r, s)=>{
    for(var e in s || (s = {}))gt.call(s, e) && vt(r, e, s[e]);
    if (Y) for (var e of Y(s))Et.call(s, e) && vt(r, e, s[e]);
    return r;
}, bt = (r, s)=>At(r, kt(s));
var Pt = (r, s)=>{
    var e = {};
    for(var u in r)gt.call(r, u) && s.indexOf(u) < 0 && (e[u] = r[u]);
    if (r != null && Y) for (var u of Y(r))s.indexOf(u) < 0 && Et.call(r, u) && (e[u] = r[u]);
    return e;
};
;
function ht(r) {
    let s = setTimeout(r, 0), e = setTimeout(r, 10), u = setTimeout(r, 50);
    return [
        s,
        e,
        u
    ];
}
;
function _t(r) {
    let s = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]();
    return __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "_t.useEffect": ()=>{
            s.current = r;
        }
    }["_t.useEffect"]), s.current;
}
;
var Ot = 18, wt = 40, Gt = "".concat(wt, "px"), xt = [
    "[data-lastpass-icon-root]",
    "com-1password-button",
    "[data-dashlanecreated]",
    '[style$="2147483647 !important;"]'
].join(",");
function Tt(param) {
    let { containerRef: r, inputRef: s, pushPasswordManagerStrategy: e, isFocused: u } = param;
    let [P, D] = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [G, H] = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [F, W] = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), Z = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Tt.useMemo[Z]": ()=>e === "none" ? !1 : (e === "increase-width" || e === "experimental-no-flickering") && P && G
    }["Tt.useMemo[Z]"], [
        P,
        G,
        e
    ]), T = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Tt.useCallback[T]": ()=>{
            let f = r.current, h = s.current;
            if (!f || !h || F || e === "none") return;
            let a = f, B = a.getBoundingClientRect().left + a.offsetWidth, A = a.getBoundingClientRect().top + a.offsetHeight / 2, z = B - Ot, q = A;
            document.querySelectorAll(xt).length === 0 && document.elementFromPoint(z, q) === f || (D(!0), W(!0));
        }
    }["Tt.useCallback[T]"], [
        r,
        s,
        F,
        e
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Tt.useEffect": ()=>{
            let f = r.current;
            if (!f || e === "none") return;
            function h() {
                let A = window.innerWidth - f.getBoundingClientRect().right;
                H(A >= wt);
            }
            h();
            let a = setInterval(h, 1e3);
            return ({
                "Tt.useEffect": ()=>{
                    clearInterval(a);
                }
            })["Tt.useEffect"];
        }
    }["Tt.useEffect"], [
        r,
        e
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Tt.useEffect": ()=>{
            let f = u || document.activeElement === s.current;
            if (e === "none" || !f) return;
            let h = setTimeout(T, 0), a = setTimeout(T, 2e3), B = setTimeout(T, 5e3), A = setTimeout({
                "Tt.useEffect.A": ()=>{
                    W(!0);
                }
            }["Tt.useEffect.A"], 6e3);
            return ({
                "Tt.useEffect": ()=>{
                    clearTimeout(h), clearTimeout(a), clearTimeout(B), clearTimeout(A);
                }
            })["Tt.useEffect"];
        }
    }["Tt.useEffect"], [
        s,
        u,
        e,
        T
    ]), {
        hasPWMBadge: P,
        willPushPWMBadge: Z,
        PWM_BADGE_SPACE_WIDTH: Gt
    };
}
var jt = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({}), Lt = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((A, B)=>{
    var z = A, { value: r, onChange: s, maxLength: e, textAlign: u = "left", pattern: P, placeholder: D, inputMode: G = "numeric", onComplete: H, pushPasswordManagerStrategy: F = "increase-width", pasteTransformer: W, containerClassName: Z, noScriptCSSFallback: T = Nt, render: f, children: h } = z, a = Pt(z, [
        "value",
        "onChange",
        "maxLength",
        "textAlign",
        "pattern",
        "placeholder",
        "inputMode",
        "onComplete",
        "pushPasswordManagerStrategy",
        "pasteTransformer",
        "containerClassName",
        "noScriptCSSFallback",
        "render",
        "children"
    ]);
    var X, lt, ut, dt, ft;
    let [q, nt] = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](typeof a.defaultValue == "string" ? a.defaultValue : ""), i = r != null ? r : q, I = _t(i), x = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[x]": (t)=>{
            s == null || s(t), nt(t);
        }
    }["Lt.useCallback[x]"], [
        s
    ]), m = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[m]": ()=>P ? typeof P == "string" ? new RegExp(P) : P : null
    }["Lt.useMemo[m]"], [
        P
    ]), l = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), K = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), J = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]({
        value: i,
        onChange: x,
        isIOS: typeof window != "undefined" && ((lt = (X = window == null ? void 0 : window.CSS) == null ? void 0 : X.supports) == null ? void 0 : lt.call(X, "-webkit-touch-callout", "none"))
    }), V = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]({
        prev: [
            (ut = l.current) == null ? void 0 : ut.selectionStart,
            (dt = l.current) == null ? void 0 : dt.selectionEnd,
            (ft = l.current) == null ? void 0 : ft.selectionDirection
        ]
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"](B, {
        "Lt.useImperativeHandle": ()=>l.current
    }["Lt.useImperativeHandle"], []), __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Lt.useEffect": ()=>{
            let t = l.current, o = K.current;
            if (!t || !o) return;
            J.current.value !== t.value && J.current.onChange(t.value), V.current.prev = [
                t.selectionStart,
                t.selectionEnd,
                t.selectionDirection
            ];
            function d() {
                if (document.activeElement !== t) {
                    L(null), N(null);
                    return;
                }
                let c = t.selectionStart, b = t.selectionEnd, mt = t.selectionDirection, v = t.maxLength, C = t.value, _ = V.current.prev, g = -1, E = -1, w;
                if (C.length !== 0 && c !== null && b !== null) {
                    let Dt = c === b, Ht = c === C.length && C.length < v;
                    if (Dt && !Ht) {
                        let y = c;
                        if (y === 0) g = 0, E = 1, w = "forward";
                        else if (y === v) g = y - 1, E = y, w = "backward";
                        else if (v > 1 && C.length > 1) {
                            let et = 0;
                            if (_[0] !== null && _[1] !== null) {
                                w = y < _[1] ? "backward" : "forward";
                                let Wt = _[0] === _[1] && _[0] < v;
                                w === "backward" && !Wt && (et = -1);
                            }
                            g = et + y, E = et + y + 1;
                        }
                    }
                    g !== -1 && E !== -1 && g !== E && l.current.setSelectionRange(g, E, w);
                }
                let pt = g !== -1 ? g : c, Rt = E !== -1 ? E : b, yt = w != null ? w : mt;
                L(pt), N(Rt), V.current.prev = [
                    pt,
                    Rt,
                    yt
                ];
            }
            if (document.addEventListener("selectionchange", d, {
                capture: !0
            }), d(), document.activeElement === t && Q(!0), !document.getElementById("input-otp-style")) {
                let c = document.createElement("style");
                if (c.id = "input-otp-style", document.head.appendChild(c), c.sheet) {
                    let b = "background: transparent !important; color: transparent !important; border-color: transparent !important; opacity: 0 !important; box-shadow: none !important; -webkit-box-shadow: none !important; -webkit-text-fill-color: transparent !important;";
                    $(c.sheet, "[data-input-otp]::selection { background: transparent !important; color: transparent !important; }"), $(c.sheet, "[data-input-otp]:autofill { ".concat(b, " }")), $(c.sheet, "[data-input-otp]:-webkit-autofill { ".concat(b, " }")), $(c.sheet, "@supports (-webkit-touch-callout: none) { [data-input-otp] { letter-spacing: -.6em !important; font-weight: 100 !important; font-stretch: ultra-condensed; font-optical-sizing: none !important; left: -1px !important; right: 1px !important; } }"), $(c.sheet, "[data-input-otp] + * { pointer-events: all !important; }");
                }
            }
            let p = {
                "Lt.useEffect.p": ()=>{
                    o && o.style.setProperty("--root-height", "".concat(t.clientHeight, "px"));
                }
            }["Lt.useEffect.p"];
            p();
            let R = new ResizeObserver(p);
            return R.observe(t), ({
                "Lt.useEffect": ()=>{
                    document.removeEventListener("selectionchange", d, {
                        capture: !0
                    }), R.disconnect();
                }
            })["Lt.useEffect"];
        }
    }["Lt.useEffect"], []);
    let [ot, rt] = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [j, Q] = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [M, L] = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null), [k, N] = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Lt.useEffect": ()=>{
            ht({
                "Lt.useEffect": ()=>{
                    var p, R, c, b;
                    (p = l.current) == null || p.dispatchEvent(new Event("input"));
                    let t = (R = l.current) == null ? void 0 : R.selectionStart, o = (c = l.current) == null ? void 0 : c.selectionEnd, d = (b = l.current) == null ? void 0 : b.selectionDirection;
                    t !== null && o !== null && (L(t), N(o), V.current.prev = [
                        t,
                        o,
                        d
                    ]);
                }
            }["Lt.useEffect"]);
        }
    }["Lt.useEffect"], [
        i,
        j
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Lt.useEffect": ()=>{
            I !== void 0 && i !== I && I.length < e && i.length === e && (H == null || H(i));
        }
    }["Lt.useEffect"], [
        e,
        H,
        I,
        i
    ]);
    let O = Tt({
        containerRef: K,
        inputRef: l,
        pushPasswordManagerStrategy: F,
        isFocused: j
    }), st = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[st]": (t)=>{
            let o = t.currentTarget.value.slice(0, e);
            if (o.length > 0 && m && !m.test(o)) {
                t.preventDefault();
                return;
            }
            typeof I == "string" && o.length < I.length && document.dispatchEvent(new Event("selectionchange")), x(o);
        }
    }["Lt.useCallback[st]"], [
        e,
        x,
        I,
        m
    ]), at = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[at]": ()=>{
            var t;
            if (l.current) {
                let o = Math.min(l.current.value.length, e - 1), d = l.current.value.length;
                (t = l.current) == null || t.setSelectionRange(o, d), L(o), N(d);
            }
            Q(!0);
        }
    }["Lt.useCallback[at]"], [
        e
    ]), ct = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[ct]": (t)=>{
            var g, E;
            let o = l.current;
            if (!W && (!J.current.isIOS || !t.clipboardData || !o)) return;
            let d = t.clipboardData.getData("text/plain"), p = W ? W(d) : d;
            console.log({
                _content: d,
                content: p
            }), t.preventDefault();
            let R = (g = l.current) == null ? void 0 : g.selectionStart, c = (E = l.current) == null ? void 0 : E.selectionEnd, v = (R !== c ? i.slice(0, R) + p + i.slice(c) : i.slice(0, R) + p + i.slice(R)).slice(0, e);
            if (v.length > 0 && m && !m.test(v)) return;
            o.value = v, x(v);
            let C = Math.min(v.length, e - 1), _ = v.length;
            o.setSelectionRange(C, _), L(C), N(_);
        }
    }["Lt.useCallback[ct]"], [
        e,
        x,
        m,
        i
    ]), It = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[It]": ()=>({
                position: "relative",
                cursor: a.disabled ? "default" : "text",
                userSelect: "none",
                WebkitUserSelect: "none",
                pointerEvents: "none"
            })
    }["Lt.useMemo[It]"], [
        a.disabled
    ]), it = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[it]": ()=>({
                position: "absolute",
                inset: 0,
                width: O.willPushPWMBadge ? "calc(100% + ".concat(O.PWM_BADGE_SPACE_WIDTH, ")") : "100%",
                clipPath: O.willPushPWMBadge ? "inset(0 ".concat(O.PWM_BADGE_SPACE_WIDTH, " 0 0)") : void 0,
                height: "100%",
                display: "flex",
                textAlign: u,
                opacity: "1",
                color: "transparent",
                pointerEvents: "all",
                background: "transparent",
                caretColor: "transparent",
                border: "0 solid transparent",
                outline: "0 solid transparent",
                boxShadow: "none",
                lineHeight: "1",
                letterSpacing: "-.5em",
                fontSize: "var(--root-height)",
                fontFamily: "monospace",
                fontVariantNumeric: "tabular-nums"
            })
    }["Lt.useMemo[it]"], [
        O.PWM_BADGE_SPACE_WIDTH,
        O.willPushPWMBadge,
        u
    ]), Mt = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[Mt]": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("input", bt(St({
                autoComplete: a.autoComplete || "one-time-code"
            }, a), {
                "data-input-otp": !0,
                "data-input-otp-placeholder-shown": i.length === 0 || void 0,
                "data-input-otp-mss": M,
                "data-input-otp-mse": k,
                inputMode: G,
                pattern: m == null ? void 0 : m.source,
                "aria-placeholder": D,
                style: it,
                maxLength: e,
                value: i,
                ref: l,
                onPaste: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        ct(t), (o = a.onPaste) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onChange: st,
                onMouseOver: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        rt(!0), (o = a.onMouseOver) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onMouseLeave: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        rt(!1), (o = a.onMouseLeave) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onFocus: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        at(), (o = a.onFocus) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onBlur: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        Q(!1), (o = a.onBlur) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"]
            }))
    }["Lt.useMemo[Mt]"], [
        st,
        at,
        ct,
        G,
        it,
        e,
        k,
        M,
        a,
        m == null ? void 0 : m.source,
        i
    ]), tt = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[tt]": ()=>({
                slots: Array.from({
                    length: e
                }).map({
                    "Lt.useMemo[tt]": (t, o)=>{
                        var c;
                        let d = j && M !== null && k !== null && (M === k && o === M || o >= M && o < k), p = i[o] !== void 0 ? i[o] : null, R = i[0] !== void 0 ? null : (c = D == null ? void 0 : D[o]) != null ? c : null;
                        return {
                            char: p,
                            placeholderChar: R,
                            isActive: d,
                            hasFakeCaret: d && p === null
                        };
                    }
                }["Lt.useMemo[tt]"]),
                isFocused: j,
                isHovering: !a.disabled && ot
            })
    }["Lt.useMemo[tt]"], [
        j,
        ot,
        e,
        k,
        M,
        a.disabled,
        i
    ]), Ct = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[Ct]": ()=>f ? f(tt) : __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](jt.Provider, {
                value: tt
            }, h)
    }["Lt.useMemo[Ct]"], [
        h,
        tt,
        f
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, T !== null && __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("noscript", null, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("style", null, T)), __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: K,
        "data-input-otp-container": !0,
        style: It,
        className: Z
    }, Ct, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("div", {
        style: {
            position: "absolute",
            inset: 0,
            pointerEvents: "none"
        }
    }, Mt)));
});
Lt.displayName = "Input";
function $(r, s) {
    try {
        r.insertRule(s);
    } catch (e) {
        console.error("input-otp could not insert CSS rule:", s);
    }
}
var Nt = "\n[data-input-otp] {\n  --nojs-bg: white !important;\n  --nojs-fg: black !important;\n\n  background-color: var(--nojs-bg) !important;\n  color: var(--nojs-fg) !important;\n  caret-color: var(--nojs-fg) !important;\n  letter-spacing: .25em !important;\n  text-align: center !important;\n  border: 1px solid var(--nojs-fg) !important;\n  border-radius: 4px !important;\n  width: 100% !important;\n}\n@media (prefers-color-scheme: dark) {\n  [data-input-otp] {\n    --nojs-bg: black !important;\n    --nojs-fg: white !important;\n  }\n}";
var Kt = "^\\d+$", Jt = "^[a-zA-Z]+$", Qt = "^[a-zA-Z0-9]+$";
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/next-admin-dashboard/node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * use-sync-external-store-shim.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function is(x, y) {
        return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
    }
    function useSyncExternalStore$2(subscribe, getSnapshot) {
        didWarnOld18Alpha || void 0 === React.startTransition || (didWarnOld18Alpha = !0, console.error("You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."));
        var value = getSnapshot();
        if (!didWarnUncachedGetSnapshot) {
            var cachedValue = getSnapshot();
            objectIs(value, cachedValue) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), didWarnUncachedGetSnapshot = !0);
        }
        cachedValue = useState({
            inst: {
                value: value,
                getSnapshot: getSnapshot
            }
        });
        var inst = cachedValue[0].inst, forceUpdate = cachedValue[1];
        useLayoutEffect({
            "useSyncExternalStore$2.useLayoutEffect": function() {
                inst.value = value;
                inst.getSnapshot = getSnapshot;
                checkIfSnapshotChanged(inst) && forceUpdate({
                    inst: inst
                });
            }
        }["useSyncExternalStore$2.useLayoutEffect"], [
            subscribe,
            value,
            getSnapshot
        ]);
        useEffect({
            "useSyncExternalStore$2.useEffect": function() {
                checkIfSnapshotChanged(inst) && forceUpdate({
                    inst: inst
                });
                return subscribe({
                    "useSyncExternalStore$2.useEffect": function() {
                        checkIfSnapshotChanged(inst) && forceUpdate({
                            inst: inst
                        });
                    }
                }["useSyncExternalStore$2.useEffect"]);
            }
        }["useSyncExternalStore$2.useEffect"], [
            subscribe
        ]);
        useDebugValue(value);
        return value;
    }
    function checkIfSnapshotChanged(inst) {
        var latestGetSnapshot = inst.getSnapshot;
        inst = inst.value;
        try {
            var nextValue = latestGetSnapshot();
            return !objectIs(inst, nextValue);
        } catch (error) {
            return !0;
        }
    }
    function useSyncExternalStore$1(subscribe, getSnapshot) {
        return getSnapshot();
    }
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
    var React = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), objectIs = "function" === typeof Object.is ? Object.is : is, useState = React.useState, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect, useDebugValue = React.useDebugValue, didWarnOld18Alpha = !1, didWarnUncachedGetSnapshot = !1, shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
    exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
}();
}),
"[project]/next-admin-dashboard/node_modules/use-sync-external-store/shim/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js [app-client] (ecmascript)");
}
}),
]);

//# sourceMappingURL=2e916_ca3672f2._.js.map