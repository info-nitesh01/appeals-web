module.exports = [
"[project]/next-admin-dashboard/node_modules/next/navigation.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/next/dist/client/components/navigation.js [app-ssr] (ecmascript)");
}),
"[project]/next-admin-dashboard/node_modules/next/image.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/next/dist/shared/lib/image-external.js [app-ssr] (ecmascript)");
}),
];

//# sourceMappingURL=2e916_next_6d89c0ab._.js.map