module.exports = [
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/chain.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ /**
 * Calls all functions in the order they were chained with the same arguments.
 */ __turbopack_context__.s([
    "chain",
    ()=>$ff5963eb1fccf552$export$e08e3b67e392101e
]);
function $ff5963eb1fccf552$export$e08e3b67e392101e(...callbacks) {
    return (...args)=>{
        for (let callback of callbacks)if (typeof callback === 'function') callback(...args);
    };
}
;
 //# sourceMappingURL=chain.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useLayoutEffect.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLayoutEffect",
    ()=>$f0a04ccd8dbdd83b$export$e5c5a5f917a5871c
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ const $f0a04ccd8dbdd83b$export$e5c5a5f917a5871c = typeof document !== 'undefined' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]).useLayoutEffect : ()=>{};
;
 //# sourceMappingURL=useLayoutEffect.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useEffectEvent.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useEffectEvent",
    ()=>$8ae05eaa5c114e9c$export$7f54fc3180508a52
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useLayoutEffect$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useLayoutEffect.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
;
/*
 * Copyright 2023 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ var $8ae05eaa5c114e9c$var$_React_useInsertionEffect;
// Use the earliest effect type possible. useInsertionEffect runs during the mutation phase,
// before all layout effects, but is available only in React 18 and later.
const $8ae05eaa5c114e9c$var$useEarlyEffect = ($8ae05eaa5c114e9c$var$_React_useInsertionEffect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])['useInsertionEffect']) !== null && $8ae05eaa5c114e9c$var$_React_useInsertionEffect !== void 0 ? $8ae05eaa5c114e9c$var$_React_useInsertionEffect : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useLayoutEffect$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useLayoutEffect"]);
function $8ae05eaa5c114e9c$export$7f54fc3180508a52(fn) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useRef"])(null);
    $8ae05eaa5c114e9c$var$useEarlyEffect(()=>{
        ref.current = fn;
    }, [
        fn
    ]);
    // @ts-ignore
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCallback"])((...args)=>{
        const f = ref.current;
        return f === null || f === void 0 ? void 0 : f(...args);
    }, []);
}
;
 //# sourceMappingURL=useEffectEvent.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useValueEffect.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useValueEffect",
    ()=>$1dbecbe27a04f9af$export$14d238f342723f25
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useEffectEvent$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useEffectEvent.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useLayoutEffect$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useLayoutEffect.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
;
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ function $1dbecbe27a04f9af$export$14d238f342723f25(defaultValue) {
    let [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(defaultValue);
    let effect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Store the function in a ref so we can always access the current version
    // which has the proper `value` in scope.
    let nextRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useEffectEvent$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useEffectEvent"])(()=>{
        if (!effect.current) return;
        // Run the generator to the next yield.
        let newValue = effect.current.next();
        // If the generator is done, reset the effect.
        if (newValue.done) {
            effect.current = null;
            return;
        }
        // If the value is the same as the current value,
        // then continue to the next yield. Otherwise,
        // set the value in state and wait for the next layout effect.
        if (value === newValue.value) nextRef();
        else setValue(newValue.value);
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useLayoutEffect$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useLayoutEffect"])(()=>{
        // If there is an effect currently running, continue to the next yield.
        if (effect.current) nextRef();
    });
    let queue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useEffectEvent$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useEffectEvent"])((fn)=>{
        effect.current = fn(value);
        nextRef();
    });
    return [
        value,
        queue
    ];
}
;
 //# sourceMappingURL=useValueEffect.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useId.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "idsUpdaterMap",
    ()=>$bdb11010cef70236$export$d41a04c74483c6ef,
    "mergeIds",
    ()=>$bdb11010cef70236$export$cd8c9cb68f842629,
    "useId",
    ()=>$bdb11010cef70236$export$f680877a34711e37,
    "useSlotId",
    ()=>$bdb11010cef70236$export$b4cc09c592e8fdb8
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useLayoutEffect$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useLayoutEffect.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useValueEffect$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useValueEffect.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$ssr$2f$dist$2f$SSRProvider$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/ssr/dist/SSRProvider.mjs [app-rsc] (ecmascript)");
;
;
;
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ // copied from SSRProvider.tsx to reduce exports, if needed again, consider sharing
let $bdb11010cef70236$var$canUseDOM = Boolean("undefined" !== 'undefined' && window.document && window.document.createElement);
let $bdb11010cef70236$export$d41a04c74483c6ef = new Map();
// This allows us to clean up the idsUpdaterMap when the id is no longer used.
// Map is a strong reference, so unused ids wouldn't be cleaned up otherwise.
// This can happen in suspended components where mount/unmount is not called.
let $bdb11010cef70236$var$registry;
if (typeof FinalizationRegistry !== 'undefined') $bdb11010cef70236$var$registry = new FinalizationRegistry((heldValue)=>{
    $bdb11010cef70236$export$d41a04c74483c6ef.delete(heldValue);
});
function $bdb11010cef70236$export$f680877a34711e37(defaultId) {
    let [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(defaultId);
    let nextId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useRef"])(null);
    let res = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$ssr$2f$dist$2f$SSRProvider$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useSSRSafeId"])(value);
    let cleanupRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useRef"])(null);
    if ($bdb11010cef70236$var$registry) $bdb11010cef70236$var$registry.register(cleanupRef, res);
    if ($bdb11010cef70236$var$canUseDOM) {
        const cacheIdRef = $bdb11010cef70236$export$d41a04c74483c6ef.get(res);
        if (cacheIdRef && !cacheIdRef.includes(nextId)) cacheIdRef.push(nextId);
        else $bdb11010cef70236$export$d41a04c74483c6ef.set(res, [
            nextId
        ]);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useLayoutEffect$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useLayoutEffect"])(()=>{
        let r = res;
        return ()=>{
            // In Suspense, the cleanup function may be not called
            // when it is though, also remove it from the finalization registry.
            if ($bdb11010cef70236$var$registry) $bdb11010cef70236$var$registry.unregister(cleanupRef);
            $bdb11010cef70236$export$d41a04c74483c6ef.delete(r);
        };
    }, [
        res
    ]);
    // This cannot cause an infinite loop because the ref is always cleaned up.
    // eslint-disable-next-line
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let newId = nextId.current;
        if (newId) setValue(newId);
        return ()=>{
            if (newId) nextId.current = null;
        };
    });
    return res;
}
function $bdb11010cef70236$export$cd8c9cb68f842629(idA, idB) {
    if (idA === idB) return idA;
    let setIdsA = $bdb11010cef70236$export$d41a04c74483c6ef.get(idA);
    if (setIdsA) {
        setIdsA.forEach((ref)=>ref.current = idB);
        return idB;
    }
    let setIdsB = $bdb11010cef70236$export$d41a04c74483c6ef.get(idB);
    if (setIdsB) {
        setIdsB.forEach((ref)=>ref.current = idA);
        return idA;
    }
    return idB;
}
function $bdb11010cef70236$export$b4cc09c592e8fdb8(depArray = []) {
    let id = $bdb11010cef70236$export$f680877a34711e37();
    let [resolvedId, setResolvedId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useValueEffect$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useValueEffect"])(id);
    let updateId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        setResolvedId(function*() {
            yield id;
            yield document.getElementById(id) ? id : undefined;
        });
    }, [
        id,
        setResolvedId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useLayoutEffect$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useLayoutEffect"])(updateId, [
        id,
        updateId,
        ...depArray
    ]);
    return resolvedId;
}
;
 //# sourceMappingURL=useId.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/mergeProps.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mergeProps",
    ()=>$3ef42575df84b30b$export$9d1611c77c2fe928
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$chain$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/chain.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useId$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useId.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/node_modules/clsx/dist/clsx.mjs [app-rsc] (ecmascript)");
;
;
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ function $3ef42575df84b30b$export$9d1611c77c2fe928(...args) {
    // Start with a base clone of the first argument. This is a lot faster than starting
    // with an empty object and adding properties as we go.
    let result = {
        ...args[0]
    };
    for(let i = 1; i < args.length; i++){
        let props = args[i];
        for(let key in props){
            let a = result[key];
            let b = props[key];
            // Chain events
            if (typeof a === 'function' && typeof b === 'function' && // This is a lot faster than a regex.
            key[0] === 'o' && key[1] === 'n' && key.charCodeAt(2) >= /* 'A' */ 65 && key.charCodeAt(2) <= /* 'Z' */ 90) result[key] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$chain$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["chain"])(a, b);
            else if ((key === 'className' || key === 'UNSAFE_className') && typeof a === 'string' && typeof b === 'string') result[key] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(a, b);
            else if (key === 'id' && a && b) result.id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useId$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mergeIds"])(a, b);
            else result[key] = b !== undefined ? b : a;
        }
    }
    return result;
}
;
 //# sourceMappingURL=mergeProps.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/domHelpers.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getOwnerDocument",
    ()=>$431fbd86ca7dc216$export$b204af158042fbac,
    "getOwnerWindow",
    ()=>$431fbd86ca7dc216$export$f21a1ffae260145a,
    "isShadowRoot",
    ()=>$431fbd86ca7dc216$export$af51f0f06c0f328a
]);
const $431fbd86ca7dc216$export$b204af158042fbac = (el)=>{
    var _el_ownerDocument;
    return (_el_ownerDocument = el === null || el === void 0 ? void 0 : el.ownerDocument) !== null && _el_ownerDocument !== void 0 ? _el_ownerDocument : document;
};
const $431fbd86ca7dc216$export$f21a1ffae260145a = (el)=>{
    if (el && 'window' in el && el.window === el) return el;
    const doc = $431fbd86ca7dc216$export$b204af158042fbac(el);
    return doc.defaultView || window;
};
/**
 * Type guard that checks if a value is a Node. Verifies the presence and type of the nodeType property.
 */ function $431fbd86ca7dc216$var$isNode(value) {
    return value !== null && typeof value === 'object' && 'nodeType' in value && typeof value.nodeType === 'number';
}
function $431fbd86ca7dc216$export$af51f0f06c0f328a(node) {
    return $431fbd86ca7dc216$var$isNode(node) && node.nodeType === Node.DOCUMENT_FRAGMENT_NODE && 'host' in node;
}
;
 //# sourceMappingURL=domHelpers.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/isElementVisible.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isElementVisible",
    ()=>$7d2416ea0959daaa$export$e989c0fffaa6b27a
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$domHelpers$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/domHelpers.mjs [app-rsc] (ecmascript)");
;
/*
 * Copyright 2021 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ const $7d2416ea0959daaa$var$supportsCheckVisibility = typeof Element !== 'undefined' && 'checkVisibility' in Element.prototype;
function $7d2416ea0959daaa$var$isStyleVisible(element) {
    const windowObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$domHelpers$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getOwnerWindow"])(element);
    if (!(element instanceof windowObject.HTMLElement) && !(element instanceof windowObject.SVGElement)) return false;
    let { display: display, visibility: visibility } = element.style;
    let isVisible = display !== 'none' && visibility !== 'hidden' && visibility !== 'collapse';
    if (isVisible) {
        const { getComputedStyle: getComputedStyle } = element.ownerDocument.defaultView;
        let { display: computedDisplay, visibility: computedVisibility } = getComputedStyle(element);
        isVisible = computedDisplay !== 'none' && computedVisibility !== 'hidden' && computedVisibility !== 'collapse';
    }
    return isVisible;
}
function $7d2416ea0959daaa$var$isAttributeVisible(element, childElement) {
    return !element.hasAttribute('hidden') && // Ignore HiddenSelect when tree walking.
    !element.hasAttribute('data-react-aria-prevent-focus') && (element.nodeName === 'DETAILS' && childElement && childElement.nodeName !== 'SUMMARY' ? element.hasAttribute('open') : true);
}
function $7d2416ea0959daaa$export$e989c0fffaa6b27a(element, childElement) {
    if ($7d2416ea0959daaa$var$supportsCheckVisibility) return element.checkVisibility() && !element.closest('[data-react-aria-prevent-focus]');
    return element.nodeName !== '#comment' && $7d2416ea0959daaa$var$isStyleVisible(element) && $7d2416ea0959daaa$var$isAttributeVisible(element, childElement) && (!element.parentElement || $7d2416ea0959daaa$export$e989c0fffaa6b27a(element.parentElement, element));
}
;
 //# sourceMappingURL=isElementVisible.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/isFocusable.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isFocusable",
    ()=>$b4b717babfbb907b$export$4c063cf1350e6fed,
    "isTabbable",
    ()=>$b4b717babfbb907b$export$bebd5a1431fec25d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$isElementVisible$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/isElementVisible.mjs [app-rsc] (ecmascript)");
;
/*
 * Copyright 2025 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ const $b4b717babfbb907b$var$focusableElements = [
    'input:not([disabled]):not([type=hidden])',
    'select:not([disabled])',
    'textarea:not([disabled])',
    'button:not([disabled])',
    'a[href]',
    'area[href]',
    'summary',
    'iframe',
    'object',
    'embed',
    'audio[controls]',
    'video[controls]',
    '[contenteditable]:not([contenteditable^="false"])',
    'permission'
];
const $b4b717babfbb907b$var$FOCUSABLE_ELEMENT_SELECTOR = $b4b717babfbb907b$var$focusableElements.join(':not([hidden]),') + ',[tabindex]:not([disabled]):not([hidden])';
$b4b717babfbb907b$var$focusableElements.push('[tabindex]:not([tabindex="-1"]):not([disabled])');
const $b4b717babfbb907b$var$TABBABLE_ELEMENT_SELECTOR = $b4b717babfbb907b$var$focusableElements.join(':not([hidden]):not([tabindex="-1"]),');
function $b4b717babfbb907b$export$4c063cf1350e6fed(element) {
    return element.matches($b4b717babfbb907b$var$FOCUSABLE_ELEMENT_SELECTOR) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$isElementVisible$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["isElementVisible"])(element) && !$b4b717babfbb907b$var$isInert(element);
}
function $b4b717babfbb907b$export$bebd5a1431fec25d(element) {
    return element.matches($b4b717babfbb907b$var$TABBABLE_ELEMENT_SELECTOR) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$isElementVisible$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["isElementVisible"])(element) && !$b4b717babfbb907b$var$isInert(element);
}
function $b4b717babfbb907b$var$isInert(element) {
    let node = element;
    while(node != null){
        if (node instanceof node.ownerDocument.defaultView.HTMLElement && node.inert) return true;
        node = node.parentElement;
    }
    return false;
}
;
 //# sourceMappingURL=isFocusable.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/focusWithoutScrolling.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ __turbopack_context__.s([
    "focusWithoutScrolling",
    ()=>$7215afc6de606d6b$export$de79e2c695e052f3
]);
function $7215afc6de606d6b$export$de79e2c695e052f3(element) {
    if ($7215afc6de606d6b$var$supportsPreventScroll()) element.focus({
        preventScroll: true
    });
    else {
        let scrollableElements = $7215afc6de606d6b$var$getScrollableElements(element);
        element.focus();
        $7215afc6de606d6b$var$restoreScrollPosition(scrollableElements);
    }
}
let $7215afc6de606d6b$var$supportsPreventScrollCached = null;
function $7215afc6de606d6b$var$supportsPreventScroll() {
    if ($7215afc6de606d6b$var$supportsPreventScrollCached == null) {
        $7215afc6de606d6b$var$supportsPreventScrollCached = false;
        try {
            let focusElem = document.createElement('div');
            focusElem.focus({
                get preventScroll () {
                    $7215afc6de606d6b$var$supportsPreventScrollCached = true;
                    return true;
                }
            });
        } catch  {
        // Ignore
        }
    }
    return $7215afc6de606d6b$var$supportsPreventScrollCached;
}
function $7215afc6de606d6b$var$getScrollableElements(element) {
    let parent = element.parentNode;
    let scrollableElements = [];
    let rootScrollingElement = document.scrollingElement || document.documentElement;
    while(parent instanceof HTMLElement && parent !== rootScrollingElement){
        if (parent.offsetHeight < parent.scrollHeight || parent.offsetWidth < parent.scrollWidth) scrollableElements.push({
            element: parent,
            scrollTop: parent.scrollTop,
            scrollLeft: parent.scrollLeft
        });
        parent = parent.parentNode;
    }
    if (rootScrollingElement instanceof HTMLElement) scrollableElements.push({
        element: rootScrollingElement,
        scrollTop: rootScrollingElement.scrollTop,
        scrollLeft: rootScrollingElement.scrollLeft
    });
    return scrollableElements;
}
function $7215afc6de606d6b$var$restoreScrollPosition(scrollableElements) {
    for (let { element: element, scrollTop: scrollTop, scrollLeft: scrollLeft } of scrollableElements){
        element.scrollTop = scrollTop;
        element.scrollLeft = scrollLeft;
    }
}
;
 //# sourceMappingURL=focusWithoutScrolling.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useGlobalListeners.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useGlobalListeners",
    ()=>$03deb23ff14920c4$export$4eaf04e54aa8eed6
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ function $03deb23ff14920c4$export$4eaf04e54aa8eed6() {
    let globalListeners = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    let addGlobalListener = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCallback"])((eventTarget, type, listener, options)=>{
        // Make sure we remove the listener after it is called with the `once` option.
        let fn = (options === null || options === void 0 ? void 0 : options.once) ? (...args)=>{
            globalListeners.current.delete(listener);
            listener(...args);
        } : listener;
        globalListeners.current.set(listener, {
            type: type,
            eventTarget: eventTarget,
            fn: fn,
            options: options
        });
        eventTarget.addEventListener(type, fn, options);
    }, []);
    let removeGlobalListener = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCallback"])((eventTarget, type, listener, options)=>{
        var _globalListeners_current_get;
        let fn = ((_globalListeners_current_get = globalListeners.current.get(listener)) === null || _globalListeners_current_get === void 0 ? void 0 : _globalListeners_current_get.fn) || listener;
        eventTarget.removeEventListener(type, fn, options);
        globalListeners.current.delete(listener);
    }, []);
    let removeAllGlobalListeners = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        globalListeners.current.forEach((value, key)=>{
            removeGlobalListener(value.eventTarget, value.type, key, value.options);
        });
    }, [
        removeGlobalListener
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        return removeAllGlobalListeners;
    }, [
        removeAllGlobalListeners
    ]);
    return {
        addGlobalListener: addGlobalListener,
        removeGlobalListener: removeGlobalListener,
        removeAllGlobalListeners: removeAllGlobalListeners
    };
}
;
 //# sourceMappingURL=useGlobalListeners.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/DOMFunctions.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getActiveElement",
    ()=>$d4ee10de306f2510$export$cd4e5573fbe2b576,
    "getEventTarget",
    ()=>$d4ee10de306f2510$export$e58f029f0fbfdb29,
    "nodeContains",
    ()=>$d4ee10de306f2510$export$4282f70798064fe0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$domHelpers$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/domHelpers.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$flags$2f$dist$2f$import$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-stately/flags/dist/import.mjs [app-rsc] (ecmascript)");
;
;
// Source: https://github.com/microsoft/tabster/blob/a89fc5d7e332d48f68d03b1ca6e344489d1c3898/src/Shadowdomize/DOMFunctions.ts#L16
function $d4ee10de306f2510$export$4282f70798064fe0(node, otherNode) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$flags$2f$dist$2f$import$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["shadowDOM"])()) return otherNode && node ? node.contains(otherNode) : false;
    if (!node || !otherNode) return false;
    let currentNode = otherNode;
    while(currentNode !== null){
        if (currentNode === node) return true;
        if (currentNode.tagName === 'SLOT' && currentNode.assignedSlot) currentNode = currentNode.assignedSlot.parentNode;
        else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$domHelpers$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["isShadowRoot"])(currentNode)) currentNode = currentNode.host;
        else currentNode = currentNode.parentNode;
    }
    return false;
}
const $d4ee10de306f2510$export$cd4e5573fbe2b576 = (doc = document)=>{
    var _activeElement_shadowRoot;
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$flags$2f$dist$2f$import$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["shadowDOM"])()) return doc.activeElement;
    let activeElement = doc.activeElement;
    while(activeElement && 'shadowRoot' in activeElement && ((_activeElement_shadowRoot = activeElement.shadowRoot) === null || _activeElement_shadowRoot === void 0 ? void 0 : _activeElement_shadowRoot.activeElement))activeElement = activeElement.shadowRoot.activeElement;
    return activeElement;
};
function $d4ee10de306f2510$export$e58f029f0fbfdb29(event) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$stately$2f$flags$2f$dist$2f$import$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["shadowDOM"])() && event.target.shadowRoot) {
        if (event.composedPath) return event.composedPath()[0];
    }
    return event.target;
}
;
 //# sourceMappingURL=DOMFunctions.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/ssr/dist/SSRProvider.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SSRProvider",
    ()=>$b5e257d569688ac6$export$9f8ac96af4b1b2ae,
    "useIsSSR",
    ()=>$b5e257d569688ac6$export$535bd6ca7f90a273,
    "useSSRSafeId",
    ()=>$b5e257d569688ac6$export$619500959fc48b26
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ // We must avoid a circular dependency with @react-aria/utils, and this useLayoutEffect is
// guarded by a check that it only runs on the client side.
// eslint-disable-next-line rulesdir/useLayoutEffectRule
// Default context value to use in case there is no SSRProvider. This is fine for
// client-only apps. In order to support multiple copies of React Aria potentially
// being on the page at once, the prefix is set to a random number. SSRProvider
// will reset this to zero for consistency between server and client, so in the
// SSR case multiple copies of React Aria is not supported.
const $b5e257d569688ac6$var$defaultContext = {
    prefix: String(Math.round(Math.random() * 10000000000)),
    current: 0
};
const $b5e257d569688ac6$var$SSRContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]).createContext($b5e257d569688ac6$var$defaultContext);
const $b5e257d569688ac6$var$IsSSRContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]).createContext(false);
// This is only used in React < 18.
function $b5e257d569688ac6$var$LegacySSRProvider(props) {
    let cur = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useContext"])($b5e257d569688ac6$var$SSRContext);
    let counter = $b5e257d569688ac6$var$useCounter(cur === $b5e257d569688ac6$var$defaultContext);
    let [isSSR, setIsSSR] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(true);
    let value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            // If this is the first SSRProvider, start with an empty string prefix, otherwise
            // append and increment the counter.
            prefix: cur === $b5e257d569688ac6$var$defaultContext ? '' : `${cur.prefix}-${counter}`,
            current: 0
        }), [
        cur,
        counter
    ]);
    // If on the client, and the component was initially server rendered,
    // then schedule a layout effect to update the component after hydration.
    if (typeof document !== 'undefined') // because the condition never changes after mounting.
    // eslint-disable-next-line react-hooks/rules-of-hooks
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useLayoutEffect"])(()=>{
        setIsSSR(false);
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]).createElement($b5e257d569688ac6$var$SSRContext.Provider, {
        value: value
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]).createElement($b5e257d569688ac6$var$IsSSRContext.Provider, {
        value: isSSR
    }, props.children));
}
let $b5e257d569688ac6$var$warnedAboutSSRProvider = false;
function $b5e257d569688ac6$export$9f8ac96af4b1b2ae(props) {
    if (typeof (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])['useId'] === 'function') {
        if (("TURBOPACK compile-time value", "development") !== 'test' && ("TURBOPACK compile-time value", "development") !== 'production' && !$b5e257d569688ac6$var$warnedAboutSSRProvider) {
            console.warn('In React 18, SSRProvider is not necessary and is a noop. You can remove it from your app.');
            $b5e257d569688ac6$var$warnedAboutSSRProvider = true;
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]).createElement((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]).Fragment, null, props.children);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]).createElement($b5e257d569688ac6$var$LegacySSRProvider, props);
}
let $b5e257d569688ac6$var$canUseDOM = Boolean("undefined" !== 'undefined' && window.document && window.document.createElement);
let $b5e257d569688ac6$var$componentIds = new WeakMap();
function $b5e257d569688ac6$var$useCounter(isDisabled = false) {
    let ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useContext"])($b5e257d569688ac6$var$SSRContext);
    let ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useRef"])(null);
    // eslint-disable-next-line rulesdir/pure-render
    if (ref.current === null && !isDisabled) {
        var _React___SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED_ReactCurrentOwner, _React___SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
        // In strict mode, React renders components twice, and the ref will be reset to null on the second render.
        // This means our id counter will be incremented twice instead of once. This is a problem because on the
        // server, components are only rendered once and so ids generated on the server won't match the client.
        // In React 18, useId was introduced to solve this, but it is not available in older versions. So to solve this
        // we need to use some React internals to access the underlying Fiber instance, which is stable between renders.
        // This is exposed as ReactCurrentOwner in development, which is all we need since StrictMode only runs in development.
        // To ensure that we only increment the global counter once, we store the starting id for this component in
        // a weak map associated with the Fiber. On the second render, we reset the global counter to this value.
        // Since React runs the second render immediately after the first, this is safe.
        // @ts-ignore
        let currentOwner = (_React___SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]).__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED) === null || _React___SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED === void 0 ? void 0 : (_React___SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED_ReactCurrentOwner = _React___SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner) === null || _React___SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED_ReactCurrentOwner === void 0 ? void 0 : _React___SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED_ReactCurrentOwner.current;
        if (currentOwner) {
            let prevComponentValue = $b5e257d569688ac6$var$componentIds.get(currentOwner);
            if (prevComponentValue == null) $b5e257d569688ac6$var$componentIds.set(currentOwner, {
                id: ctx.current,
                state: currentOwner.memoizedState
            });
            else if (currentOwner.memoizedState !== prevComponentValue.state) {
                // On the second render, the memoizedState gets reset by React.
                // Reset the counter, and remove from the weak map so we don't
                // do this for subsequent useId calls.
                ctx.current = prevComponentValue.id;
                $b5e257d569688ac6$var$componentIds.delete(currentOwner);
            }
        }
        // eslint-disable-next-line rulesdir/pure-render
        ref.current = ++ctx.current;
    }
    // eslint-disable-next-line rulesdir/pure-render
    return ref.current;
}
function $b5e257d569688ac6$var$useLegacySSRSafeId(defaultId) {
    let ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useContext"])($b5e257d569688ac6$var$SSRContext);
    // If we are rendering in a non-DOM environment, and there's no SSRProvider,
    // provide a warning to hint to the developer to add one.
    if (ctx === $b5e257d569688ac6$var$defaultContext && !$b5e257d569688ac6$var$canUseDOM && ("TURBOPACK compile-time value", "development") !== 'production') console.warn('When server rendering, you must wrap your application in an <SSRProvider> to ensure consistent ids are generated between the client and server.');
    let counter = $b5e257d569688ac6$var$useCounter(!!defaultId);
    let prefix = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : `react-aria${ctx.prefix}`;
    return defaultId || `${prefix}-${counter}`;
}
function $b5e257d569688ac6$var$useModernSSRSafeId(defaultId) {
    let id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]).useId();
    let [didSSR] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])($b5e257d569688ac6$export$535bd6ca7f90a273());
    let prefix = didSSR || ("TURBOPACK compile-time value", "development") === 'test' ? 'react-aria' : `react-aria${$b5e257d569688ac6$var$defaultContext.prefix}`;
    return defaultId || `${prefix}-${id}`;
}
const $b5e257d569688ac6$export$619500959fc48b26 = typeof (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])['useId'] === 'function' ? $b5e257d569688ac6$var$useModernSSRSafeId : $b5e257d569688ac6$var$useLegacySSRSafeId;
function $b5e257d569688ac6$var$getSnapshot() {
    return false;
}
function $b5e257d569688ac6$var$getServerSnapshot() {
    return true;
}
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function $b5e257d569688ac6$var$subscribe(onStoreChange) {
    // noop
    return ()=>{};
}
function $b5e257d569688ac6$export$535bd6ca7f90a273() {
    // In React 18, we can use useSyncExternalStore to detect if we're server rendering or hydrating.
    if (typeof (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])['useSyncExternalStore'] === 'function') return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])['useSyncExternalStore']($b5e257d569688ac6$var$subscribe, $b5e257d569688ac6$var$getSnapshot, $b5e257d569688ac6$var$getServerSnapshot);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useContext"])($b5e257d569688ac6$var$IsSSRContext);
}
;
 //# sourceMappingURL=SSRProvider.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/utils/node_modules/clsx/dist/clsx.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clsx",
    ()=>clsx,
    "default",
    ()=>__TURBOPACK__default__export__
]);
function r(e) {
    var t, f, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e) if (Array.isArray(e)) {
        var o = e.length;
        for(t = 0; t < o; t++)e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
    } else for(f in e)e[f] && (n && (n += " "), n += f);
    return n;
}
function clsx() {
    for(var e, t, f = 0, n = "", o = arguments.length; f < o; f++)(e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
    return n;
}
const __TURBOPACK__default__export__ = clsx;
}),
"[project]/next-admin-dashboard/node_modules/clsx/dist/clsx.m.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clsx",
    ()=>clsx,
    "default",
    ()=>__TURBOPACK__default__export__
]);
function r(e) {
    var t, f, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e) if (Array.isArray(e)) for(t = 0; t < e.length; t++)e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
    else for(t in e)e[t] && (n && (n += " "), n += t);
    return n;
}
function clsx() {
    for(var e, t, f = 0, n = ""; f < arguments.length;)(e = arguments[f++]) && (t = r(e)) && (n && (n += " "), n += t);
    return n;
}
const __TURBOPACK__default__export__ = clsx;
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/interactions/dist/utils.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSyntheticEvent",
    ()=>$8a9cb279dc87e130$export$525bc4921d56d4a,
    "ignoreFocusEvent",
    ()=>$8a9cb279dc87e130$export$fda7da73ab5d4c48,
    "preventFocus",
    ()=>$8a9cb279dc87e130$export$cabe61c495ee3649,
    "setEventTarget",
    ()=>$8a9cb279dc87e130$export$c2b7abe5d61ec696,
    "useSyntheticBlurEvent",
    ()=>$8a9cb279dc87e130$export$715c682d09d639cc
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useLayoutEffect$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useLayoutEffect.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useEffectEvent$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useEffectEvent.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$isFocusable$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/isFocusable.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$domHelpers$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/domHelpers.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$focusWithoutScrolling$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/focusWithoutScrolling.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ function $8a9cb279dc87e130$export$525bc4921d56d4a(nativeEvent) {
    let event = nativeEvent;
    event.nativeEvent = nativeEvent;
    event.isDefaultPrevented = ()=>event.defaultPrevented;
    // cancelBubble is technically deprecated in the spec, but still supported in all browsers.
    event.isPropagationStopped = ()=>event.cancelBubble;
    event.persist = ()=>{};
    return event;
}
function $8a9cb279dc87e130$export$c2b7abe5d61ec696(event, target) {
    Object.defineProperty(event, 'target', {
        value: target
    });
    Object.defineProperty(event, 'currentTarget', {
        value: target
    });
}
function $8a9cb279dc87e130$export$715c682d09d639cc(onBlur) {
    let stateRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useRef"])({
        isFocused: false,
        observer: null
    });
    // Clean up MutationObserver on unmount. See below.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useLayoutEffect$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useLayoutEffect"])(()=>{
        const state = stateRef.current;
        return ()=>{
            if (state.observer) {
                state.observer.disconnect();
                state.observer = null;
            }
        };
    }, []);
    let dispatchBlur = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useEffectEvent$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useEffectEvent"])((e)=>{
        onBlur === null || onBlur === void 0 ? void 0 : onBlur(e);
    });
    // This function is called during a React onFocus event.
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCallback"])((e)=>{
        // React does not fire onBlur when an element is disabled. https://github.com/facebook/react/issues/9142
        // Most browsers fire a native focusout event in this case, except for Firefox. In that case, we use a
        // MutationObserver to watch for the disabled attribute, and dispatch these events ourselves.
        // For browsers that do, focusout fires before the MutationObserver, so onBlur should not fire twice.
        if (e.target instanceof HTMLButtonElement || e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement) {
            stateRef.current.isFocused = true;
            let target = e.target;
            let onBlurHandler = (e)=>{
                stateRef.current.isFocused = false;
                if (target.disabled) {
                    // For backward compatibility, dispatch a (fake) React synthetic event.
                    let event = $8a9cb279dc87e130$export$525bc4921d56d4a(e);
                    dispatchBlur(event);
                }
                // We no longer need the MutationObserver once the target is blurred.
                if (stateRef.current.observer) {
                    stateRef.current.observer.disconnect();
                    stateRef.current.observer = null;
                }
            };
            target.addEventListener('focusout', onBlurHandler, {
                once: true
            });
            stateRef.current.observer = new MutationObserver(()=>{
                if (stateRef.current.isFocused && target.disabled) {
                    var _stateRef_current_observer;
                    (_stateRef_current_observer = stateRef.current.observer) === null || _stateRef_current_observer === void 0 ? void 0 : _stateRef_current_observer.disconnect();
                    let relatedTargetEl = target === document.activeElement ? null : document.activeElement;
                    target.dispatchEvent(new FocusEvent('blur', {
                        relatedTarget: relatedTargetEl
                    }));
                    target.dispatchEvent(new FocusEvent('focusout', {
                        bubbles: true,
                        relatedTarget: relatedTargetEl
                    }));
                }
            });
            stateRef.current.observer.observe(target, {
                attributes: true,
                attributeFilter: [
                    'disabled'
                ]
            });
        }
    }, [
        dispatchBlur
    ]);
}
let $8a9cb279dc87e130$export$fda7da73ab5d4c48 = false;
function $8a9cb279dc87e130$export$cabe61c495ee3649(target) {
    // The browser will focus the nearest focusable ancestor of our target.
    while(target && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$isFocusable$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["isFocusable"])(target))target = target.parentElement;
    let window = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$domHelpers$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getOwnerWindow"])(target);
    let activeElement = window.document.activeElement;
    if (!activeElement || activeElement === target) return;
    $8a9cb279dc87e130$export$fda7da73ab5d4c48 = true;
    let isRefocusing = false;
    let onBlur = (e)=>{
        if (e.target === activeElement || isRefocusing) e.stopImmediatePropagation();
    };
    let onFocusOut = (e)=>{
        if (e.target === activeElement || isRefocusing) {
            e.stopImmediatePropagation();
            // If there was no focusable ancestor, we don't expect a focus event.
            // Re-focus the original active element here.
            if (!target && !isRefocusing) {
                isRefocusing = true;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$focusWithoutScrolling$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["focusWithoutScrolling"])(activeElement);
                cleanup();
            }
        }
    };
    let onFocus = (e)=>{
        if (e.target === target || isRefocusing) e.stopImmediatePropagation();
    };
    let onFocusIn = (e)=>{
        if (e.target === target || isRefocusing) {
            e.stopImmediatePropagation();
            if (!isRefocusing) {
                isRefocusing = true;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$focusWithoutScrolling$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["focusWithoutScrolling"])(activeElement);
                cleanup();
            }
        }
    };
    window.addEventListener('blur', onBlur, true);
    window.addEventListener('focusout', onFocusOut, true);
    window.addEventListener('focusin', onFocusIn, true);
    window.addEventListener('focus', onFocus, true);
    let cleanup = ()=>{
        cancelAnimationFrame(raf);
        window.removeEventListener('blur', onBlur, true);
        window.removeEventListener('focusout', onFocusOut, true);
        window.removeEventListener('focusin', onFocusIn, true);
        window.removeEventListener('focus', onFocus, true);
        $8a9cb279dc87e130$export$fda7da73ab5d4c48 = false;
        isRefocusing = false;
    };
    let raf = requestAnimationFrame(cleanup);
    return cleanup;
}
;
 //# sourceMappingURL=utils.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/interactions/dist/useFocusWithin.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useFocusWithin",
    ()=>$9ab94262bd0047c7$export$420e68273165f4ec
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$interactions$2f$dist$2f$utils$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/interactions/dist/utils.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useGlobalListeners$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/useGlobalListeners.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$domHelpers$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/domHelpers.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$DOMFunctions$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/DOMFunctions.mjs [app-rsc] (ecmascript)");
;
;
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ // Portions of the code in this file are based on code from react.
// Original licensing for the following can be found in the
// NOTICE file in the root directory of this source tree.
// See https://github.com/facebook/react/tree/cc7c1aece46a6b69b41958d731e0fd27c94bfc6c/packages/react-interactions
function $9ab94262bd0047c7$export$420e68273165f4ec(props) {
    let { isDisabled: isDisabled, onBlurWithin: onBlurWithin, onFocusWithin: onFocusWithin, onFocusWithinChange: onFocusWithinChange } = props;
    let state = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useRef"])({
        isFocusWithin: false
    });
    let { addGlobalListener: addGlobalListener, removeAllGlobalListeners: removeAllGlobalListeners } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$useGlobalListeners$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useGlobalListeners"])();
    let onBlur = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCallback"])((e)=>{
        // Ignore events bubbling through portals.
        if (!e.currentTarget.contains(e.target)) return;
        // We don't want to trigger onBlurWithin and then immediately onFocusWithin again
        // when moving focus inside the element. Only trigger if the currentTarget doesn't
        // include the relatedTarget (where focus is moving).
        if (state.current.isFocusWithin && !e.currentTarget.contains(e.relatedTarget)) {
            state.current.isFocusWithin = false;
            removeAllGlobalListeners();
            if (onBlurWithin) onBlurWithin(e);
            if (onFocusWithinChange) onFocusWithinChange(false);
        }
    }, [
        onBlurWithin,
        onFocusWithinChange,
        state,
        removeAllGlobalListeners
    ]);
    let onSyntheticFocus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$interactions$2f$dist$2f$utils$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useSyntheticBlurEvent"])(onBlur);
    let onFocus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCallback"])((e)=>{
        // Ignore events bubbling through portals.
        if (!e.currentTarget.contains(e.target)) return;
        // Double check that document.activeElement actually matches e.target in case a previously chained
        // focus handler already moved focus somewhere else.
        const ownerDocument = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$domHelpers$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getOwnerDocument"])(e.target);
        const activeElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$DOMFunctions$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getActiveElement"])(ownerDocument);
        if (!state.current.isFocusWithin && activeElement === (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$DOMFunctions$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getEventTarget"])(e.nativeEvent)) {
            if (onFocusWithin) onFocusWithin(e);
            if (onFocusWithinChange) onFocusWithinChange(true);
            state.current.isFocusWithin = true;
            onSyntheticFocus(e);
            // Browsers don't fire blur events when elements are removed from the DOM.
            // However, if a focus event occurs outside the element we're tracking, we
            // can manually fire onBlur.
            let currentTarget = e.currentTarget;
            addGlobalListener(ownerDocument, 'focus', (e)=>{
                if (state.current.isFocusWithin && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$DOMFunctions$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["nodeContains"])(currentTarget, e.target)) {
                    let nativeEvent = new ownerDocument.defaultView.FocusEvent('blur', {
                        relatedTarget: e.target
                    });
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$interactions$2f$dist$2f$utils$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["setEventTarget"])(nativeEvent, currentTarget);
                    let event = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$interactions$2f$dist$2f$utils$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createSyntheticEvent"])(nativeEvent);
                    onBlur(event);
                }
            }, {
                capture: true
            });
        }
    }, [
        onFocusWithin,
        onFocusWithinChange,
        onSyntheticFocus,
        addGlobalListener,
        onBlur
    ]);
    if (isDisabled) return {
        focusWithinProps: {
            // These cannot be null, that would conflict in mergeProps
            onFocus: undefined,
            onBlur: undefined
        }
    };
    return {
        focusWithinProps: {
            onFocus: onFocus,
            onBlur: onBlur
        }
    };
}
;
 //# sourceMappingURL=useFocusWithin.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-stately/flags/dist/import.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*
 * Copyright 2023 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ __turbopack_context__.s([
    "enableShadowDOM",
    ()=>$f4e2df6bd15f8569$export$12b151d9882e9985,
    "enableTableNestedRows",
    ()=>$f4e2df6bd15f8569$export$d9d8a0f82de49530,
    "shadowDOM",
    ()=>$f4e2df6bd15f8569$export$98658e8c59125e6a,
    "tableNestedRows",
    ()=>$f4e2df6bd15f8569$export$1b00cb14a96194e6
]);
let $f4e2df6bd15f8569$var$_tableNestedRows = false;
let $f4e2df6bd15f8569$var$_shadowDOM = false;
function $f4e2df6bd15f8569$export$d9d8a0f82de49530() {
    $f4e2df6bd15f8569$var$_tableNestedRows = true;
}
function $f4e2df6bd15f8569$export$1b00cb14a96194e6() {
    return $f4e2df6bd15f8569$var$_tableNestedRows;
}
function $f4e2df6bd15f8569$export$12b151d9882e9985() {
    $f4e2df6bd15f8569$var$_shadowDOM = true;
}
function $f4e2df6bd15f8569$export$98658e8c59125e6a() {
    return $f4e2df6bd15f8569$var$_shadowDOM;
}
;
 //# sourceMappingURL=module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@react-aria/visually-hidden/dist/VisuallyHidden.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VisuallyHidden",
    ()=>$5c3e21d68f1c4674$export$439d29a4e110a164,
    "useVisuallyHidden",
    ()=>$5c3e21d68f1c4674$export$a966af930f325cab
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$mergeProps$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/utils/dist/mergeProps.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$interactions$2f$dist$2f$useFocusWithin$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/interactions/dist/useFocusWithin.mjs [app-rsc] (ecmascript)");
;
;
;
/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ const $5c3e21d68f1c4674$var$styles = {
    border: 0,
    clip: 'rect(0 0 0 0)',
    clipPath: 'inset(50%)',
    height: '1px',
    margin: '-1px',
    overflow: 'hidden',
    padding: 0,
    position: 'absolute',
    width: '1px',
    whiteSpace: 'nowrap'
};
function $5c3e21d68f1c4674$export$a966af930f325cab(props = {}) {
    let { style: style, isFocusable: isFocusable } = props;
    let [isFocused, setFocused] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(false);
    let { focusWithinProps: focusWithinProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$interactions$2f$dist$2f$useFocusWithin$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useFocusWithin"])({
        isDisabled: !isFocusable,
        onFocusWithinChange: (val)=>setFocused(val)
    });
    // If focused, don't hide the element.
    let combinedStyles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (isFocused) return style;
        else if (style) return {
            ...$5c3e21d68f1c4674$var$styles,
            ...style
        };
        else return $5c3e21d68f1c4674$var$styles;
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        isFocused
    ]);
    return {
        visuallyHiddenProps: {
            ...focusWithinProps,
            style: combinedStyles
        }
    };
}
function $5c3e21d68f1c4674$export$439d29a4e110a164(props) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    let { children: children, elementType: Element = 'div', isFocusable: isFocusable, style: style, ...otherProps } = props;
    let { visuallyHiddenProps: visuallyHiddenProps } = $5c3e21d68f1c4674$export$a966af930f325cab(props);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]).createElement(Element, (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$utils$2f$dist$2f$mergeProps$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mergeProps"])(otherProps, visuallyHiddenProps), children);
}
;
 //# sourceMappingURL=VisuallyHidden.module.js.map
}),
"[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "ResizablePanel",
    ()=>ResizablePanel,
    "TRANSITION_DEFAULTS",
    ()=>TRANSITION_DEFAULTS,
    "TRANSITION_EASINGS",
    ()=>TRANSITION_EASINGS,
    "TRANSITION_VARIANTS",
    ()=>TRANSITION_VARIANTS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const ResizablePanel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ResizablePanel() from the server but ResizablePanel is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs <module evaluation>", "ResizablePanel");
const TRANSITION_DEFAULTS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TRANSITION_DEFAULTS() from the server but TRANSITION_DEFAULTS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs <module evaluation>", "TRANSITION_DEFAULTS");
const TRANSITION_EASINGS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TRANSITION_EASINGS() from the server but TRANSITION_EASINGS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs <module evaluation>", "TRANSITION_EASINGS");
const TRANSITION_VARIANTS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TRANSITION_VARIANTS() from the server but TRANSITION_VARIANTS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs <module evaluation>", "TRANSITION_VARIANTS");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "ResizablePanel",
    ()=>ResizablePanel,
    "TRANSITION_DEFAULTS",
    ()=>TRANSITION_DEFAULTS,
    "TRANSITION_EASINGS",
    ()=>TRANSITION_EASINGS,
    "TRANSITION_VARIANTS",
    ()=>TRANSITION_VARIANTS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const ResizablePanel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ResizablePanel() from the server but ResizablePanel is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs", "ResizablePanel");
const TRANSITION_DEFAULTS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TRANSITION_DEFAULTS() from the server but TRANSITION_DEFAULTS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs", "TRANSITION_DEFAULTS");
const TRANSITION_EASINGS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TRANSITION_EASINGS() from the server but TRANSITION_EASINGS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs", "TRANSITION_EASINGS");
const TRANSITION_VARIANTS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TRANSITION_VARIANTS() from the server but TRANSITION_VARIANTS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs", "TRANSITION_VARIANTS");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$framer$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$framer$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$framer$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/react/dist/index.mjs [app-rsc] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// src/index.ts
__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$visually$2d$hidden$2f$dist$2f$VisuallyHidden$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/visually-hidden/dist/VisuallyHidden.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$framer$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/react/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "COMMON_UNITS",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["COMMON_UNITS"],
    "Code",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Code"],
    "Divider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Divider"],
    "Kbd",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Kbd"],
    "ResizablePanel",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$framer$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ResizablePanel"],
    "Spacer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Spacer"],
    "VisuallyHidden",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$visually$2d$hidden$2f$dist$2f$VisuallyHidden$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["VisuallyHidden"],
    "absoluteFullClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["absoluteFullClasses"],
    "accordion",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["accordion"],
    "accordionItem",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["accordionItem"],
    "alert",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["alert"],
    "autocomplete",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["autocomplete"],
    "avatar",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["avatar"],
    "avatarGroup",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["avatarGroup"],
    "badge",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["badge"],
    "baseStyles",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["baseStyles"],
    "breadcrumbItem",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["breadcrumbItem"],
    "breadcrumbs",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["breadcrumbs"],
    "button",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["button"],
    "buttonGroup",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["buttonGroup"],
    "calendar",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["calendar"],
    "card",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["card"],
    "checkbox",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["checkbox"],
    "checkboxGroup",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["checkboxGroup"],
    "chip",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["chip"],
    "circularProgress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["circularProgress"],
    "cn",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"],
    "code",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["code"],
    "collapseAdjacentVariantBorders",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["collapseAdjacentVariantBorders"],
    "colorVariants",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["colorVariants"],
    "colors",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["colors"],
    "commonColors",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["commonColors"],
    "darkLayout",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["darkLayout"],
    "dataFocusVisibleClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["dataFocusVisibleClasses"],
    "dateInput",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["dateInput"],
    "datePicker",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["datePicker"],
    "dateRangePicker",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["dateRangePicker"],
    "defaultLayout",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["defaultLayout"],
    "divider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["divider"],
    "drawer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["drawer"],
    "drip",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["drip"],
    "dropdown",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["dropdown"],
    "dropdownItem",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["dropdownItem"],
    "dropdownMenu",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["dropdownMenu"],
    "dropdownSection",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["dropdownSection"],
    "focusVisibleClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["focusVisibleClasses"],
    "form",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["form"],
    "groupDataFocusVisibleClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["groupDataFocusVisibleClasses"],
    "heroui",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["heroui"],
    "hiddenInputClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["hiddenInputClasses"],
    "image",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["image"],
    "input",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["input"],
    "inputOtp",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["inputOtp"],
    "kbd",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["kbd"],
    "lightLayout",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["lightLayout"],
    "link",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["link"],
    "linkAnchorClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["linkAnchorClasses"],
    "listbox",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["listbox"],
    "listboxItem",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["listboxItem"],
    "listboxSection",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["listboxSection"],
    "menu",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["menu"],
    "menuItem",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["menuItem"],
    "menuSection",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["menuSection"],
    "mergeClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mergeClasses"],
    "modal",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["modal"],
    "navbar",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["navbar"],
    "numberInput",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["numberInput"],
    "pagination",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["pagination"],
    "popover",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["popover"],
    "progress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["progress"],
    "radio",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["radio"],
    "radioGroup",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["radioGroup"],
    "ringClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ringClasses"],
    "scrollShadow",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["scrollShadow"],
    "select",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["select"],
    "semanticColors",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["semanticColors"],
    "skeleton",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["skeleton"],
    "slider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["slider"],
    "snippet",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["snippet"],
    "spacer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["spacer"],
    "spinner",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["spinner"],
    "table",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["table"],
    "tabs",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["tabs"],
    "toast",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["toast"],
    "toastRegion",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["toastRegion"],
    "toggle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["toggle"],
    "translateCenterClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["translateCenterClasses"],
    "tv",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["tv"],
    "twMergeConfig",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["twMergeConfig"],
    "useCode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCode"],
    "useDivider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useDivider"],
    "useKbd",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useKbd"],
    "useSpacer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useSpacer"],
    "user",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["user"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$react$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/react/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/theme/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$accordion$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$badge$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/badge/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$card$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$chip$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/chip/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/code/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$link$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$pagination$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$radio$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$snippet$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/snippet/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spinner$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/spinner/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/switch/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/tooltip/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$user$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/user/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$progress$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$image$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/image/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$navbar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$table$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$skeleton$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/skeleton/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$scroll$2d$shadow$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/scroll-shadow/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$listbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$ripple$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/ripple/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$slider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/slider/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$breadcrumbs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$autocomplete$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$calendar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$date$2d$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$date$2d$picker$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$form$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$alert$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/alert/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$drawer$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$input$2d$otp$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$number$2d$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/number-input/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$react$2d$aria$2f$visually$2d$hidden$2f$dist$2f$VisuallyHidden$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@react-aria/visually-hidden/dist/VisuallyHidden.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$framer$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/framer-utils/dist/index.mjs [app-rsc] (ecmascript)");
__turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$accordion$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$badge$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$card$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$chip$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$link$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$pagination$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$radio$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$snippet$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spinner$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$user$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$progress$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$image$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$navbar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$table$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$skeleton$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$scroll$2d$shadow$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$listbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$ripple$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$slider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$breadcrumbs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$autocomplete$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$calendar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$date$2d$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$date$2d$picker$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$form$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$alert$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$drawer$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$input$2d$otp$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$number$2d$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__), __turbopack_context__.j(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "HeroUIProvider",
    ()=>HeroUIProvider,
    "ProviderContext",
    ()=>ProviderContext,
    "extendVariants",
    ()=>extendVariants,
    "forwardRef",
    ()=>forwardRef,
    "isHeroUIEl",
    ()=>isHeroUIEl,
    "mapPropsVariants",
    ()=>mapPropsVariants,
    "mapPropsVariantsWithCommon",
    ()=>mapPropsVariantsWithCommon,
    "toIterator",
    ()=>toIterator,
    "useInputLabelPlacement",
    ()=>useInputLabelPlacement,
    "useLabelPlacement",
    ()=>useLabelPlacement,
    "useProviderContext",
    ()=>useProviderContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const HeroUIProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call HeroUIProvider() from the server but HeroUIProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs <module evaluation>", "HeroUIProvider");
const ProviderContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ProviderContext() from the server but ProviderContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs <module evaluation>", "ProviderContext");
const extendVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call extendVariants() from the server but extendVariants is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs <module evaluation>", "extendVariants");
const forwardRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call forwardRef() from the server but forwardRef is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs <module evaluation>", "forwardRef");
const isHeroUIEl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call isHeroUIEl() from the server but isHeroUIEl is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs <module evaluation>", "isHeroUIEl");
const mapPropsVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call mapPropsVariants() from the server but mapPropsVariants is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs <module evaluation>", "mapPropsVariants");
const mapPropsVariantsWithCommon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call mapPropsVariantsWithCommon() from the server but mapPropsVariantsWithCommon is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs <module evaluation>", "mapPropsVariantsWithCommon");
const toIterator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call toIterator() from the server but toIterator is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs <module evaluation>", "toIterator");
const useInputLabelPlacement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useInputLabelPlacement() from the server but useInputLabelPlacement is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs <module evaluation>", "useInputLabelPlacement");
const useLabelPlacement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useLabelPlacement() from the server but useLabelPlacement is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs <module evaluation>", "useLabelPlacement");
const useProviderContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useProviderContext() from the server but useProviderContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs <module evaluation>", "useProviderContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "HeroUIProvider",
    ()=>HeroUIProvider,
    "ProviderContext",
    ()=>ProviderContext,
    "extendVariants",
    ()=>extendVariants,
    "forwardRef",
    ()=>forwardRef,
    "isHeroUIEl",
    ()=>isHeroUIEl,
    "mapPropsVariants",
    ()=>mapPropsVariants,
    "mapPropsVariantsWithCommon",
    ()=>mapPropsVariantsWithCommon,
    "toIterator",
    ()=>toIterator,
    "useInputLabelPlacement",
    ()=>useInputLabelPlacement,
    "useLabelPlacement",
    ()=>useLabelPlacement,
    "useProviderContext",
    ()=>useProviderContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const HeroUIProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call HeroUIProvider() from the server but HeroUIProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs", "HeroUIProvider");
const ProviderContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ProviderContext() from the server but ProviderContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs", "ProviderContext");
const extendVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call extendVariants() from the server but extendVariants is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs", "extendVariants");
const forwardRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call forwardRef() from the server but forwardRef is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs", "forwardRef");
const isHeroUIEl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call isHeroUIEl() from the server but isHeroUIEl is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs", "isHeroUIEl");
const mapPropsVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call mapPropsVariants() from the server but mapPropsVariants is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs", "mapPropsVariants");
const mapPropsVariantsWithCommon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call mapPropsVariantsWithCommon() from the server but mapPropsVariantsWithCommon is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs", "mapPropsVariantsWithCommon");
const toIterator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call toIterator() from the server but toIterator is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs", "toIterator");
const useInputLabelPlacement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useInputLabelPlacement() from the server but useInputLabelPlacement is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs", "useInputLabelPlacement");
const useLabelPlacement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useLabelPlacement() from the server but useLabelPlacement is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs", "useLabelPlacement");
const useProviderContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useProviderContext() from the server but useProviderContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs", "useProviderContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/system/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/chunk-GQLG7IS2.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>a,
    "b",
    ()=>u,
    "c",
    ()=>h,
    "d",
    ()=>x,
    "e",
    ()=>k,
    "f",
    ()=>A,
    "g",
    ()=>d,
    "h",
    ()=>c,
    "i",
    ()=>O,
    "j",
    ()=>g,
    "k",
    ()=>p
]);
var y = /\s+/g, a = (t)=>typeof t != "string" || !t ? t : t.replace(y, " ").trim(), u = (...t)=>{
    let r = [], n = (e)=>{
        if (!e && e !== 0 && e !== 0n) return;
        if (Array.isArray(e)) {
            for(let s = 0, o = e.length; s < o; s++)n(e[s]);
            return;
        }
        let f = typeof e;
        if (f === "string" || f === "number" || f === "bigint") {
            if (f === "number" && e !== e) return;
            r.push(String(e));
        } else if (f === "object") {
            let s = Object.keys(e);
            for(let o = 0, i = s.length; o < i; o++){
                let l = s[o];
                e[l] && r.push(l);
            }
        }
    };
    for(let e = 0, f = t.length; e < f; e++){
        let s = t[e];
        s != null && n(s);
    }
    return r.length > 0 ? a(r.join(" ")) : void 0;
}, h = (t)=>t === false ? "false" : t === true ? "true" : t === 0 ? "0" : t, x = (t)=>{
    if (!t || typeof t != "object") return true;
    for(let r in t)return false;
    return true;
}, k = (t, r)=>{
    if (t === r) return true;
    if (!t || !r) return false;
    let n = Object.keys(t), e = Object.keys(r);
    if (n.length !== e.length) return false;
    for(let f = 0; f < n.length; f++){
        let s = n[f];
        if (!e.includes(s) || t[s] !== r[s]) return false;
    }
    return true;
}, A = (t)=>t === true || t === false, d = (t, r)=>{
    for(let n in r)if (Object.prototype.hasOwnProperty.call(r, n)) {
        let e = r[n];
        n in t ? t[n] = u(t[n], e) : t[n] = e;
    }
    return t;
}, c = (t, r)=>{
    for(let n = 0; n < t.length; n++){
        let e = t[n];
        Array.isArray(e) ? c(e, r) : e && r.push(e);
    }
};
function O(t) {
    let r = [];
    return c(t, r), r;
}
var g = (...t)=>{
    let r = [];
    c(t, r);
    let n = [];
    for(let e = 0; e < r.length; e++)r[e] && n.push(r[e]);
    return n;
}, p = (t, r)=>{
    let n = {};
    for(let e in t){
        let f = t[e];
        if (e in r) {
            let s = r[e];
            Array.isArray(f) || Array.isArray(s) ? n[e] = g(s, f) : typeof f == "object" && typeof s == "object" && f && s ? n[e] = p(f, s) : n[e] = s + " " + f;
        } else n[e] = f;
    }
    for(let e in r)e in t || (n[e] = r[e]);
    return n;
};
;
}),
"[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/chunk-IFWU2MEM.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>Q,
    "b",
    ()=>S,
    "c",
    ()=>le
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/chunk-GQLG7IS2.js [app-rsc] (ecmascript)");
;
var Q = {
    twMerge: true,
    twMergeConfig: {},
    responsiveVariants: false
};
function ne() {
    let b = null, w = {}, A = false;
    return {
        get cachedTwMerge () {
            return b;
        },
        set cachedTwMerge (u){
            b = u;
        },
        get cachedTwMergeConfig () {
            return w;
        },
        set cachedTwMergeConfig (u){
            w = u;
        },
        get didTwMergeConfigChange () {
            return A;
        },
        set didTwMergeConfigChange (u){
            A = u;
        },
        reset () {
            b = null, w = {}, A = false;
        }
    };
}
var S = ne();
var le = (b$1)=>{
    let w = (u1, $)=>{
        let { extend: c$1 = null, slots: M = {}, variants: q = {}, compoundVariants: L = [], compoundSlots: v = [], defaultVariants: U = {} } = u1, d$1 = {
            ...Q,
            ...$
        }, x = c$1?.base ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["b"])(c$1.base, u1?.base) : u1?.base, p = c$1?.variants && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(c$1.variants) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["k"])(q, c$1.variants) : q, E = c$1?.defaultVariants && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(c$1.defaultVariants) ? {
            ...c$1.defaultVariants,
            ...U
        } : U;
        !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(d$1.twMergeConfig) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["e"])(d$1.twMergeConfig, S.cachedTwMergeConfig) && (S.didTwMergeConfigChange = true, S.cachedTwMergeConfig = d$1.twMergeConfig);
        let N = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(c$1?.slots), O = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(M) ? {} : {
            base: (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["b"])(u1?.base, N && c$1?.base),
            ...M
        }, j$1 = N ? O : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["g"])({
            ...c$1?.slots
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(O) ? {
            base: u1?.base
        } : O), T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(c$1?.compoundVariants) ? L : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["j"])(c$1?.compoundVariants, L), y = (h)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(p) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(M) && N) return b$1(x, h?.class, h?.className)(d$1);
            if (T && !Array.isArray(T)) throw new TypeError(`The "compoundVariants" prop must be an array. Received: ${typeof T}`);
            if (v && !Array.isArray(v)) throw new TypeError(`The "compoundSlots" prop must be an array. Received: ${typeof v}`);
            let Y = (t, e, n = [], a$1)=>{
                let r = n;
                if (typeof e == "string") {
                    let i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["a"])(e).split(" ");
                    for(let l = 0; l < i.length; l++)r.push(`${t}:${i[l]}`);
                } else if (Array.isArray(e)) for(let s = 0; s < e.length; s++)r.push(`${t}:${e[s]}`);
                else if (typeof e == "object" && typeof a$1 == "string" && a$1 in e) {
                    let s = e[a$1];
                    if (s && typeof s == "string") {
                        let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["a"])(s).split(" "), f = [];
                        for(let o = 0; o < l.length; o++)f.push(`${t}:${l[o]}`);
                        r[a$1] = r[a$1] ? r[a$1].concat(f) : f;
                    } else if (Array.isArray(s) && s.length > 0) {
                        let i = [];
                        for(let l = 0; l < s.length; l++)i.push(`${t}:${s[l]}`);
                        r[a$1] = i;
                    }
                }
                return r;
            }, W = (t, e = p, n = null, a = null)=>{
                let r = e[t];
                if (!r || (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(r)) return null;
                let s = a?.[t] ?? h?.[t];
                if (s === null) return null;
                let i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["c"])(s), l = Array.isArray(d$1.responsiveVariants) && d$1.responsiveVariants.length > 0 || d$1.responsiveVariants === true, f = E?.[t], o = [];
                if (typeof i == "object" && l) for (let [C, H] of Object.entries(i)){
                    let te = r[H];
                    if (C === "initial") {
                        f = H;
                        continue;
                    }
                    Array.isArray(d$1.responsiveVariants) && !d$1.responsiveVariants.includes(C) || (o = Y(C, te, o, n));
                }
                let V = i != null && typeof i != "object" ? i : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["c"])(f), m = r[V || "false"];
                return typeof o == "object" && typeof n == "string" && o[n] ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["g"])(o, m) : o.length > 0 ? (o.push(m), n === "base" ? o.join(" ") : o) : m;
            }, Z = ()=>{
                if (!p) return null;
                let t = Object.keys(p), e = [];
                for(let n = 0; n < t.length; n++){
                    let a = W(t[n], p);
                    a && e.push(a);
                }
                return e;
            }, _ = (t, e)=>{
                if (!p || typeof p != "object") return null;
                let n = [];
                for(let a in p){
                    let r = W(a, p, t, e), s = t === "base" && typeof r == "string" ? r : r && r[t];
                    s && n.push(s);
                }
                return n;
            }, z = {};
            for(let t in h){
                let e = h[t];
                e !== void 0 && (z[t] = e);
            }
            let D = (t, e)=>{
                let n = typeof h?.[t] == "object" ? {
                    [t]: h[t]?.initial
                } : {};
                return {
                    ...E,
                    ...z,
                    ...n,
                    ...e
                };
            }, G = (t = [], e)=>{
                let n = [], a = t.length;
                for(let r = 0; r < a; r++){
                    let { class: s, className: i, ...l } = t[r], f = true, o = D(null, e);
                    for(let V in l){
                        let m = l[V], C = o[V];
                        if (Array.isArray(m)) {
                            if (!m.includes(C)) {
                                f = false;
                                break;
                            }
                        } else {
                            if ((m == null || m === false) && (C == null || C === false)) continue;
                            if (C !== m) {
                                f = false;
                                break;
                            }
                        }
                    }
                    f && (s && n.push(s), i && n.push(i));
                }
                return n;
            }, K = (t)=>{
                let e = G(T, t);
                if (!Array.isArray(e)) return e;
                let n = {}, a = b$1;
                for(let r = 0; r < e.length; r++){
                    let s = e[r];
                    if (typeof s == "string") n.base = a(n.base, s)(d$1);
                    else if (typeof s == "object") for(let i in s)n[i] = a(n[i], s[i])(d$1);
                }
                return n;
            }, ee = (t)=>{
                if (v.length < 1) return null;
                let e = {}, n = D(null, t);
                for(let a = 0; a < v.length; a++){
                    let { slots: r = [], class: s, className: i, ...l } = v[a];
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(l)) {
                        let f = true;
                        for(let o in l){
                            let V = n[o], m = l[o];
                            if (V === void 0 || (Array.isArray(m) ? !m.includes(V) : m !== V)) {
                                f = false;
                                break;
                            }
                        }
                        if (!f) continue;
                    }
                    for(let f = 0; f < r.length; f++){
                        let o = r[f];
                        e[o] || (e[o] = []), e[o].push([
                            s,
                            i
                        ]);
                    }
                }
                return e;
            };
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(M) || !N) {
                let t = {};
                if (typeof j$1 == "object" && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(j$1)) {
                    let e = b$1;
                    for(let n in j$1)t[n] = (a)=>{
                        let r = K(a), s = ee(a);
                        return e(j$1[n], _(n, a), ("TURBOPACK compile-time truthy", 1) ? r[n] : "TURBOPACK unreachable", s ? s[n] : void 0, a?.class, a?.className)(d$1);
                    };
                }
                return t;
            }
            return b$1(x, Z(), G(T), h?.class, h?.className)(d$1);
        }, X = ()=>{
            if (!(!p || typeof p != "object")) return Object.keys(p);
        };
        return y.variantKeys = X(), y.extend = c$1, y.base = x, y.slots = j$1, y.variants = p, y.defaultVariants = E, y.compoundSlots = v, y.compoundVariants = T, y;
    };
    return {
        tv: w,
        createTV: (u1)=>($, c)=>w($, c ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["k"])(u1, c) : u1)
    };
};
;
}),
"[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/index.js [app-rsc] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>i,
    "createTV",
    ()=>C,
    "tv",
    ()=>T
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/chunk-IFWU2MEM.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/tailwind-variants/dist/chunk-GQLG7IS2.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-rsc] (ecmascript)");
;
;
;
;
;
var f = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["d"])(e) ? __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["twMerge"] : (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["extendTailwindMerge"])({
        ...e,
        extend: {
            theme: e.theme,
            classGroups: e.classGroups,
            conflictingClassGroupModifiers: e.conflictingClassGroupModifiers,
            conflictingClassGroups: e.conflictingClassGroups,
            ...e.extend
        }
    }), i = (...e)=>(a)=>{
        let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$GQLG7IS2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["b"])(e);
        return !t || !a.twMerge ? t : ((!__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["b"].cachedTwMerge || __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["b"].didTwMergeConfigChange) && (__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["b"].didTwMergeConfigChange = false, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["b"].cachedTwMerge = f(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["b"].cachedTwMergeConfig)), __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["b"].cachedTwMerge(t) || void 0);
    };
var { createTV: C, tv: T } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$tailwind$2d$variants$2f$dist$2f$chunk$2d$IFWU2MEM$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["c"])(i);
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/shared-utils/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/demi/react19/getInertValue.ts
__turbopack_context__.s([
    "__DEV__",
    ()=>__DEV__,
    "__TEST__",
    ()=>__TEST__,
    "arrayToObject",
    ()=>arrayToObject,
    "callAll",
    ()=>callAll,
    "callAllHandlers",
    ()=>callAllHandlers,
    "capitalize",
    ()=>capitalize,
    "chain",
    ()=>chain,
    "clamp",
    ()=>clamp,
    "clampPercentage",
    ()=>clampPercentage,
    "cleanObject",
    ()=>cleanObject,
    "cleanObjectKeys",
    ()=>cleanObjectKeys,
    "clsx",
    ()=>clsx,
    "compact",
    ()=>compact,
    "copyObject",
    ()=>copyObject,
    "dataAttr",
    ()=>dataAttr,
    "debounce",
    ()=>debounce,
    "extractProperty",
    ()=>extractProperty,
    "get",
    ()=>get,
    "getGregorianYearOffset",
    ()=>getGregorianYearOffset,
    "getInertValue",
    ()=>getInertValue,
    "getKeyValue",
    ()=>getKeyValue,
    "getMargin",
    ()=>getMargin,
    "getProp",
    ()=>getProp,
    "getUniqueID",
    ()=>getUniqueID,
    "idsUpdaterMap",
    ()=>idsUpdaterMap,
    "intersectionBy",
    ()=>intersectionBy,
    "isArray",
    ()=>isArray,
    "isEmpty",
    ()=>isEmpty,
    "isEmptyArray",
    ()=>isEmptyArray,
    "isEmptyObject",
    ()=>isEmptyObject,
    "isFunction",
    ()=>isFunction,
    "isNumeric",
    ()=>isNumeric,
    "isObject",
    ()=>isObject,
    "isPatternNumeric",
    ()=>isPatternNumeric,
    "kebabCase",
    ()=>kebabCase,
    "mapKeys",
    ()=>mapKeys,
    "mergeIds",
    ()=>mergeIds,
    "mergeProps",
    ()=>mergeProps,
    "mergeRefs",
    ()=>mergeRefs,
    "objectToDeps",
    ()=>objectToDeps,
    "omit",
    ()=>omit,
    "omitObject",
    ()=>omitObject,
    "range",
    ()=>range,
    "removeEvents",
    ()=>removeEvents,
    "renameProp",
    ()=>renameProp,
    "safeAriaLabel",
    ()=>safeAriaLabel,
    "safeText",
    ()=>safeText,
    "uniqBy",
    ()=>uniqBy,
    "warn",
    ()=>warn
]);
var getInertValue = (v)=>{
    return v;
};
// src/common/assertion.ts
var __DEV__ = ("TURBOPACK compile-time value", "development") !== "production";
var __TEST__ = ("TURBOPACK compile-time value", "development") === "test";
function isArray(value) {
    return Array.isArray(value);
}
function isEmptyArray(value) {
    return isArray(value) && value.length === 0;
}
function isObject(value) {
    const type = typeof value;
    return value != null && (type === "object" || type === "function") && !isArray(value);
}
function isEmptyObject(value) {
    return isObject(value) && Object.keys(value).length === 0;
}
function isEmpty(value) {
    if (isArray(value)) return isEmptyArray(value);
    if (isObject(value)) return isEmptyObject(value);
    if (value == null || value === "") return true;
    return false;
}
function isFunction(value) {
    return typeof value === "function";
}
var dataAttr = (condition)=>condition ? "true" : void 0;
var isNumeric = (value)=>value != null && parseInt(value.toString(), 10) > 0;
// src/common/clsx.ts
function toVal(mix) {
    var k, y, str = "";
    if (typeof mix === "string" || typeof mix === "number") {
        str += mix;
    } else if (typeof mix === "object") {
        if (Array.isArray(mix)) {
            for(k = 0; k < mix.length; k++){
                if (mix[k]) {
                    if (y = toVal(mix[k])) {
                        str && (str += " ");
                        str += y;
                    }
                }
            }
        } else {
            for(k in mix){
                if (mix[k]) {
                    str && (str += " ");
                    str += k;
                }
            }
        }
    }
    return str;
}
function clsx(...args) {
    var i = 0, tmp, x, str = "";
    while(i < args.length){
        if (tmp = args[i++]) {
            if (x = toVal(tmp)) {
                str && (str += " ");
                str += x;
            }
        }
    }
    return str;
}
// src/common/object.ts
var renameProp = (oldProp, newProp, { [oldProp]: old, ...others })=>({
        [newProp]: old,
        ...others
    });
var copyObject = (obj)=>{
    if (!isObject(obj)) return obj;
    if (obj instanceof Array) return [
        ...obj
    ];
    return {
        ...obj
    };
};
var omitObject = (obj, omitKeys)=>{
    if (!isObject(obj)) return obj;
    if (obj instanceof Array) return [
        ...obj
    ];
    const newObj = {
        ...obj
    };
    omitKeys.forEach((key)=>newObj[key] && delete newObj[key]);
    return newObj;
};
var cleanObject = (obj)=>{
    if (!isObject(obj)) return obj;
    if (obj instanceof Array) return [
        ...obj
    ];
    const newObj = {
        ...obj
    };
    Object.keys(newObj).forEach((key)=>{
        if (newObj[key] === void 0 || newObj[key] === null) {
            delete newObj[key];
        }
    });
    return newObj;
};
var cleanObjectKeys = (obj, keys = [])=>{
    if (!isObject(obj)) return obj;
    if (obj instanceof Array) return [
        ...obj
    ];
    const newObj = {
        ...obj
    };
    keys.forEach((key)=>{
        if (newObj[key]) {
            delete newObj[key];
        }
    });
    return newObj;
};
var getKeyValue = (obj, key)=>{
    if (!isObject(obj)) return obj;
    if (obj instanceof Array) return [
        ...obj
    ];
    return obj[key];
};
var getProp = (obj, path, fallback, index)=>{
    const key = typeof path === "string" ? path.split(".") : [
        path
    ];
    for(index = 0; index < key.length; index += 1){
        if (!obj) break;
        obj = obj[key[index]];
    }
    return obj === void 0 ? fallback : obj;
};
var arrayToObject = (arr)=>{
    if (!arr.length || !Array.isArray(arr)) return {};
    return arr.reduce((acc, item)=>{
        return {
            ...acc,
            ...item
        };
    }, {});
};
function compact(object) {
    const clone = Object.assign({}, object);
    for(let key in clone){
        if (clone[key] === void 0) delete clone[key];
    }
    return clone;
}
// src/common/text.ts
var safeText = (text)=>{
    if ((text == null ? void 0 : text.length) <= 4) return text;
    return text == null ? void 0 : text.slice(0, 3);
};
var safeAriaLabel = (...texts)=>{
    let ariaLabel = " ";
    for (const text of texts){
        if (typeof text === "string" && text.length > 0) {
            ariaLabel = text;
            break;
        }
    }
    return ariaLabel;
};
// src/common/dimensions.ts
var getMargin = (num)=>{
    return `calc(${num * 15.25}pt + 1px * ${num - 1})`;
};
// src/common/functions.ts
var capitalize = (s)=>{
    return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : "";
};
function callAllHandlers(...fns) {
    return function func(event) {
        fns.some((fn)=>{
            fn == null ? void 0 : fn(event);
            return event == null ? void 0 : event.defaultPrevented;
        });
    };
}
function callAll(...fns) {
    return function mergedFn(arg) {
        fns.forEach((fn)=>{
            fn == null ? void 0 : fn(arg);
        });
    };
}
function extractProperty(key, defaultValue, ...objs) {
    let result = defaultValue;
    for (const obj of objs){
        if (obj && key in obj && !!obj[key]) {
            result = obj[key];
        }
    }
    return result;
}
function getUniqueID(prefix) {
    return `${prefix}-${Math.floor(Math.random() * 1e6)}`;
}
function removeEvents(input) {
    for(const key in input){
        if (key.startsWith("on")) {
            delete input[key];
        }
    }
    return input;
}
function objectToDeps(obj) {
    if (!obj || typeof obj !== "object") {
        return "";
    }
    try {
        return JSON.stringify(obj);
    } catch  {
        return "";
    }
}
function debounce(func, waitMilliseconds = 0) {
    let timeout;
    return function(...args) {
        const later = ()=>{
            timeout = void 0;
            func.apply(this, args);
        };
        if (timeout !== void 0) {
            clearTimeout(timeout);
        }
        timeout = setTimeout(later, waitMilliseconds);
    };
}
function uniqBy(arr, iteratee) {
    if (typeof iteratee === "string") {
        iteratee = (item)=>item[iteratee];
    }
    return arr.filter((x, i, self)=>i === self.findIndex((y)=>iteratee(x) === iteratee(y)));
}
var omit = (obj, keys)=>{
    const res = Object.assign({}, obj);
    keys.forEach((key)=>{
        delete res[key];
    });
    return res;
};
var kebabCase = (s)=>{
    return s.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
};
var mapKeys = (obj, iteratee)=>{
    return Object.fromEntries(Object.entries(obj).map(([key, value])=>[
            iteratee(value, key),
            value
        ]));
};
var get = (object, path, defaultValue)=>{
    const keys = Array.isArray(path) ? path : path.replace(/\[(\d+)\]/g, ".$1").split(".");
    let res = object;
    for (const key of keys){
        res = res == null ? void 0 : res[key];
        if (res === void 0) {
            return defaultValue;
        }
    }
    return res;
};
var intersectionBy = (...args)=>{
    if (args.length < 2) {
        throw new Error("intersectionBy requires at least two arrays and an iteratee");
    }
    const iteratee = args[args.length - 1];
    const arrays = args.slice(0, -1);
    if (arrays.length === 0) {
        return [];
    }
    const getIterateeValue = (item)=>{
        if (typeof iteratee === "function") {
            return iteratee(item);
        } else if (typeof iteratee === "string") {
            return item[iteratee];
        } else {
            throw new Error("Iteratee must be a function or a string key of the array elements");
        }
    };
    const [first, ...rest] = arrays;
    const transformedFirst = first.map((item)=>getIterateeValue(item));
    const transformedSets = rest.map((array)=>new Set(array.map((item)=>getIterateeValue(item))));
    const res = [];
    const seen = /* @__PURE__ */ new Set();
    for(let i = 0; i < first.length; i++){
        const item = first[i];
        const transformed = transformedFirst[i];
        if (seen.has(transformed)) {
            continue;
        }
        const existsInAll = transformedSets.every((set)=>set.has(transformed));
        if (existsInAll) {
            res.push(item);
            seen.add(transformed);
        }
    }
    return res;
};
// src/common/numbers.ts
function range(start, end) {
    const length = end - start + 1;
    return Array.from({
        length
    }, (_, index)=>index + start);
}
function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}
function clampPercentage(value, max = 100) {
    return Math.min(Math.max(value, 0), max);
}
// src/common/console.ts
var warningStack = {};
function warn(message, component, ...args) {
    const tag = component ? ` [${component}]` : " ";
    const log = `[Hero UI]${tag}: ${message}`;
    if (typeof console === "undefined") return;
    if (warningStack[log]) return;
    warningStack[log] = true;
    if ("TURBOPACK compile-time truthy", 1) {
        return console.warn(log, args);
    }
}
// src/common/dates.ts
function getGregorianYearOffset(identifier) {
    switch(identifier){
        case "buddhist":
            return 543;
        case "ethiopic":
        case "ethioaa":
            return -8;
        case "coptic":
            return -284;
        case "hebrew":
            return 3760;
        case "indian":
            return -78;
        case "islamic-civil":
        case "islamic-tbla":
        case "islamic-umalqura":
            return -579;
        case "persian":
            return -600;
        case "roc":
        case "japanese":
        case "gregory":
        default:
            return 0;
    }
}
// src/common/regex.ts
var isPatternNumeric = (pattern)=>{
    const numericPattern = /(^|\W)[0-9](\W|$)/;
    return numericPattern.test(pattern) && !/[^\d\^$\[\]\(\)\*\+\-\.\|]/.test(pattern);
};
// src/common/ra.ts
function chain(...callbacks) {
    return (...args)=>{
        for (let callback of callbacks){
            if (typeof callback === "function") {
                callback(...args);
            }
        }
    };
}
var idsUpdaterMap = /* @__PURE__ */ new Map();
function mergeIds(idA, idB) {
    if (idA === idB) {
        return idA;
    }
    let setIdsA = idsUpdaterMap.get(idA);
    if (setIdsA) {
        setIdsA.forEach((ref)=>ref.current = idB);
        return idB;
    }
    let setIdsB = idsUpdaterMap.get(idB);
    if (setIdsB) {
        setIdsB.forEach((ref)=>ref.current = idA);
        return idA;
    }
    return idB;
}
function mergeProps(...args) {
    let result = {
        ...args[0]
    };
    for(let i = 1; i < args.length; i++){
        let props = args[i];
        for(let key in props){
            let a = result[key];
            let b = props[key];
            if (typeof a === "function" && typeof b === "function" && // This is a lot faster than a regex.
            key[0] === "o" && key[1] === "n" && key.charCodeAt(2) >= /* 'A' */ 65 && key.charCodeAt(2) <= /* 'Z' */ 90) {
                result[key] = chain(a, b);
            } else if ((key === "className" || key === "UNSAFE_className") && typeof a === "string" && typeof b === "string") {
                result[key] = clsx(a, b);
            } else if (key === "id" && a && b) {
                result.id = mergeIds(a, b);
            } else {
                result[key] = b !== void 0 ? b : a;
            }
        }
    }
    return result;
}
function mergeRefs(...refs) {
    if (refs.length === 1 && refs[0]) {
        return refs[0];
    }
    return (value)=>{
        let hasCleanup = false;
        const cleanups = refs.map((ref)=>{
            const cleanup = setRef(ref, value);
            hasCleanup || (hasCleanup = typeof cleanup == "function");
            return cleanup;
        });
        if (hasCleanup) {
            return ()=>{
                cleanups.forEach((cleanup, i)=>{
                    if (typeof cleanup === "function") {
                        cleanup == null ? void 0 : cleanup();
                    } else {
                        setRef(refs[i], null);
                    }
                });
            };
        }
    };
}
function setRef(ref, value) {
    if (typeof ref === "function") {
        return ()=>ref(value);
    } else if (ref != null) {
        if ("current" in ref) {
            ref.current = value;
        }
    }
}
;
}),
"[project]/next-admin-dashboard/node_modules/flat/index.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = flatten;
flatten.flatten = flatten;
flatten.unflatten = unflatten;
function isBuffer(obj) {
    return obj && obj.constructor && typeof obj.constructor.isBuffer === 'function' && obj.constructor.isBuffer(obj);
}
function keyIdentity(key) {
    return key;
}
function flatten(target, opts) {
    opts = opts || {};
    const delimiter = opts.delimiter || '.';
    const maxDepth = opts.maxDepth;
    const transformKey = opts.transformKey || keyIdentity;
    const output = {};
    function step(object, prev, currentDepth) {
        currentDepth = currentDepth || 1;
        Object.keys(object).forEach(function(key) {
            const value = object[key];
            const isarray = opts.safe && Array.isArray(value);
            const type = Object.prototype.toString.call(value);
            const isbuffer = isBuffer(value);
            const isobject = type === '[object Object]' || type === '[object Array]';
            const newKey = prev ? prev + delimiter + transformKey(key) : transformKey(key);
            if (!isarray && !isbuffer && isobject && Object.keys(value).length && (!opts.maxDepth || currentDepth < maxDepth)) {
                return step(value, newKey, currentDepth + 1);
            }
            output[newKey] = value;
        });
    }
    step(target);
    return output;
}
function unflatten(target, opts) {
    opts = opts || {};
    const delimiter = opts.delimiter || '.';
    const overwrite = opts.overwrite || false;
    const transformKey = opts.transformKey || keyIdentity;
    const result = {};
    const isbuffer = isBuffer(target);
    if (isbuffer || Object.prototype.toString.call(target) !== '[object Object]') {
        return target;
    }
    // safely ensure that the key is
    // an integer.
    function getkey(key) {
        const parsedKey = Number(key);
        return isNaN(parsedKey) || key.indexOf('.') !== -1 || opts.object ? key : parsedKey;
    }
    function addKeys(keyPrefix, recipient, target) {
        return Object.keys(target).reduce(function(result, key) {
            result[keyPrefix + delimiter + key] = target[key];
            return result;
        }, recipient);
    }
    function isEmpty(val) {
        const type = Object.prototype.toString.call(val);
        const isArray = type === '[object Array]';
        const isObject = type === '[object Object]';
        if (!val) {
            return true;
        } else if (isArray) {
            return !val.length;
        } else if (isObject) {
            return !Object.keys(val).length;
        }
    }
    target = Object.keys(target).reduce(function(result, key) {
        const type = Object.prototype.toString.call(target[key]);
        const isObject = type === '[object Object]' || type === '[object Array]';
        if (!isObject || isEmpty(target[key])) {
            result[key] = target[key];
            return result;
        } else {
            return addKeys(key, result, flatten(target[key], opts));
        }
    }, {});
    Object.keys(target).forEach(function(key) {
        const split = key.split(delimiter).map(transformKey);
        let key1 = getkey(split.shift());
        let key2 = getkey(split[0]);
        let recipient = result;
        while(key2 !== undefined){
            if (key1 === '__proto__') {
                return;
            }
            const type = Object.prototype.toString.call(recipient[key1]);
            const isobject = type === '[object Object]' || type === '[object Array]';
            // do not write over falsey, non-undefined values if overwrite is false
            if (!overwrite && !isobject && typeof recipient[key1] !== 'undefined') {
                return;
            }
            if (overwrite && !isobject || !overwrite && recipient[key1] == null) {
                recipient[key1] = typeof key2 === 'number' && !opts.object ? [] : {};
            }
            recipient = recipient[key1];
            if (split.length > 0) {
                key1 = getkey(split.shift());
                key2 = getkey(split[0]);
            }
        }
        // unflatten again for 'messy objects'
        recipient[key1] = unflatten(target[key], opts);
    });
    return result;
}
}),
"[project]/next-admin-dashboard/node_modules/color2k/dist/index.exports.import.es.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * A simple guard function:
 *
 * ```js
 * Math.min(Math.max(low, value), high)
 * ```
 */ __turbopack_context__.s([
    "ColorError",
    ()=>ColorError$1,
    "adjustHue",
    ()=>adjustHue,
    "darken",
    ()=>darken,
    "desaturate",
    ()=>desaturate,
    "getContrast",
    ()=>getContrast,
    "getLuminance",
    ()=>getLuminance,
    "getScale",
    ()=>getScale,
    "guard",
    ()=>guard,
    "hasBadContrast",
    ()=>hasBadContrast,
    "hsla",
    ()=>hsla,
    "lighten",
    ()=>lighten,
    "mix",
    ()=>mix,
    "opacify",
    ()=>opacify,
    "parseToHsla",
    ()=>parseToHsla,
    "parseToRgba",
    ()=>parseToRgba,
    "readableColor",
    ()=>readableColor,
    "readableColorIsBlack",
    ()=>readableColorIsBlack,
    "rgba",
    ()=>rgba,
    "saturate",
    ()=>saturate,
    "toHex",
    ()=>toHex,
    "toHsla",
    ()=>toHsla,
    "toRgba",
    ()=>toRgba,
    "transparentize",
    ()=>transparentize
]);
function guard(low, high, value) {
    return Math.min(Math.max(low, value), high);
}
class ColorError extends Error {
    constructor(color){
        super(`Failed to parse color: "${color}"`);
    }
}
var ColorError$1 = ColorError;
/**
 * Parses a color into red, gree, blue, alpha parts
 *
 * @param color the input color. Can be a RGB, RBGA, HSL, HSLA, or named color
 */ function parseToRgba(color) {
    if (typeof color !== 'string') throw new ColorError$1(color);
    if (color.trim().toLowerCase() === 'transparent') return [
        0,
        0,
        0,
        0
    ];
    let normalizedColor = color.trim();
    normalizedColor = namedColorRegex.test(color) ? nameToHex(color) : color;
    const reducedHexMatch = reducedHexRegex.exec(normalizedColor);
    if (reducedHexMatch) {
        const arr = Array.from(reducedHexMatch).slice(1);
        return [
            ...arr.slice(0, 3).map((x)=>parseInt(r(x, 2), 16)),
            parseInt(r(arr[3] || 'f', 2), 16) / 255
        ];
    }
    const hexMatch = hexRegex.exec(normalizedColor);
    if (hexMatch) {
        const arr = Array.from(hexMatch).slice(1);
        return [
            ...arr.slice(0, 3).map((x)=>parseInt(x, 16)),
            parseInt(arr[3] || 'ff', 16) / 255
        ];
    }
    const rgbaMatch = rgbaRegex.exec(normalizedColor);
    if (rgbaMatch) {
        const arr = Array.from(rgbaMatch).slice(1);
        return [
            ...arr.slice(0, 3).map((x)=>parseInt(x, 10)),
            parseFloat(arr[3] || '1')
        ];
    }
    const hslaMatch = hslaRegex.exec(normalizedColor);
    if (hslaMatch) {
        const [h, s, l, a] = Array.from(hslaMatch).slice(1).map(parseFloat);
        if (guard(0, 100, s) !== s) throw new ColorError$1(color);
        if (guard(0, 100, l) !== l) throw new ColorError$1(color);
        return [
            ...hslToRgb(h, s, l),
            Number.isNaN(a) ? 1 : a
        ];
    }
    throw new ColorError$1(color);
}
function hash(str) {
    let hash = 5381;
    let i = str.length;
    while(i){
        hash = hash * 33 ^ str.charCodeAt(--i);
    }
    /* JavaScript does bitwise operations (like XOR, above) on 32-bit signed
   * integers. Since we want the results to be always positive, convert the
   * signed int to an unsigned by doing an unsigned bitshift. */ return (hash >>> 0) % 2341;
}
const colorToInt = (x)=>parseInt(x.replace(/_/g, ''), 36);
const compressedColorMap = '1q29ehhb 1n09sgk7 1kl1ekf_ _yl4zsno 16z9eiv3 1p29lhp8 _bd9zg04 17u0____ _iw9zhe5 _to73___ _r45e31e _7l6g016 _jh8ouiv _zn3qba8 1jy4zshs 11u87k0u 1ro9yvyo 1aj3xael 1gz9zjz0 _3w8l4xo 1bf1ekf_ _ke3v___ _4rrkb__ 13j776yz _646mbhl _nrjr4__ _le6mbhl 1n37ehkb _m75f91n _qj3bzfz 1939yygw 11i5z6x8 _1k5f8xs 1509441m 15t5lwgf _ae2th1n _tg1ugcv 1lp1ugcv 16e14up_ _h55rw7n _ny9yavn _7a11xb_ 1ih442g9 _pv442g9 1mv16xof 14e6y7tu 1oo9zkds 17d1cisi _4v9y70f _y98m8kc 1019pq0v 12o9zda8 _348j4f4 1et50i2o _8epa8__ _ts6senj 1o350i2o 1mi9eiuo 1259yrp0 1ln80gnw _632xcoy 1cn9zldc _f29edu4 1n490c8q _9f9ziet 1b94vk74 _m49zkct 1kz6s73a 1eu9dtog _q58s1rz 1dy9sjiq __u89jo3 _aj5nkwg _ld89jo3 13h9z6wx _qa9z2ii _l119xgq _bs5arju 1hj4nwk9 1qt4nwk9 1ge6wau6 14j9zlcw 11p1edc_ _ms1zcxe _439shk6 _jt9y70f _754zsow 1la40eju _oq5p___ _x279qkz 1fa5r3rv _yd2d9ip _424tcku _8y1di2_ _zi2uabw _yy7rn9h 12yz980_ __39ljp6 1b59zg0x _n39zfzp 1fy9zest _b33k___ _hp9wq92 1il50hz4 _io472ub _lj9z3eo 19z9ykg0 _8t8iu3a 12b9bl4a 1ak5yw0o _896v4ku _tb8k8lv _s59zi6t _c09ze0p 1lg80oqn 1id9z8wb _238nba5 1kq6wgdi _154zssg _tn3zk49 _da9y6tc 1sg7cv4f _r12jvtt 1gq5fmkz 1cs9rvci _lp9jn1c _xw1tdnb 13f9zje6 16f6973h _vo7ir40 _bt5arjf _rc45e4t _hr4e100 10v4e100 _hc9zke2 _w91egv_ _sj2r1kk 13c87yx8 _vqpds__ _ni8ggk8 _tj9yqfb 1ia2j4r4 _7x9b10u 1fc9ld4j 1eq9zldr _5j9lhpx _ez9zl6o _md61fzm'.split(' ').reduce((acc, next)=>{
    const key = colorToInt(next.substring(0, 3));
    const hex = colorToInt(next.substring(3)).toString(16);
    // NOTE: padStart could be used here but it breaks Node 6 compat
    // https://github.com/ricokahler/color2k/issues/351
    let prefix = '';
    for(let i = 0; i < 6 - hex.length; i++){
        prefix += '0';
    }
    acc[key] = `${prefix}${hex}`;
    return acc;
}, {});
/**
 * Checks if a string is a CSS named color and returns its equivalent hex value, otherwise returns the original color.
 */ function nameToHex(color) {
    const normalizedColorName = color.toLowerCase().trim();
    const result = compressedColorMap[hash(normalizedColorName)];
    if (!result) throw new ColorError$1(color);
    return `#${result}`;
}
const r = (str, amount)=>Array.from(Array(amount)).map(()=>str).join('');
const reducedHexRegex = new RegExp(`^#${r('([a-f0-9])', 3)}([a-f0-9])?$`, 'i');
const hexRegex = new RegExp(`^#${r('([a-f0-9]{2})', 3)}([a-f0-9]{2})?$`, 'i');
const rgbaRegex = new RegExp(`^rgba?\\(\\s*(\\d+)\\s*${r(',\\s*(\\d+)\\s*', 2)}(?:,\\s*([\\d.]+))?\\s*\\)$`, 'i');
const hslaRegex = /^hsla?\(\s*([\d.]+)\s*,\s*([\d.]+)%\s*,\s*([\d.]+)%(?:\s*,\s*([\d.]+))?\s*\)$/i;
const namedColorRegex = /^[a-z]+$/i;
const roundColor = (color)=>{
    return Math.round(color * 255);
};
const hslToRgb = (hue, saturation, lightness)=>{
    let l = lightness / 100;
    if (saturation === 0) {
        // achromatic
        return [
            l,
            l,
            l
        ].map(roundColor);
    }
    // formulae from https://en.wikipedia.org/wiki/HSL_and_HSV
    const huePrime = (hue % 360 + 360) % 360 / 60;
    const chroma = (1 - Math.abs(2 * l - 1)) * (saturation / 100);
    const secondComponent = chroma * (1 - Math.abs(huePrime % 2 - 1));
    let red = 0;
    let green = 0;
    let blue = 0;
    if (huePrime >= 0 && huePrime < 1) {
        red = chroma;
        green = secondComponent;
    } else if (huePrime >= 1 && huePrime < 2) {
        red = secondComponent;
        green = chroma;
    } else if (huePrime >= 2 && huePrime < 3) {
        green = chroma;
        blue = secondComponent;
    } else if (huePrime >= 3 && huePrime < 4) {
        green = secondComponent;
        blue = chroma;
    } else if (huePrime >= 4 && huePrime < 5) {
        red = secondComponent;
        blue = chroma;
    } else if (huePrime >= 5 && huePrime < 6) {
        red = chroma;
        blue = secondComponent;
    }
    const lightnessModification = l - chroma / 2;
    const finalRed = red + lightnessModification;
    const finalGreen = green + lightnessModification;
    const finalBlue = blue + lightnessModification;
    return [
        finalRed,
        finalGreen,
        finalBlue
    ].map(roundColor);
};
// taken from:
// https://github.com/styled-components/polished/blob/a23a6a2bb26802b3d922d9c3b67bac3f3a54a310/src/internalHelpers/_rgbToHsl.js
/**
 * Parses a color in hue, saturation, lightness, and the alpha channel.
 *
 * Hue is a number between 0 and 360, saturation, lightness, and alpha are
 * decimal percentages between 0 and 1
 */ function parseToHsla(color) {
    const [red, green, blue, alpha] = parseToRgba(color).map((value, index)=>// 3rd index is alpha channel which is already normalized
        index === 3 ? value : value / 255);
    const max = Math.max(red, green, blue);
    const min = Math.min(red, green, blue);
    const lightness = (max + min) / 2;
    // achromatic
    if (max === min) return [
        0,
        0,
        lightness,
        alpha
    ];
    const delta = max - min;
    const saturation = lightness > 0.5 ? delta / (2 - max - min) : delta / (max + min);
    const hue = 60 * (red === max ? (green - blue) / delta + (green < blue ? 6 : 0) : green === max ? (blue - red) / delta + 2 : (red - green) / delta + 4);
    return [
        hue,
        saturation,
        lightness,
        alpha
    ];
}
/**
 * Takes in hsla parts and constructs an hsla string
 *
 * @param hue The color circle (from 0 to 360) - 0 (or 360) is red, 120 is green, 240 is blue
 * @param saturation Percentage of saturation, given as a decimal between 0 and 1
 * @param lightness Percentage of lightness, given as a decimal between 0 and 1
 * @param alpha Percentage of opacity, given as a decimal between 0 and 1
 */ function hsla(hue, saturation, lightness, alpha) {
    return `hsla(${(hue % 360).toFixed()}, ${guard(0, 100, saturation * 100).toFixed()}%, ${guard(0, 100, lightness * 100).toFixed()}%, ${parseFloat(guard(0, 1, alpha).toFixed(3))})`;
}
/**
 * Adjusts the current hue of the color by the given degrees. Wraps around when
 * over 360.
 *
 * @param color input color
 * @param degrees degrees to adjust the input color, accepts degree integers
 * (0 - 360) and wraps around on overflow
 */ function adjustHue(color, degrees) {
    const [h, s, l, a] = parseToHsla(color);
    return hsla(h + degrees, s, l, a);
}
/**
 * Darkens using lightness. This is equivalent to subtracting the lightness
 * from the L in HSL.
 *
 * @param amount The amount to darken, given as a decimal between 0 and 1
 */ function darken(color, amount) {
    const [hue, saturation, lightness, alpha] = parseToHsla(color);
    return hsla(hue, saturation, lightness - amount, alpha);
}
/**
 * Desaturates the input color by the given amount via subtracting from the `s`
 * in `hsla`.
 *
 * @param amount The amount to desaturate, given as a decimal between 0 and 1
 */ function desaturate(color, amount) {
    const [h, s, l, a] = parseToHsla(color);
    return hsla(h, s - amount, l, a);
}
// taken from:
// https://github.com/styled-components/polished/blob/0764c982551b487469043acb56281b0358b3107b/src/color/getLuminance.js
/**
 * Returns a number (float) representing the luminance of a color.
 */ function getLuminance(color) {
    if (color === 'transparent') return 0;
    function f(x) {
        const channel = x / 255;
        return channel <= 0.04045 ? channel / 12.92 : Math.pow((channel + 0.055) / 1.055, 2.4);
    }
    const [r, g, b] = parseToRgba(color);
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
}
// taken from:
// https://github.com/styled-components/polished/blob/0764c982551b487469043acb56281b0358b3107b/src/color/getContrast.js
/**
 * Returns the contrast ratio between two colors based on
 * [W3's recommended equation for calculating contrast](http://www.w3.org/TR/WCAG20/#contrast-ratiodef).
 */ function getContrast(color1, color2) {
    const luminance1 = getLuminance(color1);
    const luminance2 = getLuminance(color2);
    return luminance1 > luminance2 ? (luminance1 + 0.05) / (luminance2 + 0.05) : (luminance2 + 0.05) / (luminance1 + 0.05);
}
/**
 * Takes in rgba parts and returns an rgba string
 *
 * @param red The amount of red in the red channel, given in a number between 0 and 255 inclusive
 * @param green The amount of green in the red channel, given in a number between 0 and 255 inclusive
 * @param blue The amount of blue in the red channel, given in a number between 0 and 255 inclusive
 * @param alpha Percentage of opacity, given as a decimal between 0 and 1
 */ function rgba(red, green, blue, alpha) {
    return `rgba(${guard(0, 255, red).toFixed()}, ${guard(0, 255, green).toFixed()}, ${guard(0, 255, blue).toFixed()}, ${parseFloat(guard(0, 1, alpha).toFixed(3))})`;
}
/**
 * Mixes two colors together. Taken from sass's implementation.
 */ function mix(color1, color2, weight) {
    const normalize = (n, index)=>// 3rd index is alpha channel which is already normalized
        index === 3 ? n : n / 255;
    const [r1, g1, b1, a1] = parseToRgba(color1).map(normalize);
    const [r2, g2, b2, a2] = parseToRgba(color2).map(normalize);
    // The formula is copied from the original Sass implementation:
    // http://sass-lang.com/documentation/Sass/Script/Functions.html#mix-instance_method
    const alphaDelta = a2 - a1;
    const normalizedWeight = weight * 2 - 1;
    const combinedWeight = normalizedWeight * alphaDelta === -1 ? normalizedWeight : normalizedWeight + alphaDelta / (1 + normalizedWeight * alphaDelta);
    const weight2 = (combinedWeight + 1) / 2;
    const weight1 = 1 - weight2;
    const r = (r1 * weight1 + r2 * weight2) * 255;
    const g = (g1 * weight1 + g2 * weight2) * 255;
    const b = (b1 * weight1 + b2 * weight2) * 255;
    const a = a2 * weight + a1 * (1 - weight);
    return rgba(r, g, b, a);
}
/**
 * Given a series colors, this function will return a `scale(x)` function that
 * accepts a percentage as a decimal between 0 and 1 and returns the color at
 * that percentage in the scale.
 *
 * ```js
 * const scale = getScale('red', 'yellow', 'green');
 * console.log(scale(0)); // rgba(255, 0, 0, 1)
 * console.log(scale(0.5)); // rgba(255, 255, 0, 1)
 * console.log(scale(1)); // rgba(0, 128, 0, 1)
 * ```
 *
 * If you'd like to limit the domain and range like chroma-js, we recommend
 * wrapping scale again.
 *
 * ```js
 * const _scale = getScale('red', 'yellow', 'green');
 * const scale = x => _scale(x / 100);
 *
 * console.log(scale(0)); // rgba(255, 0, 0, 1)
 * console.log(scale(50)); // rgba(255, 255, 0, 1)
 * console.log(scale(100)); // rgba(0, 128, 0, 1)
 * ```
 */ function getScale(...colors) {
    return (n)=>{
        const lastIndex = colors.length - 1;
        const lowIndex = guard(0, lastIndex, Math.floor(n * lastIndex));
        const highIndex = guard(0, lastIndex, Math.ceil(n * lastIndex));
        const color1 = colors[lowIndex];
        const color2 = colors[highIndex];
        const unit = 1 / lastIndex;
        const weight = (n - unit * lowIndex) / unit;
        return mix(color1, color2, weight);
    };
}
const guidelines = {
    decorative: 1.5,
    readable: 3,
    aa: 4.5,
    aaa: 7
};
/**
 * Returns whether or not a color has bad contrast against a background
 * according to a given standard.
 */ function hasBadContrast(color, standard = 'aa', background = '#fff') {
    return getContrast(color, background) < guidelines[standard];
}
/**
 * Lightens a color by a given amount. This is equivalent to
 * `darken(color, -amount)`
 *
 * @param amount The amount to darken, given as a decimal between 0 and 1
 */ function lighten(color, amount) {
    return darken(color, -amount);
}
/**
 * Takes in a color and makes it more transparent by convert to `rgba` and
 * decreasing the amount in the alpha channel.
 *
 * @param amount The amount to increase the transparency by, given as a decimal between 0 and 1
 */ function transparentize(color, amount) {
    const [r, g, b, a] = parseToRgba(color);
    return rgba(r, g, b, a - amount);
}
/**
 * Takes a color and un-transparentizes it. Equivalent to
 * `transparentize(color, -amount)`
 *
 * @param amount The amount to increase the opacity by, given as a decimal between 0 and 1
 */ function opacify(color, amount) {
    return transparentize(color, -amount);
}
/**
 * An alternative function to `readableColor`. Returns whether or not the 
 * readable color (i.e. the color to be place on top the input color) should be
 * black.
 */ function readableColorIsBlack(color) {
    return getLuminance(color) > 0.179;
}
/**
 * Returns black or white for best contrast depending on the luminosity of the
 * given color.
 */ function readableColor(color) {
    return readableColorIsBlack(color) ? '#000' : '#fff';
}
/**
 * Saturates a color by converting it to `hsl` and increasing the saturation
 * amount. Equivalent to `desaturate(color, -amount)`
 * 
 * @param color Input color
 * @param amount The amount to darken, given as a decimal between 0 and 1
 */ function saturate(color, amount) {
    return desaturate(color, -amount);
}
/**
 * Takes in any color and returns it as a hex code.
 */ function toHex(color) {
    const [r, g, b, a] = parseToRgba(color);
    let hex = (x)=>{
        const h = guard(0, 255, x).toString(16);
        // NOTE: padStart could be used here but it breaks Node 6 compat
        // https://github.com/ricokahler/color2k/issues/351
        return h.length === 1 ? `0${h}` : h;
    };
    return `#${hex(r)}${hex(g)}${hex(b)}${a < 1 ? hex(Math.round(a * 255)) : ''}`;
}
/**
 * Takes in any color and returns it as an rgba string.
 */ function toRgba(color) {
    return rgba(...parseToRgba(color));
}
/**
 * Takes in any color and returns it as an hsla string.
 */ function toHsla(color) {
    return hsla(...parseToHsla(color));
}
;
 //# sourceMappingURL=index.exports.import.es.mjs.map
}),
"[project]/next-admin-dashboard/node_modules/color-name/index.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = {
    "aliceblue": [
        240,
        248,
        255
    ],
    "antiquewhite": [
        250,
        235,
        215
    ],
    "aqua": [
        0,
        255,
        255
    ],
    "aquamarine": [
        127,
        255,
        212
    ],
    "azure": [
        240,
        255,
        255
    ],
    "beige": [
        245,
        245,
        220
    ],
    "bisque": [
        255,
        228,
        196
    ],
    "black": [
        0,
        0,
        0
    ],
    "blanchedalmond": [
        255,
        235,
        205
    ],
    "blue": [
        0,
        0,
        255
    ],
    "blueviolet": [
        138,
        43,
        226
    ],
    "brown": [
        165,
        42,
        42
    ],
    "burlywood": [
        222,
        184,
        135
    ],
    "cadetblue": [
        95,
        158,
        160
    ],
    "chartreuse": [
        127,
        255,
        0
    ],
    "chocolate": [
        210,
        105,
        30
    ],
    "coral": [
        255,
        127,
        80
    ],
    "cornflowerblue": [
        100,
        149,
        237
    ],
    "cornsilk": [
        255,
        248,
        220
    ],
    "crimson": [
        220,
        20,
        60
    ],
    "cyan": [
        0,
        255,
        255
    ],
    "darkblue": [
        0,
        0,
        139
    ],
    "darkcyan": [
        0,
        139,
        139
    ],
    "darkgoldenrod": [
        184,
        134,
        11
    ],
    "darkgray": [
        169,
        169,
        169
    ],
    "darkgreen": [
        0,
        100,
        0
    ],
    "darkgrey": [
        169,
        169,
        169
    ],
    "darkkhaki": [
        189,
        183,
        107
    ],
    "darkmagenta": [
        139,
        0,
        139
    ],
    "darkolivegreen": [
        85,
        107,
        47
    ],
    "darkorange": [
        255,
        140,
        0
    ],
    "darkorchid": [
        153,
        50,
        204
    ],
    "darkred": [
        139,
        0,
        0
    ],
    "darksalmon": [
        233,
        150,
        122
    ],
    "darkseagreen": [
        143,
        188,
        143
    ],
    "darkslateblue": [
        72,
        61,
        139
    ],
    "darkslategray": [
        47,
        79,
        79
    ],
    "darkslategrey": [
        47,
        79,
        79
    ],
    "darkturquoise": [
        0,
        206,
        209
    ],
    "darkviolet": [
        148,
        0,
        211
    ],
    "deeppink": [
        255,
        20,
        147
    ],
    "deepskyblue": [
        0,
        191,
        255
    ],
    "dimgray": [
        105,
        105,
        105
    ],
    "dimgrey": [
        105,
        105,
        105
    ],
    "dodgerblue": [
        30,
        144,
        255
    ],
    "firebrick": [
        178,
        34,
        34
    ],
    "floralwhite": [
        255,
        250,
        240
    ],
    "forestgreen": [
        34,
        139,
        34
    ],
    "fuchsia": [
        255,
        0,
        255
    ],
    "gainsboro": [
        220,
        220,
        220
    ],
    "ghostwhite": [
        248,
        248,
        255
    ],
    "gold": [
        255,
        215,
        0
    ],
    "goldenrod": [
        218,
        165,
        32
    ],
    "gray": [
        128,
        128,
        128
    ],
    "green": [
        0,
        128,
        0
    ],
    "greenyellow": [
        173,
        255,
        47
    ],
    "grey": [
        128,
        128,
        128
    ],
    "honeydew": [
        240,
        255,
        240
    ],
    "hotpink": [
        255,
        105,
        180
    ],
    "indianred": [
        205,
        92,
        92
    ],
    "indigo": [
        75,
        0,
        130
    ],
    "ivory": [
        255,
        255,
        240
    ],
    "khaki": [
        240,
        230,
        140
    ],
    "lavender": [
        230,
        230,
        250
    ],
    "lavenderblush": [
        255,
        240,
        245
    ],
    "lawngreen": [
        124,
        252,
        0
    ],
    "lemonchiffon": [
        255,
        250,
        205
    ],
    "lightblue": [
        173,
        216,
        230
    ],
    "lightcoral": [
        240,
        128,
        128
    ],
    "lightcyan": [
        224,
        255,
        255
    ],
    "lightgoldenrodyellow": [
        250,
        250,
        210
    ],
    "lightgray": [
        211,
        211,
        211
    ],
    "lightgreen": [
        144,
        238,
        144
    ],
    "lightgrey": [
        211,
        211,
        211
    ],
    "lightpink": [
        255,
        182,
        193
    ],
    "lightsalmon": [
        255,
        160,
        122
    ],
    "lightseagreen": [
        32,
        178,
        170
    ],
    "lightskyblue": [
        135,
        206,
        250
    ],
    "lightslategray": [
        119,
        136,
        153
    ],
    "lightslategrey": [
        119,
        136,
        153
    ],
    "lightsteelblue": [
        176,
        196,
        222
    ],
    "lightyellow": [
        255,
        255,
        224
    ],
    "lime": [
        0,
        255,
        0
    ],
    "limegreen": [
        50,
        205,
        50
    ],
    "linen": [
        250,
        240,
        230
    ],
    "magenta": [
        255,
        0,
        255
    ],
    "maroon": [
        128,
        0,
        0
    ],
    "mediumaquamarine": [
        102,
        205,
        170
    ],
    "mediumblue": [
        0,
        0,
        205
    ],
    "mediumorchid": [
        186,
        85,
        211
    ],
    "mediumpurple": [
        147,
        112,
        219
    ],
    "mediumseagreen": [
        60,
        179,
        113
    ],
    "mediumslateblue": [
        123,
        104,
        238
    ],
    "mediumspringgreen": [
        0,
        250,
        154
    ],
    "mediumturquoise": [
        72,
        209,
        204
    ],
    "mediumvioletred": [
        199,
        21,
        133
    ],
    "midnightblue": [
        25,
        25,
        112
    ],
    "mintcream": [
        245,
        255,
        250
    ],
    "mistyrose": [
        255,
        228,
        225
    ],
    "moccasin": [
        255,
        228,
        181
    ],
    "navajowhite": [
        255,
        222,
        173
    ],
    "navy": [
        0,
        0,
        128
    ],
    "oldlace": [
        253,
        245,
        230
    ],
    "olive": [
        128,
        128,
        0
    ],
    "olivedrab": [
        107,
        142,
        35
    ],
    "orange": [
        255,
        165,
        0
    ],
    "orangered": [
        255,
        69,
        0
    ],
    "orchid": [
        218,
        112,
        214
    ],
    "palegoldenrod": [
        238,
        232,
        170
    ],
    "palegreen": [
        152,
        251,
        152
    ],
    "paleturquoise": [
        175,
        238,
        238
    ],
    "palevioletred": [
        219,
        112,
        147
    ],
    "papayawhip": [
        255,
        239,
        213
    ],
    "peachpuff": [
        255,
        218,
        185
    ],
    "peru": [
        205,
        133,
        63
    ],
    "pink": [
        255,
        192,
        203
    ],
    "plum": [
        221,
        160,
        221
    ],
    "powderblue": [
        176,
        224,
        230
    ],
    "purple": [
        128,
        0,
        128
    ],
    "rebeccapurple": [
        102,
        51,
        153
    ],
    "red": [
        255,
        0,
        0
    ],
    "rosybrown": [
        188,
        143,
        143
    ],
    "royalblue": [
        65,
        105,
        225
    ],
    "saddlebrown": [
        139,
        69,
        19
    ],
    "salmon": [
        250,
        128,
        114
    ],
    "sandybrown": [
        244,
        164,
        96
    ],
    "seagreen": [
        46,
        139,
        87
    ],
    "seashell": [
        255,
        245,
        238
    ],
    "sienna": [
        160,
        82,
        45
    ],
    "silver": [
        192,
        192,
        192
    ],
    "skyblue": [
        135,
        206,
        235
    ],
    "slateblue": [
        106,
        90,
        205
    ],
    "slategray": [
        112,
        128,
        144
    ],
    "slategrey": [
        112,
        128,
        144
    ],
    "snow": [
        255,
        250,
        250
    ],
    "springgreen": [
        0,
        255,
        127
    ],
    "steelblue": [
        70,
        130,
        180
    ],
    "tan": [
        210,
        180,
        140
    ],
    "teal": [
        0,
        128,
        128
    ],
    "thistle": [
        216,
        191,
        216
    ],
    "tomato": [
        255,
        99,
        71
    ],
    "turquoise": [
        64,
        224,
        208
    ],
    "violet": [
        238,
        130,
        238
    ],
    "wheat": [
        245,
        222,
        179
    ],
    "white": [
        255,
        255,
        255
    ],
    "whitesmoke": [
        245,
        245,
        245
    ],
    "yellow": [
        255,
        255,
        0
    ],
    "yellowgreen": [
        154,
        205,
        50
    ]
};
}),
"[project]/next-admin-dashboard/node_modules/is-arrayish/index.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = function isArrayish(obj) {
    if (!obj || typeof obj === 'string') {
        return false;
    }
    return obj instanceof Array || Array.isArray(obj) || obj.length >= 0 && (obj.splice instanceof Function || Object.getOwnPropertyDescriptor(obj, obj.length - 1) && obj.constructor.name !== 'String');
};
}),
"[project]/next-admin-dashboard/node_modules/simple-swizzle/index.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var isArrayish = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/is-arrayish/index.js [app-rsc] (ecmascript)");
var concat = Array.prototype.concat;
var slice = Array.prototype.slice;
var swizzle = module.exports = function swizzle(args) {
    var results = [];
    for(var i = 0, len = args.length; i < len; i++){
        var arg = args[i];
        if (isArrayish(arg)) {
            // http://jsperf.com/javascript-array-concat-vs-push/98
            results = concat.call(results, slice.call(arg));
        } else {
            results.push(arg);
        }
    }
    return results;
};
swizzle.wrap = function(fn) {
    return function() {
        return fn(swizzle(arguments));
    };
};
}),
"[project]/next-admin-dashboard/node_modules/color-string/index.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

/* MIT license */ var colorNames = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/color-name/index.js [app-rsc] (ecmascript)");
var swizzle = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/simple-swizzle/index.js [app-rsc] (ecmascript)");
var hasOwnProperty = Object.hasOwnProperty;
var reverseNames = Object.create(null);
// create a list of reverse color names
for(var name in colorNames){
    if (hasOwnProperty.call(colorNames, name)) {
        reverseNames[colorNames[name]] = name;
    }
}
var cs = module.exports = {
    to: {},
    get: {}
};
cs.get = function(string) {
    var prefix = string.substring(0, 3).toLowerCase();
    var val;
    var model;
    switch(prefix){
        case 'hsl':
            val = cs.get.hsl(string);
            model = 'hsl';
            break;
        case 'hwb':
            val = cs.get.hwb(string);
            model = 'hwb';
            break;
        default:
            val = cs.get.rgb(string);
            model = 'rgb';
            break;
    }
    if (!val) {
        return null;
    }
    return {
        model: model,
        value: val
    };
};
cs.get.rgb = function(string) {
    if (!string) {
        return null;
    }
    var abbr = /^#([a-f0-9]{3,4})$/i;
    var hex = /^#([a-f0-9]{6})([a-f0-9]{2})?$/i;
    var rgba = /^rgba?\(\s*([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)\s*(?:[,|\/]\s*([+-]?[\d\.]+)(%?)\s*)?\)$/;
    var per = /^rgba?\(\s*([+-]?[\d\.]+)\%\s*,?\s*([+-]?[\d\.]+)\%\s*,?\s*([+-]?[\d\.]+)\%\s*(?:[,|\/]\s*([+-]?[\d\.]+)(%?)\s*)?\)$/;
    var keyword = /^(\w+)$/;
    var rgb = [
        0,
        0,
        0,
        1
    ];
    var match;
    var i;
    var hexAlpha;
    if (match = string.match(hex)) {
        hexAlpha = match[2];
        match = match[1];
        for(i = 0; i < 3; i++){
            // https://jsperf.com/slice-vs-substr-vs-substring-methods-long-string/19
            var i2 = i * 2;
            rgb[i] = parseInt(match.slice(i2, i2 + 2), 16);
        }
        if (hexAlpha) {
            rgb[3] = parseInt(hexAlpha, 16) / 255;
        }
    } else if (match = string.match(abbr)) {
        match = match[1];
        hexAlpha = match[3];
        for(i = 0; i < 3; i++){
            rgb[i] = parseInt(match[i] + match[i], 16);
        }
        if (hexAlpha) {
            rgb[3] = parseInt(hexAlpha + hexAlpha, 16) / 255;
        }
    } else if (match = string.match(rgba)) {
        for(i = 0; i < 3; i++){
            rgb[i] = parseInt(match[i + 1], 0);
        }
        if (match[4]) {
            if (match[5]) {
                rgb[3] = parseFloat(match[4]) * 0.01;
            } else {
                rgb[3] = parseFloat(match[4]);
            }
        }
    } else if (match = string.match(per)) {
        for(i = 0; i < 3; i++){
            rgb[i] = Math.round(parseFloat(match[i + 1]) * 2.55);
        }
        if (match[4]) {
            if (match[5]) {
                rgb[3] = parseFloat(match[4]) * 0.01;
            } else {
                rgb[3] = parseFloat(match[4]);
            }
        }
    } else if (match = string.match(keyword)) {
        if (match[1] === 'transparent') {
            return [
                0,
                0,
                0,
                0
            ];
        }
        if (!hasOwnProperty.call(colorNames, match[1])) {
            return null;
        }
        rgb = colorNames[match[1]];
        rgb[3] = 1;
        return rgb;
    } else {
        return null;
    }
    for(i = 0; i < 3; i++){
        rgb[i] = clamp(rgb[i], 0, 255);
    }
    rgb[3] = clamp(rgb[3], 0, 1);
    return rgb;
};
cs.get.hsl = function(string) {
    if (!string) {
        return null;
    }
    var hsl = /^hsla?\(\s*([+-]?(?:\d{0,3}\.)?\d+)(?:deg)?\s*,?\s*([+-]?[\d\.]+)%\s*,?\s*([+-]?[\d\.]+)%\s*(?:[,|\/]\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:[eE][+-]?\d+)?)\s*)?\)$/;
    var match = string.match(hsl);
    if (match) {
        var alpha = parseFloat(match[4]);
        var h = (parseFloat(match[1]) % 360 + 360) % 360;
        var s = clamp(parseFloat(match[2]), 0, 100);
        var l = clamp(parseFloat(match[3]), 0, 100);
        var a = clamp(isNaN(alpha) ? 1 : alpha, 0, 1);
        return [
            h,
            s,
            l,
            a
        ];
    }
    return null;
};
cs.get.hwb = function(string) {
    if (!string) {
        return null;
    }
    var hwb = /^hwb\(\s*([+-]?\d{0,3}(?:\.\d+)?)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:[eE][+-]?\d+)?)\s*)?\)$/;
    var match = string.match(hwb);
    if (match) {
        var alpha = parseFloat(match[4]);
        var h = (parseFloat(match[1]) % 360 + 360) % 360;
        var w = clamp(parseFloat(match[2]), 0, 100);
        var b = clamp(parseFloat(match[3]), 0, 100);
        var a = clamp(isNaN(alpha) ? 1 : alpha, 0, 1);
        return [
            h,
            w,
            b,
            a
        ];
    }
    return null;
};
cs.to.hex = function() {
    var rgba = swizzle(arguments);
    return '#' + hexDouble(rgba[0]) + hexDouble(rgba[1]) + hexDouble(rgba[2]) + (rgba[3] < 1 ? hexDouble(Math.round(rgba[3] * 255)) : '');
};
cs.to.rgb = function() {
    var rgba = swizzle(arguments);
    return rgba.length < 4 || rgba[3] === 1 ? 'rgb(' + Math.round(rgba[0]) + ', ' + Math.round(rgba[1]) + ', ' + Math.round(rgba[2]) + ')' : 'rgba(' + Math.round(rgba[0]) + ', ' + Math.round(rgba[1]) + ', ' + Math.round(rgba[2]) + ', ' + rgba[3] + ')';
};
cs.to.rgb.percent = function() {
    var rgba = swizzle(arguments);
    var r = Math.round(rgba[0] / 255 * 100);
    var g = Math.round(rgba[1] / 255 * 100);
    var b = Math.round(rgba[2] / 255 * 100);
    return rgba.length < 4 || rgba[3] === 1 ? 'rgb(' + r + '%, ' + g + '%, ' + b + '%)' : 'rgba(' + r + '%, ' + g + '%, ' + b + '%, ' + rgba[3] + ')';
};
cs.to.hsl = function() {
    var hsla = swizzle(arguments);
    return hsla.length < 4 || hsla[3] === 1 ? 'hsl(' + hsla[0] + ', ' + hsla[1] + '%, ' + hsla[2] + '%)' : 'hsla(' + hsla[0] + ', ' + hsla[1] + '%, ' + hsla[2] + '%, ' + hsla[3] + ')';
};
// hwb is a bit different than rgb(a) & hsl(a) since there is no alpha specific syntax
// (hwb have alpha optional & 1 is default value)
cs.to.hwb = function() {
    var hwba = swizzle(arguments);
    var a = '';
    if (hwba.length >= 4 && hwba[3] !== 1) {
        a = ', ' + hwba[3];
    }
    return 'hwb(' + hwba[0] + ', ' + hwba[1] + '%, ' + hwba[2] + '%' + a + ')';
};
cs.to.keyword = function(rgb) {
    return reverseNames[rgb.slice(0, 3)];
};
// helpers
function clamp(num, min, max) {
    return Math.min(Math.max(min, num), max);
}
function hexDouble(num) {
    var str = Math.round(num).toString(16).toUpperCase();
    return str.length < 2 ? '0' + str : str;
}
}),
"[project]/next-admin-dashboard/node_modules/color-convert/conversions.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

/* MIT license */ /* eslint-disable no-mixed-operators */ const cssKeywords = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/color-name/index.js [app-rsc] (ecmascript)");
// NOTE: conversions should only return primitive values (i.e. arrays, or
//       values that give correct `typeof` results).
//       do not use box values types (i.e. Number(), String(), etc.)
const reverseKeywords = {};
for (const key of Object.keys(cssKeywords)){
    reverseKeywords[cssKeywords[key]] = key;
}
const convert = {
    rgb: {
        channels: 3,
        labels: 'rgb'
    },
    hsl: {
        channels: 3,
        labels: 'hsl'
    },
    hsv: {
        channels: 3,
        labels: 'hsv'
    },
    hwb: {
        channels: 3,
        labels: 'hwb'
    },
    cmyk: {
        channels: 4,
        labels: 'cmyk'
    },
    xyz: {
        channels: 3,
        labels: 'xyz'
    },
    lab: {
        channels: 3,
        labels: 'lab'
    },
    lch: {
        channels: 3,
        labels: 'lch'
    },
    hex: {
        channels: 1,
        labels: [
            'hex'
        ]
    },
    keyword: {
        channels: 1,
        labels: [
            'keyword'
        ]
    },
    ansi16: {
        channels: 1,
        labels: [
            'ansi16'
        ]
    },
    ansi256: {
        channels: 1,
        labels: [
            'ansi256'
        ]
    },
    hcg: {
        channels: 3,
        labels: [
            'h',
            'c',
            'g'
        ]
    },
    apple: {
        channels: 3,
        labels: [
            'r16',
            'g16',
            'b16'
        ]
    },
    gray: {
        channels: 1,
        labels: [
            'gray'
        ]
    }
};
module.exports = convert;
// Hide .channels and .labels properties
for (const model of Object.keys(convert)){
    if (!('channels' in convert[model])) {
        throw new Error('missing channels property: ' + model);
    }
    if (!('labels' in convert[model])) {
        throw new Error('missing channel labels property: ' + model);
    }
    if (convert[model].labels.length !== convert[model].channels) {
        throw new Error('channel and label counts mismatch: ' + model);
    }
    const { channels, labels } = convert[model];
    delete convert[model].channels;
    delete convert[model].labels;
    Object.defineProperty(convert[model], 'channels', {
        value: channels
    });
    Object.defineProperty(convert[model], 'labels', {
        value: labels
    });
}
convert.rgb.hsl = function(rgb) {
    const r = rgb[0] / 255;
    const g = rgb[1] / 255;
    const b = rgb[2] / 255;
    const min = Math.min(r, g, b);
    const max = Math.max(r, g, b);
    const delta = max - min;
    let h;
    let s;
    if (max === min) {
        h = 0;
    } else if (r === max) {
        h = (g - b) / delta;
    } else if (g === max) {
        h = 2 + (b - r) / delta;
    } else if (b === max) {
        h = 4 + (r - g) / delta;
    }
    h = Math.min(h * 60, 360);
    if (h < 0) {
        h += 360;
    }
    const l = (min + max) / 2;
    if (max === min) {
        s = 0;
    } else if (l <= 0.5) {
        s = delta / (max + min);
    } else {
        s = delta / (2 - max - min);
    }
    return [
        h,
        s * 100,
        l * 100
    ];
};
convert.rgb.hsv = function(rgb) {
    let rdif;
    let gdif;
    let bdif;
    let h;
    let s;
    const r = rgb[0] / 255;
    const g = rgb[1] / 255;
    const b = rgb[2] / 255;
    const v = Math.max(r, g, b);
    const diff = v - Math.min(r, g, b);
    const diffc = function(c) {
        return (v - c) / 6 / diff + 1 / 2;
    };
    if (diff === 0) {
        h = 0;
        s = 0;
    } else {
        s = diff / v;
        rdif = diffc(r);
        gdif = diffc(g);
        bdif = diffc(b);
        if (r === v) {
            h = bdif - gdif;
        } else if (g === v) {
            h = 1 / 3 + rdif - bdif;
        } else if (b === v) {
            h = 2 / 3 + gdif - rdif;
        }
        if (h < 0) {
            h += 1;
        } else if (h > 1) {
            h -= 1;
        }
    }
    return [
        h * 360,
        s * 100,
        v * 100
    ];
};
convert.rgb.hwb = function(rgb) {
    const r = rgb[0];
    const g = rgb[1];
    let b = rgb[2];
    const h = convert.rgb.hsl(rgb)[0];
    const w = 1 / 255 * Math.min(r, Math.min(g, b));
    b = 1 - 1 / 255 * Math.max(r, Math.max(g, b));
    return [
        h,
        w * 100,
        b * 100
    ];
};
convert.rgb.cmyk = function(rgb) {
    const r = rgb[0] / 255;
    const g = rgb[1] / 255;
    const b = rgb[2] / 255;
    const k = Math.min(1 - r, 1 - g, 1 - b);
    const c = (1 - r - k) / (1 - k) || 0;
    const m = (1 - g - k) / (1 - k) || 0;
    const y = (1 - b - k) / (1 - k) || 0;
    return [
        c * 100,
        m * 100,
        y * 100,
        k * 100
    ];
};
function comparativeDistance(x, y) {
    /*
		See https://en.m.wikipedia.org/wiki/Euclidean_distance#Squared_Euclidean_distance
	*/ return (x[0] - y[0]) ** 2 + (x[1] - y[1]) ** 2 + (x[2] - y[2]) ** 2;
}
convert.rgb.keyword = function(rgb) {
    const reversed = reverseKeywords[rgb];
    if (reversed) {
        return reversed;
    }
    let currentClosestDistance = Infinity;
    let currentClosestKeyword;
    for (const keyword of Object.keys(cssKeywords)){
        const value = cssKeywords[keyword];
        // Compute comparative distance
        const distance = comparativeDistance(rgb, value);
        // Check if its less, if so set as closest
        if (distance < currentClosestDistance) {
            currentClosestDistance = distance;
            currentClosestKeyword = keyword;
        }
    }
    return currentClosestKeyword;
};
convert.keyword.rgb = function(keyword) {
    return cssKeywords[keyword];
};
convert.rgb.xyz = function(rgb) {
    let r = rgb[0] / 255;
    let g = rgb[1] / 255;
    let b = rgb[2] / 255;
    // Assume sRGB
    r = r > 0.04045 ? ((r + 0.055) / 1.055) ** 2.4 : r / 12.92;
    g = g > 0.04045 ? ((g + 0.055) / 1.055) ** 2.4 : g / 12.92;
    b = b > 0.04045 ? ((b + 0.055) / 1.055) ** 2.4 : b / 12.92;
    const x = r * 0.4124 + g * 0.3576 + b * 0.1805;
    const y = r * 0.2126 + g * 0.7152 + b * 0.0722;
    const z = r * 0.0193 + g * 0.1192 + b * 0.9505;
    return [
        x * 100,
        y * 100,
        z * 100
    ];
};
convert.rgb.lab = function(rgb) {
    const xyz = convert.rgb.xyz(rgb);
    let x = xyz[0];
    let y = xyz[1];
    let z = xyz[2];
    x /= 95.047;
    y /= 100;
    z /= 108.883;
    x = x > 0.008856 ? x ** (1 / 3) : 7.787 * x + 16 / 116;
    y = y > 0.008856 ? y ** (1 / 3) : 7.787 * y + 16 / 116;
    z = z > 0.008856 ? z ** (1 / 3) : 7.787 * z + 16 / 116;
    const l = 116 * y - 16;
    const a = 500 * (x - y);
    const b = 200 * (y - z);
    return [
        l,
        a,
        b
    ];
};
convert.hsl.rgb = function(hsl) {
    const h = hsl[0] / 360;
    const s = hsl[1] / 100;
    const l = hsl[2] / 100;
    let t2;
    let t3;
    let val;
    if (s === 0) {
        val = l * 255;
        return [
            val,
            val,
            val
        ];
    }
    if (l < 0.5) {
        t2 = l * (1 + s);
    } else {
        t2 = l + s - l * s;
    }
    const t1 = 2 * l - t2;
    const rgb = [
        0,
        0,
        0
    ];
    for(let i = 0; i < 3; i++){
        t3 = h + 1 / 3 * -(i - 1);
        if (t3 < 0) {
            t3++;
        }
        if (t3 > 1) {
            t3--;
        }
        if (6 * t3 < 1) {
            val = t1 + (t2 - t1) * 6 * t3;
        } else if (2 * t3 < 1) {
            val = t2;
        } else if (3 * t3 < 2) {
            val = t1 + (t2 - t1) * (2 / 3 - t3) * 6;
        } else {
            val = t1;
        }
        rgb[i] = val * 255;
    }
    return rgb;
};
convert.hsl.hsv = function(hsl) {
    const h = hsl[0];
    let s = hsl[1] / 100;
    let l = hsl[2] / 100;
    let smin = s;
    const lmin = Math.max(l, 0.01);
    l *= 2;
    s *= l <= 1 ? l : 2 - l;
    smin *= lmin <= 1 ? lmin : 2 - lmin;
    const v = (l + s) / 2;
    const sv = l === 0 ? 2 * smin / (lmin + smin) : 2 * s / (l + s);
    return [
        h,
        sv * 100,
        v * 100
    ];
};
convert.hsv.rgb = function(hsv) {
    const h = hsv[0] / 60;
    const s = hsv[1] / 100;
    let v = hsv[2] / 100;
    const hi = Math.floor(h) % 6;
    const f = h - Math.floor(h);
    const p = 255 * v * (1 - s);
    const q = 255 * v * (1 - s * f);
    const t = 255 * v * (1 - s * (1 - f));
    v *= 255;
    switch(hi){
        case 0:
            return [
                v,
                t,
                p
            ];
        case 1:
            return [
                q,
                v,
                p
            ];
        case 2:
            return [
                p,
                v,
                t
            ];
        case 3:
            return [
                p,
                q,
                v
            ];
        case 4:
            return [
                t,
                p,
                v
            ];
        case 5:
            return [
                v,
                p,
                q
            ];
    }
};
convert.hsv.hsl = function(hsv) {
    const h = hsv[0];
    const s = hsv[1] / 100;
    const v = hsv[2] / 100;
    const vmin = Math.max(v, 0.01);
    let sl;
    let l;
    l = (2 - s) * v;
    const lmin = (2 - s) * vmin;
    sl = s * vmin;
    sl /= lmin <= 1 ? lmin : 2 - lmin;
    sl = sl || 0;
    l /= 2;
    return [
        h,
        sl * 100,
        l * 100
    ];
};
// http://dev.w3.org/csswg/css-color/#hwb-to-rgb
convert.hwb.rgb = function(hwb) {
    const h = hwb[0] / 360;
    let wh = hwb[1] / 100;
    let bl = hwb[2] / 100;
    const ratio = wh + bl;
    let f;
    // Wh + bl cant be > 1
    if (ratio > 1) {
        wh /= ratio;
        bl /= ratio;
    }
    const i = Math.floor(6 * h);
    const v = 1 - bl;
    f = 6 * h - i;
    if ((i & 0x01) !== 0) {
        f = 1 - f;
    }
    const n = wh + f * (v - wh); // Linear interpolation
    let r;
    let g;
    let b;
    /* eslint-disable max-statements-per-line,no-multi-spaces */ switch(i){
        default:
        case 6:
        case 0:
            r = v;
            g = n;
            b = wh;
            break;
        case 1:
            r = n;
            g = v;
            b = wh;
            break;
        case 2:
            r = wh;
            g = v;
            b = n;
            break;
        case 3:
            r = wh;
            g = n;
            b = v;
            break;
        case 4:
            r = n;
            g = wh;
            b = v;
            break;
        case 5:
            r = v;
            g = wh;
            b = n;
            break;
    }
    /* eslint-enable max-statements-per-line,no-multi-spaces */ return [
        r * 255,
        g * 255,
        b * 255
    ];
};
convert.cmyk.rgb = function(cmyk) {
    const c = cmyk[0] / 100;
    const m = cmyk[1] / 100;
    const y = cmyk[2] / 100;
    const k = cmyk[3] / 100;
    const r = 1 - Math.min(1, c * (1 - k) + k);
    const g = 1 - Math.min(1, m * (1 - k) + k);
    const b = 1 - Math.min(1, y * (1 - k) + k);
    return [
        r * 255,
        g * 255,
        b * 255
    ];
};
convert.xyz.rgb = function(xyz) {
    const x = xyz[0] / 100;
    const y = xyz[1] / 100;
    const z = xyz[2] / 100;
    let r;
    let g;
    let b;
    r = x * 3.2406 + y * -1.5372 + z * -0.4986;
    g = x * -0.9689 + y * 1.8758 + z * 0.0415;
    b = x * 0.0557 + y * -0.2040 + z * 1.0570;
    // Assume sRGB
    r = r > 0.0031308 ? 1.055 * r ** (1.0 / 2.4) - 0.055 : r * 12.92;
    g = g > 0.0031308 ? 1.055 * g ** (1.0 / 2.4) - 0.055 : g * 12.92;
    b = b > 0.0031308 ? 1.055 * b ** (1.0 / 2.4) - 0.055 : b * 12.92;
    r = Math.min(Math.max(0, r), 1);
    g = Math.min(Math.max(0, g), 1);
    b = Math.min(Math.max(0, b), 1);
    return [
        r * 255,
        g * 255,
        b * 255
    ];
};
convert.xyz.lab = function(xyz) {
    let x = xyz[0];
    let y = xyz[1];
    let z = xyz[2];
    x /= 95.047;
    y /= 100;
    z /= 108.883;
    x = x > 0.008856 ? x ** (1 / 3) : 7.787 * x + 16 / 116;
    y = y > 0.008856 ? y ** (1 / 3) : 7.787 * y + 16 / 116;
    z = z > 0.008856 ? z ** (1 / 3) : 7.787 * z + 16 / 116;
    const l = 116 * y - 16;
    const a = 500 * (x - y);
    const b = 200 * (y - z);
    return [
        l,
        a,
        b
    ];
};
convert.lab.xyz = function(lab) {
    const l = lab[0];
    const a = lab[1];
    const b = lab[2];
    let x;
    let y;
    let z;
    y = (l + 16) / 116;
    x = a / 500 + y;
    z = y - b / 200;
    const y2 = y ** 3;
    const x2 = x ** 3;
    const z2 = z ** 3;
    y = y2 > 0.008856 ? y2 : (y - 16 / 116) / 7.787;
    x = x2 > 0.008856 ? x2 : (x - 16 / 116) / 7.787;
    z = z2 > 0.008856 ? z2 : (z - 16 / 116) / 7.787;
    x *= 95.047;
    y *= 100;
    z *= 108.883;
    return [
        x,
        y,
        z
    ];
};
convert.lab.lch = function(lab) {
    const l = lab[0];
    const a = lab[1];
    const b = lab[2];
    let h;
    const hr = Math.atan2(b, a);
    h = hr * 360 / 2 / Math.PI;
    if (h < 0) {
        h += 360;
    }
    const c = Math.sqrt(a * a + b * b);
    return [
        l,
        c,
        h
    ];
};
convert.lch.lab = function(lch) {
    const l = lch[0];
    const c = lch[1];
    const h = lch[2];
    const hr = h / 360 * 2 * Math.PI;
    const a = c * Math.cos(hr);
    const b = c * Math.sin(hr);
    return [
        l,
        a,
        b
    ];
};
convert.rgb.ansi16 = function(args, saturation = null) {
    const [r, g, b] = args;
    let value = saturation === null ? convert.rgb.hsv(args)[2] : saturation; // Hsv -> ansi16 optimization
    value = Math.round(value / 50);
    if (value === 0) {
        return 30;
    }
    let ansi = 30 + (Math.round(b / 255) << 2 | Math.round(g / 255) << 1 | Math.round(r / 255));
    if (value === 2) {
        ansi += 60;
    }
    return ansi;
};
convert.hsv.ansi16 = function(args) {
    // Optimization here; we already know the value and don't need to get
    // it converted for us.
    return convert.rgb.ansi16(convert.hsv.rgb(args), args[2]);
};
convert.rgb.ansi256 = function(args) {
    const r = args[0];
    const g = args[1];
    const b = args[2];
    // We use the extended greyscale palette here, with the exception of
    // black and white. normal palette only has 4 greyscale shades.
    if (r === g && g === b) {
        if (r < 8) {
            return 16;
        }
        if (r > 248) {
            return 231;
        }
        return Math.round((r - 8) / 247 * 24) + 232;
    }
    const ansi = 16 + 36 * Math.round(r / 255 * 5) + 6 * Math.round(g / 255 * 5) + Math.round(b / 255 * 5);
    return ansi;
};
convert.ansi16.rgb = function(args) {
    let color = args % 10;
    // Handle greyscale
    if (color === 0 || color === 7) {
        if (args > 50) {
            color += 3.5;
        }
        color = color / 10.5 * 255;
        return [
            color,
            color,
            color
        ];
    }
    const mult = (~~(args > 50) + 1) * 0.5;
    const r = (color & 1) * mult * 255;
    const g = (color >> 1 & 1) * mult * 255;
    const b = (color >> 2 & 1) * mult * 255;
    return [
        r,
        g,
        b
    ];
};
convert.ansi256.rgb = function(args) {
    // Handle greyscale
    if (args >= 232) {
        const c = (args - 232) * 10 + 8;
        return [
            c,
            c,
            c
        ];
    }
    args -= 16;
    let rem;
    const r = Math.floor(args / 36) / 5 * 255;
    const g = Math.floor((rem = args % 36) / 6) / 5 * 255;
    const b = rem % 6 / 5 * 255;
    return [
        r,
        g,
        b
    ];
};
convert.rgb.hex = function(args) {
    const integer = ((Math.round(args[0]) & 0xFF) << 16) + ((Math.round(args[1]) & 0xFF) << 8) + (Math.round(args[2]) & 0xFF);
    const string = integer.toString(16).toUpperCase();
    return '000000'.substring(string.length) + string;
};
convert.hex.rgb = function(args) {
    const match = args.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
    if (!match) {
        return [
            0,
            0,
            0
        ];
    }
    let colorString = match[0];
    if (match[0].length === 3) {
        colorString = colorString.split('').map((char)=>{
            return char + char;
        }).join('');
    }
    const integer = parseInt(colorString, 16);
    const r = integer >> 16 & 0xFF;
    const g = integer >> 8 & 0xFF;
    const b = integer & 0xFF;
    return [
        r,
        g,
        b
    ];
};
convert.rgb.hcg = function(rgb) {
    const r = rgb[0] / 255;
    const g = rgb[1] / 255;
    const b = rgb[2] / 255;
    const max = Math.max(Math.max(r, g), b);
    const min = Math.min(Math.min(r, g), b);
    const chroma = max - min;
    let grayscale;
    let hue;
    if (chroma < 1) {
        grayscale = min / (1 - chroma);
    } else {
        grayscale = 0;
    }
    if (chroma <= 0) {
        hue = 0;
    } else if (max === r) {
        hue = (g - b) / chroma % 6;
    } else if (max === g) {
        hue = 2 + (b - r) / chroma;
    } else {
        hue = 4 + (r - g) / chroma;
    }
    hue /= 6;
    hue %= 1;
    return [
        hue * 360,
        chroma * 100,
        grayscale * 100
    ];
};
convert.hsl.hcg = function(hsl) {
    const s = hsl[1] / 100;
    const l = hsl[2] / 100;
    const c = l < 0.5 ? 2.0 * s * l : 2.0 * s * (1.0 - l);
    let f = 0;
    if (c < 1.0) {
        f = (l - 0.5 * c) / (1.0 - c);
    }
    return [
        hsl[0],
        c * 100,
        f * 100
    ];
};
convert.hsv.hcg = function(hsv) {
    const s = hsv[1] / 100;
    const v = hsv[2] / 100;
    const c = s * v;
    let f = 0;
    if (c < 1.0) {
        f = (v - c) / (1 - c);
    }
    return [
        hsv[0],
        c * 100,
        f * 100
    ];
};
convert.hcg.rgb = function(hcg) {
    const h = hcg[0] / 360;
    const c = hcg[1] / 100;
    const g = hcg[2] / 100;
    if (c === 0.0) {
        return [
            g * 255,
            g * 255,
            g * 255
        ];
    }
    const pure = [
        0,
        0,
        0
    ];
    const hi = h % 1 * 6;
    const v = hi % 1;
    const w = 1 - v;
    let mg = 0;
    /* eslint-disable max-statements-per-line */ switch(Math.floor(hi)){
        case 0:
            pure[0] = 1;
            pure[1] = v;
            pure[2] = 0;
            break;
        case 1:
            pure[0] = w;
            pure[1] = 1;
            pure[2] = 0;
            break;
        case 2:
            pure[0] = 0;
            pure[1] = 1;
            pure[2] = v;
            break;
        case 3:
            pure[0] = 0;
            pure[1] = w;
            pure[2] = 1;
            break;
        case 4:
            pure[0] = v;
            pure[1] = 0;
            pure[2] = 1;
            break;
        default:
            pure[0] = 1;
            pure[1] = 0;
            pure[2] = w;
    }
    /* eslint-enable max-statements-per-line */ mg = (1.0 - c) * g;
    return [
        (c * pure[0] + mg) * 255,
        (c * pure[1] + mg) * 255,
        (c * pure[2] + mg) * 255
    ];
};
convert.hcg.hsv = function(hcg) {
    const c = hcg[1] / 100;
    const g = hcg[2] / 100;
    const v = c + g * (1.0 - c);
    let f = 0;
    if (v > 0.0) {
        f = c / v;
    }
    return [
        hcg[0],
        f * 100,
        v * 100
    ];
};
convert.hcg.hsl = function(hcg) {
    const c = hcg[1] / 100;
    const g = hcg[2] / 100;
    const l = g * (1.0 - c) + 0.5 * c;
    let s = 0;
    if (l > 0.0 && l < 0.5) {
        s = c / (2 * l);
    } else if (l >= 0.5 && l < 1.0) {
        s = c / (2 * (1 - l));
    }
    return [
        hcg[0],
        s * 100,
        l * 100
    ];
};
convert.hcg.hwb = function(hcg) {
    const c = hcg[1] / 100;
    const g = hcg[2] / 100;
    const v = c + g * (1.0 - c);
    return [
        hcg[0],
        (v - c) * 100,
        (1 - v) * 100
    ];
};
convert.hwb.hcg = function(hwb) {
    const w = hwb[1] / 100;
    const b = hwb[2] / 100;
    const v = 1 - b;
    const c = v - w;
    let g = 0;
    if (c < 1) {
        g = (v - c) / (1 - c);
    }
    return [
        hwb[0],
        c * 100,
        g * 100
    ];
};
convert.apple.rgb = function(apple) {
    return [
        apple[0] / 65535 * 255,
        apple[1] / 65535 * 255,
        apple[2] / 65535 * 255
    ];
};
convert.rgb.apple = function(rgb) {
    return [
        rgb[0] / 255 * 65535,
        rgb[1] / 255 * 65535,
        rgb[2] / 255 * 65535
    ];
};
convert.gray.rgb = function(args) {
    return [
        args[0] / 100 * 255,
        args[0] / 100 * 255,
        args[0] / 100 * 255
    ];
};
convert.gray.hsl = function(args) {
    return [
        0,
        0,
        args[0]
    ];
};
convert.gray.hsv = convert.gray.hsl;
convert.gray.hwb = function(gray) {
    return [
        0,
        100,
        gray[0]
    ];
};
convert.gray.cmyk = function(gray) {
    return [
        0,
        0,
        0,
        gray[0]
    ];
};
convert.gray.lab = function(gray) {
    return [
        gray[0],
        0,
        0
    ];
};
convert.gray.hex = function(gray) {
    const val = Math.round(gray[0] / 100 * 255) & 0xFF;
    const integer = (val << 16) + (val << 8) + val;
    const string = integer.toString(16).toUpperCase();
    return '000000'.substring(string.length) + string;
};
convert.rgb.gray = function(rgb) {
    const val = (rgb[0] + rgb[1] + rgb[2]) / 3;
    return [
        val / 255 * 100
    ];
};
}),
"[project]/next-admin-dashboard/node_modules/color-convert/route.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const conversions = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/color-convert/conversions.js [app-rsc] (ecmascript)");
/*
	This function routes a model to all other models.

	all functions that are routed have a property `.conversion` attached
	to the returned synthetic function. This property is an array
	of strings, each with the steps in between the 'from' and 'to'
	color models (inclusive).

	conversions that are not possible simply are not included.
*/ function buildGraph() {
    const graph = {};
    // https://jsperf.com/object-keys-vs-for-in-with-closure/3
    const models = Object.keys(conversions);
    for(let len = models.length, i = 0; i < len; i++){
        graph[models[i]] = {
            // http://jsperf.com/1-vs-infinity
            // micro-opt, but this is simple.
            distance: -1,
            parent: null
        };
    }
    return graph;
}
// https://en.wikipedia.org/wiki/Breadth-first_search
function deriveBFS(fromModel) {
    const graph = buildGraph();
    const queue = [
        fromModel
    ]; // Unshift -> queue -> pop
    graph[fromModel].distance = 0;
    while(queue.length){
        const current = queue.pop();
        const adjacents = Object.keys(conversions[current]);
        for(let len = adjacents.length, i = 0; i < len; i++){
            const adjacent = adjacents[i];
            const node = graph[adjacent];
            if (node.distance === -1) {
                node.distance = graph[current].distance + 1;
                node.parent = current;
                queue.unshift(adjacent);
            }
        }
    }
    return graph;
}
function link(from, to) {
    return function(args) {
        return to(from(args));
    };
}
function wrapConversion(toModel, graph) {
    const path = [
        graph[toModel].parent,
        toModel
    ];
    let fn = conversions[graph[toModel].parent][toModel];
    let cur = graph[toModel].parent;
    while(graph[cur].parent){
        path.unshift(graph[cur].parent);
        fn = link(conversions[graph[cur].parent][cur], fn);
        cur = graph[cur].parent;
    }
    fn.conversion = path;
    return fn;
}
module.exports = function(fromModel) {
    const graph = deriveBFS(fromModel);
    const conversion = {};
    const models = Object.keys(graph);
    for(let len = models.length, i = 0; i < len; i++){
        const toModel = models[i];
        const node = graph[toModel];
        if (node.parent === null) {
            continue;
        }
        conversion[toModel] = wrapConversion(toModel, graph);
    }
    return conversion;
};
}),
"[project]/next-admin-dashboard/node_modules/color-convert/index.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const conversions = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/color-convert/conversions.js [app-rsc] (ecmascript)");
const route = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/color-convert/route.js [app-rsc] (ecmascript)");
const convert = {};
const models = Object.keys(conversions);
function wrapRaw(fn) {
    const wrappedFn = function(...args) {
        const arg0 = args[0];
        if (arg0 === undefined || arg0 === null) {
            return arg0;
        }
        if (arg0.length > 1) {
            args = arg0;
        }
        return fn(args);
    };
    // Preserve .conversion property if there is one
    if ('conversion' in fn) {
        wrappedFn.conversion = fn.conversion;
    }
    return wrappedFn;
}
function wrapRounded(fn) {
    const wrappedFn = function(...args) {
        const arg0 = args[0];
        if (arg0 === undefined || arg0 === null) {
            return arg0;
        }
        if (arg0.length > 1) {
            args = arg0;
        }
        const result = fn(args);
        // We're assuming the result is an array here.
        // see notice in conversions.js; don't use box types
        // in conversion functions.
        if (typeof result === 'object') {
            for(let len = result.length, i = 0; i < len; i++){
                result[i] = Math.round(result[i]);
            }
        }
        return result;
    };
    // Preserve .conversion property if there is one
    if ('conversion' in fn) {
        wrappedFn.conversion = fn.conversion;
    }
    return wrappedFn;
}
models.forEach((fromModel)=>{
    convert[fromModel] = {};
    Object.defineProperty(convert[fromModel], 'channels', {
        value: conversions[fromModel].channels
    });
    Object.defineProperty(convert[fromModel], 'labels', {
        value: conversions[fromModel].labels
    });
    const routes = route(fromModel);
    const routeModels = Object.keys(routes);
    routeModels.forEach((toModel)=>{
        const fn = routes[toModel];
        convert[fromModel][toModel] = wrapRounded(fn);
        convert[fromModel][toModel].raw = wrapRaw(fn);
    });
});
module.exports = convert;
}),
"[project]/next-admin-dashboard/node_modules/color/index.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const colorString = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/color-string/index.js [app-rsc] (ecmascript)");
const convert = __turbopack_context__.r("[project]/next-admin-dashboard/node_modules/color-convert/index.js [app-rsc] (ecmascript)");
const skippedModels = [
    // To be honest, I don't really feel like keyword belongs in color convert, but eh.
    'keyword',
    // Gray conflicts with some method names, and has its own method defined.
    'gray',
    // Shouldn't really be in color-convert either...
    'hex'
];
const hashedModelKeys = {};
for (const model of Object.keys(convert)){
    hashedModelKeys[[
        ...convert[model].labels
    ].sort().join('')] = model;
}
const limiters = {};
function Color(object, model) {
    if (!(this instanceof Color)) {
        return new Color(object, model);
    }
    if (model && model in skippedModels) {
        model = null;
    }
    if (model && !(model in convert)) {
        throw new Error('Unknown model: ' + model);
    }
    let i;
    let channels;
    if (object == null) {
        this.model = 'rgb';
        this.color = [
            0,
            0,
            0
        ];
        this.valpha = 1;
    } else if (object instanceof Color) {
        this.model = object.model;
        this.color = [
            ...object.color
        ];
        this.valpha = object.valpha;
    } else if (typeof object === 'string') {
        const result = colorString.get(object);
        if (result === null) {
            throw new Error('Unable to parse color from string: ' + object);
        }
        this.model = result.model;
        channels = convert[this.model].channels;
        this.color = result.value.slice(0, channels);
        this.valpha = typeof result.value[channels] === 'number' ? result.value[channels] : 1;
    } else if (object.length > 0) {
        this.model = model || 'rgb';
        channels = convert[this.model].channels;
        const newArray = Array.prototype.slice.call(object, 0, channels);
        this.color = zeroArray(newArray, channels);
        this.valpha = typeof object[channels] === 'number' ? object[channels] : 1;
    } else if (typeof object === 'number') {
        // This is always RGB - can be converted later on.
        this.model = 'rgb';
        this.color = [
            object >> 16 & 0xFF,
            object >> 8 & 0xFF,
            object & 0xFF
        ];
        this.valpha = 1;
    } else {
        this.valpha = 1;
        const keys = Object.keys(object);
        if ('alpha' in object) {
            keys.splice(keys.indexOf('alpha'), 1);
            this.valpha = typeof object.alpha === 'number' ? object.alpha : 0;
        }
        const hashedKeys = keys.sort().join('');
        if (!(hashedKeys in hashedModelKeys)) {
            throw new Error('Unable to parse color from object: ' + JSON.stringify(object));
        }
        this.model = hashedModelKeys[hashedKeys];
        const { labels } = convert[this.model];
        const color = [];
        for(i = 0; i < labels.length; i++){
            color.push(object[labels[i]]);
        }
        this.color = zeroArray(color);
    }
    // Perform limitations (clamping, etc.)
    if (limiters[this.model]) {
        channels = convert[this.model].channels;
        for(i = 0; i < channels; i++){
            const limit = limiters[this.model][i];
            if (limit) {
                this.color[i] = limit(this.color[i]);
            }
        }
    }
    this.valpha = Math.max(0, Math.min(1, this.valpha));
    if (Object.freeze) {
        Object.freeze(this);
    }
}
Color.prototype = {
    toString () {
        return this.string();
    },
    toJSON () {
        return this[this.model]();
    },
    string (places) {
        let self = this.model in colorString.to ? this : this.rgb();
        self = self.round(typeof places === 'number' ? places : 1);
        const args = self.valpha === 1 ? self.color : [
            ...self.color,
            this.valpha
        ];
        return colorString.to[self.model](args);
    },
    percentString (places) {
        const self = this.rgb().round(typeof places === 'number' ? places : 1);
        const args = self.valpha === 1 ? self.color : [
            ...self.color,
            this.valpha
        ];
        return colorString.to.rgb.percent(args);
    },
    array () {
        return this.valpha === 1 ? [
            ...this.color
        ] : [
            ...this.color,
            this.valpha
        ];
    },
    object () {
        const result = {};
        const { channels } = convert[this.model];
        const { labels } = convert[this.model];
        for(let i = 0; i < channels; i++){
            result[labels[i]] = this.color[i];
        }
        if (this.valpha !== 1) {
            result.alpha = this.valpha;
        }
        return result;
    },
    unitArray () {
        const rgb = this.rgb().color;
        rgb[0] /= 255;
        rgb[1] /= 255;
        rgb[2] /= 255;
        if (this.valpha !== 1) {
            rgb.push(this.valpha);
        }
        return rgb;
    },
    unitObject () {
        const rgb = this.rgb().object();
        rgb.r /= 255;
        rgb.g /= 255;
        rgb.b /= 255;
        if (this.valpha !== 1) {
            rgb.alpha = this.valpha;
        }
        return rgb;
    },
    round (places) {
        places = Math.max(places || 0, 0);
        return new Color([
            ...this.color.map(roundToPlace(places)),
            this.valpha
        ], this.model);
    },
    alpha (value) {
        if (value !== undefined) {
            return new Color([
                ...this.color,
                Math.max(0, Math.min(1, value))
            ], this.model);
        }
        return this.valpha;
    },
    // Rgb
    red: getset('rgb', 0, maxfn(255)),
    green: getset('rgb', 1, maxfn(255)),
    blue: getset('rgb', 2, maxfn(255)),
    hue: getset([
        'hsl',
        'hsv',
        'hsl',
        'hwb',
        'hcg'
    ], 0, (value)=>(value % 360 + 360) % 360),
    saturationl: getset('hsl', 1, maxfn(100)),
    lightness: getset('hsl', 2, maxfn(100)),
    saturationv: getset('hsv', 1, maxfn(100)),
    value: getset('hsv', 2, maxfn(100)),
    chroma: getset('hcg', 1, maxfn(100)),
    gray: getset('hcg', 2, maxfn(100)),
    white: getset('hwb', 1, maxfn(100)),
    wblack: getset('hwb', 2, maxfn(100)),
    cyan: getset('cmyk', 0, maxfn(100)),
    magenta: getset('cmyk', 1, maxfn(100)),
    yellow: getset('cmyk', 2, maxfn(100)),
    black: getset('cmyk', 3, maxfn(100)),
    x: getset('xyz', 0, maxfn(95.047)),
    y: getset('xyz', 1, maxfn(100)),
    z: getset('xyz', 2, maxfn(108.833)),
    l: getset('lab', 0, maxfn(100)),
    a: getset('lab', 1),
    b: getset('lab', 2),
    keyword (value) {
        if (value !== undefined) {
            return new Color(value);
        }
        return convert[this.model].keyword(this.color);
    },
    hex (value) {
        if (value !== undefined) {
            return new Color(value);
        }
        return colorString.to.hex(this.rgb().round().color);
    },
    hexa (value) {
        if (value !== undefined) {
            return new Color(value);
        }
        const rgbArray = this.rgb().round().color;
        let alphaHex = Math.round(this.valpha * 255).toString(16).toUpperCase();
        if (alphaHex.length === 1) {
            alphaHex = '0' + alphaHex;
        }
        return colorString.to.hex(rgbArray) + alphaHex;
    },
    rgbNumber () {
        const rgb = this.rgb().color;
        return (rgb[0] & 0xFF) << 16 | (rgb[1] & 0xFF) << 8 | rgb[2] & 0xFF;
    },
    luminosity () {
        // http://www.w3.org/TR/WCAG20/#relativeluminancedef
        const rgb = this.rgb().color;
        const lum = [];
        for (const [i, element] of rgb.entries()){
            const chan = element / 255;
            lum[i] = chan <= 0.04045 ? chan / 12.92 : ((chan + 0.055) / 1.055) ** 2.4;
        }
        return 0.2126 * lum[0] + 0.7152 * lum[1] + 0.0722 * lum[2];
    },
    contrast (color2) {
        // http://www.w3.org/TR/WCAG20/#contrast-ratiodef
        const lum1 = this.luminosity();
        const lum2 = color2.luminosity();
        if (lum1 > lum2) {
            return (lum1 + 0.05) / (lum2 + 0.05);
        }
        return (lum2 + 0.05) / (lum1 + 0.05);
    },
    level (color2) {
        // https://www.w3.org/TR/WCAG/#contrast-enhanced
        const contrastRatio = this.contrast(color2);
        if (contrastRatio >= 7) {
            return 'AAA';
        }
        return contrastRatio >= 4.5 ? 'AA' : '';
    },
    isDark () {
        // YIQ equation from http://24ways.org/2010/calculating-color-contrast
        const rgb = this.rgb().color;
        const yiq = (rgb[0] * 2126 + rgb[1] * 7152 + rgb[2] * 722) / 10000;
        return yiq < 128;
    },
    isLight () {
        return !this.isDark();
    },
    negate () {
        const rgb = this.rgb();
        for(let i = 0; i < 3; i++){
            rgb.color[i] = 255 - rgb.color[i];
        }
        return rgb;
    },
    lighten (ratio) {
        const hsl = this.hsl();
        hsl.color[2] += hsl.color[2] * ratio;
        return hsl;
    },
    darken (ratio) {
        const hsl = this.hsl();
        hsl.color[2] -= hsl.color[2] * ratio;
        return hsl;
    },
    saturate (ratio) {
        const hsl = this.hsl();
        hsl.color[1] += hsl.color[1] * ratio;
        return hsl;
    },
    desaturate (ratio) {
        const hsl = this.hsl();
        hsl.color[1] -= hsl.color[1] * ratio;
        return hsl;
    },
    whiten (ratio) {
        const hwb = this.hwb();
        hwb.color[1] += hwb.color[1] * ratio;
        return hwb;
    },
    blacken (ratio) {
        const hwb = this.hwb();
        hwb.color[2] += hwb.color[2] * ratio;
        return hwb;
    },
    grayscale () {
        // http://en.wikipedia.org/wiki/Grayscale#Converting_color_to_grayscale
        const rgb = this.rgb().color;
        const value = rgb[0] * 0.3 + rgb[1] * 0.59 + rgb[2] * 0.11;
        return Color.rgb(value, value, value);
    },
    fade (ratio) {
        return this.alpha(this.valpha - this.valpha * ratio);
    },
    opaquer (ratio) {
        return this.alpha(this.valpha + this.valpha * ratio);
    },
    rotate (degrees) {
        const hsl = this.hsl();
        let hue = hsl.color[0];
        hue = (hue + degrees) % 360;
        hue = hue < 0 ? 360 + hue : hue;
        hsl.color[0] = hue;
        return hsl;
    },
    mix (mixinColor, weight) {
        // Ported from sass implementation in C
        // https://github.com/sass/libsass/blob/0e6b4a2850092356aa3ece07c6b249f0221caced/functions.cpp#L209
        if (!mixinColor || !mixinColor.rgb) {
            throw new Error('Argument to "mix" was not a Color instance, but rather an instance of ' + typeof mixinColor);
        }
        const color1 = mixinColor.rgb();
        const color2 = this.rgb();
        const p = weight === undefined ? 0.5 : weight;
        const w = 2 * p - 1;
        const a = color1.alpha() - color2.alpha();
        const w1 = ((w * a === -1 ? w : (w + a) / (1 + w * a)) + 1) / 2;
        const w2 = 1 - w1;
        return Color.rgb(w1 * color1.red() + w2 * color2.red(), w1 * color1.green() + w2 * color2.green(), w1 * color1.blue() + w2 * color2.blue(), color1.alpha() * p + color2.alpha() * (1 - p));
    }
};
// Model conversion methods and static constructors
for (const model of Object.keys(convert)){
    if (skippedModels.includes(model)) {
        continue;
    }
    const { channels } = convert[model];
    // Conversion methods
    Color.prototype[model] = function(...args) {
        if (this.model === model) {
            return new Color(this);
        }
        if (args.length > 0) {
            return new Color(args, model);
        }
        return new Color([
            ...assertArray(convert[this.model][model].raw(this.color)),
            this.valpha
        ], model);
    };
    // 'static' construction methods
    Color[model] = function(...args) {
        let color = args[0];
        if (typeof color === 'number') {
            color = zeroArray(args, channels);
        }
        return new Color(color, model);
    };
}
function roundTo(number, places) {
    return Number(number.toFixed(places));
}
function roundToPlace(places) {
    return function(number) {
        return roundTo(number, places);
    };
}
function getset(model, channel, modifier) {
    model = Array.isArray(model) ? model : [
        model
    ];
    for (const m of model){
        (limiters[m] || (limiters[m] = []))[channel] = modifier;
    }
    model = model[0];
    return function(value) {
        let result;
        if (value !== undefined) {
            if (modifier) {
                value = modifier(value);
            }
            result = this[model]();
            result.color[channel] = value;
            return result;
        }
        result = this[model]().color[channel];
        if (modifier) {
            result = modifier(result);
        }
        return result;
    };
}
function maxfn(max) {
    return function(v) {
        return Math.max(0, Math.min(max, v));
    };
}
function assertArray(value) {
    return Array.isArray(value) ? value : [
        value
    ];
}
function zeroArray(array, length) {
    for(let i = 0; i < length; i++){
        if (typeof array[i] !== 'number') {
            array[i] = 0;
        }
    }
    return array;
}
module.exports = Color;
}),
"[project]/next-admin-dashboard/node_modules/tailwindcss/dist/plugin.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>u
]);
function g(i, n) {
    return {
        handler: i,
        config: n
    };
}
g.withOptions = function(i, n = ()=>({})) {
    function t(o) {
        return {
            handler: i(o),
            config: n(o)
        };
    }
    return t.__isOptionsFunction = !0, t;
};
var u = g;
;
}),
"[project]/next-admin-dashboard/node_modules/deepmerge/dist/cjs.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var isMergeableObject = function isMergeableObject(value) {
    return isNonNullObject(value) && !isSpecial(value);
};
function isNonNullObject(value) {
    return !!value && typeof value === 'object';
}
function isSpecial(value) {
    var stringValue = Object.prototype.toString.call(value);
    return stringValue === '[object RegExp]' || stringValue === '[object Date]' || isReactElement(value);
}
// see https://github.com/facebook/react/blob/b5ac963fb791d1298e7f396236383bc955f916c1/src/isomorphic/classic/element/ReactElement.js#L21-L25
var canUseSymbol = typeof Symbol === 'function' && Symbol.for;
var REACT_ELEMENT_TYPE = canUseSymbol ? Symbol.for('react.element') : 0xeac7;
function isReactElement(value) {
    return value.$$typeof === REACT_ELEMENT_TYPE;
}
function emptyTarget(val) {
    return Array.isArray(val) ? [] : {};
}
function cloneUnlessOtherwiseSpecified(value, options) {
    return options.clone !== false && options.isMergeableObject(value) ? deepmerge(emptyTarget(value), value, options) : value;
}
function defaultArrayMerge(target, source, options) {
    return target.concat(source).map(function(element) {
        return cloneUnlessOtherwiseSpecified(element, options);
    });
}
function getMergeFunction(key, options) {
    if (!options.customMerge) {
        return deepmerge;
    }
    var customMerge = options.customMerge(key);
    return typeof customMerge === 'function' ? customMerge : deepmerge;
}
function getEnumerableOwnPropertySymbols(target) {
    return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(target).filter(function(symbol) {
        return Object.propertyIsEnumerable.call(target, symbol);
    }) : [];
}
function getKeys(target) {
    return Object.keys(target).concat(getEnumerableOwnPropertySymbols(target));
}
function propertyIsOnObject(object, property) {
    try {
        return property in object;
    } catch (_) {
        return false;
    }
}
// Protects from prototype poisoning and unexpected merging up the prototype chain.
function propertyIsUnsafe(target, key) {
    return propertyIsOnObject(target, key) // Properties are safe to merge if they don't exist in the target yet,
     && !(Object.hasOwnProperty.call(target, key) // unsafe if they exist up the prototype chain,
     && Object.propertyIsEnumerable.call(target, key)) // and also unsafe if they're nonenumerable.
    ;
}
function mergeObject(target, source, options) {
    var destination = {};
    if (options.isMergeableObject(target)) {
        getKeys(target).forEach(function(key) {
            destination[key] = cloneUnlessOtherwiseSpecified(target[key], options);
        });
    }
    getKeys(source).forEach(function(key) {
        if (propertyIsUnsafe(target, key)) {
            return;
        }
        if (propertyIsOnObject(target, key) && options.isMergeableObject(source[key])) {
            destination[key] = getMergeFunction(key, options)(target[key], source[key], options);
        } else {
            destination[key] = cloneUnlessOtherwiseSpecified(source[key], options);
        }
    });
    return destination;
}
function deepmerge(target, source, options) {
    options = options || {};
    options.arrayMerge = options.arrayMerge || defaultArrayMerge;
    options.isMergeableObject = options.isMergeableObject || isMergeableObject;
    // cloneUnlessOtherwiseSpecified is added to `options` so that custom arrayMerge()
    // implementations can use it. The caller may not replace it.
    options.cloneUnlessOtherwiseSpecified = cloneUnlessOtherwiseSpecified;
    var sourceIsArray = Array.isArray(source);
    var targetIsArray = Array.isArray(target);
    var sourceAndTargetTypesMatch = sourceIsArray === targetIsArray;
    if (!sourceAndTargetTypesMatch) {
        return cloneUnlessOtherwiseSpecified(source, options);
    } else if (sourceIsArray) {
        return options.arrayMerge(target, source, options);
    } else {
        return mergeObject(target, source, options);
    }
}
deepmerge.all = function deepmergeAll(array, options) {
    if (!Array.isArray(array)) {
        throw new Error('first argument should be an array');
    }
    return array.reduce(function(prev, next) {
        return deepmerge(prev, next, options);
    }, {});
};
var deepmerge_1 = deepmerge;
module.exports = deepmerge_1;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Accordion",
    ()=>Accordion,
    "AccordionItem",
    ()=>AccordionItem,
    "useAccordion",
    ()=>useAccordion,
    "useAccordionItem",
    ()=>useAccordionItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Accordion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Accordion() from the server but Accordion is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs <module evaluation>", "Accordion");
const AccordionItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AccordionItem() from the server but AccordionItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs <module evaluation>", "AccordionItem");
const useAccordion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAccordion() from the server but useAccordion is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs <module evaluation>", "useAccordion");
const useAccordionItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAccordionItem() from the server but useAccordionItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs <module evaluation>", "useAccordionItem");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Accordion",
    ()=>Accordion,
    "AccordionItem",
    ()=>AccordionItem,
    "useAccordion",
    ()=>useAccordion,
    "useAccordionItem",
    ()=>useAccordionItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Accordion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Accordion() from the server but Accordion is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs", "Accordion");
const AccordionItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AccordionItem() from the server but AccordionItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs", "AccordionItem");
const useAccordion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAccordion() from the server but useAccordion is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs", "useAccordion");
const useAccordionItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAccordionItem() from the server but useAccordionItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs", "useAccordionItem");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$accordion$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$accordion$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/accordion/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$accordion$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Avatar",
    ()=>Avatar,
    "AvatarGroup",
    ()=>AvatarGroup,
    "AvatarGroupProvider",
    ()=>AvatarGroupProvider,
    "AvatarIcon",
    ()=>AvatarIcon,
    "useAvatar",
    ()=>useAvatar,
    "useAvatarGroup",
    ()=>useAvatarGroup,
    "useAvatarGroupContext",
    ()=>useAvatarGroupContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Avatar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Avatar() from the server but Avatar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs <module evaluation>", "Avatar");
const AvatarGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AvatarGroup() from the server but AvatarGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs <module evaluation>", "AvatarGroup");
const AvatarGroupProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AvatarGroupProvider() from the server but AvatarGroupProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs <module evaluation>", "AvatarGroupProvider");
const AvatarIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AvatarIcon() from the server but AvatarIcon is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs <module evaluation>", "AvatarIcon");
const useAvatar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAvatar() from the server but useAvatar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs <module evaluation>", "useAvatar");
const useAvatarGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAvatarGroup() from the server but useAvatarGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs <module evaluation>", "useAvatarGroup");
const useAvatarGroupContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAvatarGroupContext() from the server but useAvatarGroupContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs <module evaluation>", "useAvatarGroupContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Avatar",
    ()=>Avatar,
    "AvatarGroup",
    ()=>AvatarGroup,
    "AvatarGroupProvider",
    ()=>AvatarGroupProvider,
    "AvatarIcon",
    ()=>AvatarIcon,
    "useAvatar",
    ()=>useAvatar,
    "useAvatarGroup",
    ()=>useAvatarGroup,
    "useAvatarGroupContext",
    ()=>useAvatarGroupContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Avatar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Avatar() from the server but Avatar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs", "Avatar");
const AvatarGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AvatarGroup() from the server but AvatarGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs", "AvatarGroup");
const AvatarGroupProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AvatarGroupProvider() from the server but AvatarGroupProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs", "AvatarGroupProvider");
const AvatarIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AvatarIcon() from the server but AvatarIcon is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs", "AvatarIcon");
const useAvatar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAvatar() from the server but useAvatar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs", "useAvatar");
const useAvatarGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAvatarGroup() from the server but useAvatarGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs", "useAvatarGroup");
const useAvatarGroupContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAvatarGroupContext() from the server but useAvatarGroupContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs", "useAvatarGroupContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/avatar/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/badge/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Badge",
    ()=>Badge,
    "useBadge",
    ()=>useBadge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Badge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Badge() from the server but Badge is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/badge/dist/index.mjs <module evaluation>", "Badge");
const useBadge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useBadge() from the server but useBadge is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/badge/dist/index.mjs <module evaluation>", "useBadge");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/badge/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Badge",
    ()=>Badge,
    "useBadge",
    ()=>useBadge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Badge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Badge() from the server but Badge is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/badge/dist/index.mjs", "Badge");
const useBadge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useBadge() from the server but useBadge is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/badge/dist/index.mjs", "useBadge");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/badge/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$badge$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/badge/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$badge$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/badge/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$badge$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Button",
    ()=>Button,
    "ButtonGroup",
    ()=>ButtonGroup,
    "ButtonGroupProvider",
    ()=>ButtonGroupProvider,
    "useButton",
    ()=>useButton,
    "useButtonGroup",
    ()=>useButtonGroup,
    "useButtonGroupContext",
    ()=>useButtonGroupContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Button = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Button() from the server but Button is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs <module evaluation>", "Button");
const ButtonGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ButtonGroup() from the server but ButtonGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs <module evaluation>", "ButtonGroup");
const ButtonGroupProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ButtonGroupProvider() from the server but ButtonGroupProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs <module evaluation>", "ButtonGroupProvider");
const useButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useButton() from the server but useButton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs <module evaluation>", "useButton");
const useButtonGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useButtonGroup() from the server but useButtonGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs <module evaluation>", "useButtonGroup");
const useButtonGroupContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useButtonGroupContext() from the server but useButtonGroupContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs <module evaluation>", "useButtonGroupContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Button",
    ()=>Button,
    "ButtonGroup",
    ()=>ButtonGroup,
    "ButtonGroupProvider",
    ()=>ButtonGroupProvider,
    "useButton",
    ()=>useButton,
    "useButtonGroup",
    ()=>useButtonGroup,
    "useButtonGroupContext",
    ()=>useButtonGroupContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Button = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Button() from the server but Button is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs", "Button");
const ButtonGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ButtonGroup() from the server but ButtonGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs", "ButtonGroup");
const ButtonGroupProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ButtonGroupProvider() from the server but ButtonGroupProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs", "ButtonGroupProvider");
const useButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useButton() from the server but useButton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs", "useButton");
const useButtonGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useButtonGroup() from the server but useButtonGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs", "useButtonGroup");
const useButtonGroupContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useButtonGroupContext() from the server but useButtonGroupContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs", "useButtonGroupContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/button/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardBody",
    ()=>CardBody,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardProvider",
    ()=>CardProvider,
    "useCard",
    ()=>useCard,
    "useCardContext",
    ()=>useCardContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Card = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Card() from the server but Card is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs <module evaluation>", "Card");
const CardBody = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CardBody() from the server but CardBody is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs <module evaluation>", "CardBody");
const CardFooter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CardFooter() from the server but CardFooter is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs <module evaluation>", "CardFooter");
const CardHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CardHeader() from the server but CardHeader is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs <module evaluation>", "CardHeader");
const CardProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CardProvider() from the server but CardProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs <module evaluation>", "CardProvider");
const useCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCard() from the server but useCard is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs <module evaluation>", "useCard");
const useCardContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCardContext() from the server but useCardContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs <module evaluation>", "useCardContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardBody",
    ()=>CardBody,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardProvider",
    ()=>CardProvider,
    "useCard",
    ()=>useCard,
    "useCardContext",
    ()=>useCardContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Card = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Card() from the server but Card is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs", "Card");
const CardBody = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CardBody() from the server but CardBody is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs", "CardBody");
const CardFooter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CardFooter() from the server but CardFooter is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs", "CardFooter");
const CardHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CardHeader() from the server but CardHeader is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs", "CardHeader");
const CardProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CardProvider() from the server but CardProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs", "CardProvider");
const useCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCard() from the server but useCard is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs", "useCard");
const useCardContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCardContext() from the server but useCardContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs", "useCardContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$card$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$card$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/card/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$card$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/chip/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Chip",
    ()=>Chip,
    "useChip",
    ()=>useChip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Chip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Chip() from the server but Chip is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/chip/dist/index.mjs <module evaluation>", "Chip");
const useChip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useChip() from the server but useChip is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/chip/dist/index.mjs <module evaluation>", "useChip");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/chip/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Chip",
    ()=>Chip,
    "useChip",
    ()=>useChip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Chip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Chip() from the server but Chip is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/chip/dist/index.mjs", "Chip");
const useChip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useChip() from the server but useChip is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/chip/dist/index.mjs", "useChip");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/chip/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$chip$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/chip/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$chip$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/chip/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$chip$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Checkbox",
    ()=>Checkbox,
    "CheckboxGroup",
    ()=>CheckboxGroup,
    "CheckboxGroupProvider",
    ()=>CheckboxGroupProvider,
    "CheckboxIcon",
    ()=>CheckboxIcon,
    "useCheckbox",
    ()=>useCheckbox,
    "useCheckboxGroup",
    ()=>useCheckboxGroup,
    "useCheckboxGroupContext",
    ()=>useCheckboxGroupContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Checkbox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Checkbox() from the server but Checkbox is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs <module evaluation>", "Checkbox");
const CheckboxGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CheckboxGroup() from the server but CheckboxGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs <module evaluation>", "CheckboxGroup");
const CheckboxGroupProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CheckboxGroupProvider() from the server but CheckboxGroupProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs <module evaluation>", "CheckboxGroupProvider");
const CheckboxIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CheckboxIcon() from the server but CheckboxIcon is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs <module evaluation>", "CheckboxIcon");
const useCheckbox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCheckbox() from the server but useCheckbox is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs <module evaluation>", "useCheckbox");
const useCheckboxGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCheckboxGroup() from the server but useCheckboxGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs <module evaluation>", "useCheckboxGroup");
const useCheckboxGroupContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCheckboxGroupContext() from the server but useCheckboxGroupContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs <module evaluation>", "useCheckboxGroupContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Checkbox",
    ()=>Checkbox,
    "CheckboxGroup",
    ()=>CheckboxGroup,
    "CheckboxGroupProvider",
    ()=>CheckboxGroupProvider,
    "CheckboxIcon",
    ()=>CheckboxIcon,
    "useCheckbox",
    ()=>useCheckbox,
    "useCheckboxGroup",
    ()=>useCheckboxGroup,
    "useCheckboxGroupContext",
    ()=>useCheckboxGroupContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Checkbox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Checkbox() from the server but Checkbox is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs", "Checkbox");
const CheckboxGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CheckboxGroup() from the server but CheckboxGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs", "CheckboxGroup");
const CheckboxGroupProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CheckboxGroupProvider() from the server but CheckboxGroupProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs", "CheckboxGroupProvider");
const CheckboxIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CheckboxIcon() from the server but CheckboxIcon is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs", "CheckboxIcon");
const useCheckbox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCheckbox() from the server but useCheckbox is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs", "useCheckbox");
const useCheckboxGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCheckboxGroup() from the server but useCheckboxGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs", "useCheckboxGroup");
const useCheckboxGroupContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCheckboxGroupContext() from the server but useCheckboxGroupContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs", "useCheckboxGroupContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/checkbox/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/system-rsc/dist/chunk-YFAKJTDR.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/utils.ts
__turbopack_context__.s([
    "forwardRef",
    ()=>forwardRef,
    "isHeroUIEl",
    ()=>isHeroUIEl,
    "mapPropsVariants",
    ()=>mapPropsVariants,
    "mapPropsVariantsWithCommon",
    ()=>mapPropsVariantsWithCommon,
    "toIterator",
    ()=>toIterator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
function forwardRef(component) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(component);
}
var toIterator = (obj)=>{
    return {
        ...obj,
        [Symbol.iterator]: function() {
            const keys = Object.keys(this);
            let index = 0;
            return {
                next: ()=>{
                    if (index >= keys.length) {
                        return {
                            done: true
                        };
                    }
                    const key = keys[index];
                    const value = this[key];
                    index++;
                    return {
                        value: {
                            key,
                            value
                        },
                        done: false
                    };
                }
            };
        }
    };
};
var mapPropsVariants = (props, variantKeys, removeVariantProps = true)=>{
    if (!variantKeys) {
        return [
            props,
            {}
        ];
    }
    const picked = variantKeys.reduce((acc, key)=>{
        if (key in props) {
            return {
                ...acc,
                [key]: props[key]
            };
        } else {
            return acc;
        }
    }, {});
    if (removeVariantProps) {
        const omitted = Object.keys(props).filter((key)=>!variantKeys.includes(key)).reduce((acc, key)=>({
                ...acc,
                [key]: props[key]
            }), {});
        return [
            omitted,
            picked
        ];
    } else {
        return [
            props,
            picked
        ];
    }
};
var mapPropsVariantsWithCommon = (originalProps, variantKeys, commonKeys)=>{
    const props = Object.keys(originalProps).filter((key)=>!variantKeys.includes(key) || (commonKeys == null ? void 0 : commonKeys.includes(key))).reduce((acc, key)=>({
            ...acc,
            [key]: originalProps[key]
        }), {});
    const variants = variantKeys.reduce((acc, key)=>({
            ...acc,
            [key]: originalProps[key]
        }), {});
    return [
        props,
        variants
    ];
};
var isHeroUIEl = (component)=>{
    var _a, _b, _c;
    return !!((_c = (_b = (_a = component.type) == null ? void 0 : _a.render) == null ? void 0 : _b.displayName) == null ? void 0 : _c.includes("HeroUI"));
};
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/code/dist/chunk-UDFNFZDA.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/use-code.ts
__turbopack_context__.s([
    "useCode",
    ()=>useCode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$chunk$2d$6N2H53XF$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/theme/dist/chunk-6N2H53XF.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/system-rsc/dist/chunk-YFAKJTDR.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$shared$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/shared-utils/dist/index.mjs [app-rsc] (ecmascript)");
;
;
;
;
function useCode(originalProps) {
    const [props, variantProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mapPropsVariants"])(originalProps, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$chunk$2d$6N2H53XF$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["code"].variantKeys);
    const { as, children, className, ...otherProps } = props;
    const Component = as || "code";
    const styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$chunk$2d$6N2H53XF$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["code"])({
            ...variantProps,
            className
        }), [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$shared$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["objectToDeps"])(variantProps),
        className
    ]);
    const getCodeProps = ()=>{
        return {
            className: styles,
            ...otherProps
        };
    };
    return {
        Component,
        children,
        getCodeProps
    };
}
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/code/dist/chunk-C3KKIFEX.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "code_default",
    ()=>code_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$chunk$2d$UDFNFZDA$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/code/dist/chunk-UDFNFZDA.mjs [app-rsc] (ecmascript)");
// src/code.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/system-rsc/dist/chunk-YFAKJTDR.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-runtime.js [app-rsc] (ecmascript)");
;
;
;
var Code = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])((props, ref)=>{
    const { Component, children, getCodeProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$chunk$2d$UDFNFZDA$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCode"])({
        ...props
    });
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref,
        ...getCodeProps(),
        children
    });
});
Code.displayName = "HeroUI.Code";
var code_default = Code;
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/code/dist/index.mjs [app-rsc] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$chunk$2d$C3KKIFEX$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/code/dist/chunk-C3KKIFEX.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$chunk$2d$UDFNFZDA$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/code/dist/chunk-UDFNFZDA.mjs [app-rsc] (ecmascript)");
;
;
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/code/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Code",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$chunk$2d$C3KKIFEX$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["code_default"],
    "useCode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$chunk$2d$UDFNFZDA$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCode"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/code/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$chunk$2d$C3KKIFEX$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/code/dist/chunk-C3KKIFEX.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$code$2f$dist$2f$chunk$2d$UDFNFZDA$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/code/dist/chunk-UDFNFZDA.mjs [app-rsc] (ecmascript)");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Link",
    ()=>Link,
    "LinkIcon",
    ()=>LinkIcon,
    "useLink",
    ()=>useLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Link = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Link() from the server but Link is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs <module evaluation>", "Link");
const LinkIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call LinkIcon() from the server but LinkIcon is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs <module evaluation>", "LinkIcon");
const useLink = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useLink() from the server but useLink is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs <module evaluation>", "useLink");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Link",
    ()=>Link,
    "LinkIcon",
    ()=>LinkIcon,
    "useLink",
    ()=>useLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Link = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Link() from the server but Link is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs", "Link");
const LinkIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call LinkIcon() from the server but LinkIcon is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs", "LinkIcon");
const useLink = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useLink() from the server but useLink is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs", "useLink");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$link$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$link$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/link/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$link$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Pagination",
    ()=>Pagination,
    "PaginationCursor",
    ()=>PaginationCursor,
    "PaginationItem",
    ()=>PaginationItem,
    "PaginationItemType",
    ()=>PaginationItemType,
    "usePagination",
    ()=>usePagination,
    "usePaginationItem",
    ()=>usePaginationItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Pagination = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Pagination() from the server but Pagination is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs <module evaluation>", "Pagination");
const PaginationCursor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PaginationCursor() from the server but PaginationCursor is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs <module evaluation>", "PaginationCursor");
const PaginationItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PaginationItem() from the server but PaginationItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs <module evaluation>", "PaginationItem");
const PaginationItemType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PaginationItemType() from the server but PaginationItemType is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs <module evaluation>", "PaginationItemType");
const usePagination = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call usePagination() from the server but usePagination is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs <module evaluation>", "usePagination");
const usePaginationItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call usePaginationItem() from the server but usePaginationItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs <module evaluation>", "usePaginationItem");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Pagination",
    ()=>Pagination,
    "PaginationCursor",
    ()=>PaginationCursor,
    "PaginationItem",
    ()=>PaginationItem,
    "PaginationItemType",
    ()=>PaginationItemType,
    "usePagination",
    ()=>usePagination,
    "usePaginationItem",
    ()=>usePaginationItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Pagination = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Pagination() from the server but Pagination is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs", "Pagination");
const PaginationCursor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PaginationCursor() from the server but PaginationCursor is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs", "PaginationCursor");
const PaginationItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PaginationItem() from the server but PaginationItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs", "PaginationItem");
const PaginationItemType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PaginationItemType() from the server but PaginationItemType is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs", "PaginationItemType");
const usePagination = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call usePagination() from the server but usePagination is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs", "usePagination");
const usePaginationItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call usePaginationItem() from the server but usePaginationItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs", "usePaginationItem");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$pagination$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$pagination$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/pagination/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$pagination$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Radio",
    ()=>Radio,
    "RadioGroup",
    ()=>RadioGroup,
    "RadioGroupProvider",
    ()=>RadioGroupProvider,
    "useRadio",
    ()=>useRadio,
    "useRadioGroup",
    ()=>useRadioGroup,
    "useRadioGroupContext",
    ()=>useRadioGroupContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Radio = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Radio() from the server but Radio is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs <module evaluation>", "Radio");
const RadioGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call RadioGroup() from the server but RadioGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs <module evaluation>", "RadioGroup");
const RadioGroupProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call RadioGroupProvider() from the server but RadioGroupProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs <module evaluation>", "RadioGroupProvider");
const useRadio = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useRadio() from the server but useRadio is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs <module evaluation>", "useRadio");
const useRadioGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useRadioGroup() from the server but useRadioGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs <module evaluation>", "useRadioGroup");
const useRadioGroupContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useRadioGroupContext() from the server but useRadioGroupContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs <module evaluation>", "useRadioGroupContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Radio",
    ()=>Radio,
    "RadioGroup",
    ()=>RadioGroup,
    "RadioGroupProvider",
    ()=>RadioGroupProvider,
    "useRadio",
    ()=>useRadio,
    "useRadioGroup",
    ()=>useRadioGroup,
    "useRadioGroupContext",
    ()=>useRadioGroupContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Radio = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Radio() from the server but Radio is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs", "Radio");
const RadioGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call RadioGroup() from the server but RadioGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs", "RadioGroup");
const RadioGroupProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call RadioGroupProvider() from the server but RadioGroupProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs", "RadioGroupProvider");
const useRadio = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useRadio() from the server but useRadio is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs", "useRadio");
const useRadioGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useRadioGroup() from the server but useRadioGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs", "useRadioGroup");
const useRadioGroupContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useRadioGroupContext() from the server but useRadioGroupContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs", "useRadioGroupContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$radio$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$radio$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/radio/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$radio$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/snippet/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Snippet",
    ()=>Snippet,
    "useSnippet",
    ()=>useSnippet
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Snippet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Snippet() from the server but Snippet is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/snippet/dist/index.mjs <module evaluation>", "Snippet");
const useSnippet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSnippet() from the server but useSnippet is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/snippet/dist/index.mjs <module evaluation>", "useSnippet");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/snippet/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Snippet",
    ()=>Snippet,
    "useSnippet",
    ()=>useSnippet
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Snippet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Snippet() from the server but Snippet is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/snippet/dist/index.mjs", "Snippet");
const useSnippet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSnippet() from the server but useSnippet is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/snippet/dist/index.mjs", "useSnippet");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/snippet/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$snippet$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/snippet/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$snippet$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/snippet/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$snippet$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/spinner/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Spinner",
    ()=>Spinner,
    "useSpinner",
    ()=>useSpinner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Spinner = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Spinner() from the server but Spinner is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/spinner/dist/index.mjs <module evaluation>", "Spinner");
const useSpinner = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSpinner() from the server but useSpinner is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/spinner/dist/index.mjs <module evaluation>", "useSpinner");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/spinner/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Spinner",
    ()=>Spinner,
    "useSpinner",
    ()=>useSpinner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Spinner = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Spinner() from the server but Spinner is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/spinner/dist/index.mjs", "Spinner");
const useSpinner = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSpinner() from the server but useSpinner is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/spinner/dist/index.mjs", "useSpinner");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/spinner/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spinner$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/spinner/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spinner$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/spinner/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spinner$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/switch/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Switch",
    ()=>Switch,
    "useSwitch",
    ()=>useSwitch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Switch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Switch() from the server but Switch is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/switch/dist/index.mjs <module evaluation>", "Switch");
const useSwitch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSwitch() from the server but useSwitch is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/switch/dist/index.mjs <module evaluation>", "useSwitch");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/switch/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Switch",
    ()=>Switch,
    "useSwitch",
    ()=>useSwitch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Switch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Switch() from the server but Switch is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/switch/dist/index.mjs", "Switch");
const useSwitch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSwitch() from the server but useSwitch is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/switch/dist/index.mjs", "useSwitch");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/switch/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/switch/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/switch/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/tooltip/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Tooltip",
    ()=>Tooltip,
    "useTooltip",
    ()=>useTooltip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Tooltip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Tooltip() from the server but Tooltip is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/tooltip/dist/index.mjs <module evaluation>", "Tooltip");
const useTooltip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useTooltip() from the server but useTooltip is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/tooltip/dist/index.mjs <module evaluation>", "useTooltip");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/tooltip/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Tooltip",
    ()=>Tooltip,
    "useTooltip",
    ()=>useTooltip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Tooltip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Tooltip() from the server but Tooltip is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/tooltip/dist/index.mjs", "Tooltip");
const useTooltip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useTooltip() from the server but useTooltip is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/tooltip/dist/index.mjs", "useTooltip");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/tooltip/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/tooltip/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/tooltip/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/user/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "User",
    ()=>User,
    "useUser",
    ()=>useUser
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const User = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call User() from the server but User is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/user/dist/index.mjs <module evaluation>", "User");
const useUser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useUser() from the server but useUser is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/user/dist/index.mjs <module evaluation>", "useUser");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/user/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "User",
    ()=>User,
    "useUser",
    ()=>useUser
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const User = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call User() from the server but User is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/user/dist/index.mjs", "User");
const useUser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useUser() from the server but useUser is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/user/dist/index.mjs", "useUser");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/user/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$user$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/user/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$user$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/user/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$user$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "CircularProgress",
    ()=>CircularProgress,
    "Progress",
    ()=>Progress,
    "useProgress",
    ()=>useProgress
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const CircularProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CircularProgress() from the server but CircularProgress is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs <module evaluation>", "CircularProgress");
const Progress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Progress() from the server but Progress is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs <module evaluation>", "Progress");
const useProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useProgress() from the server but useProgress is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs <module evaluation>", "useProgress");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "CircularProgress",
    ()=>CircularProgress,
    "Progress",
    ()=>Progress,
    "useProgress",
    ()=>useProgress
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const CircularProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CircularProgress() from the server but CircularProgress is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs", "CircularProgress");
const Progress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Progress() from the server but Progress is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs", "Progress");
const useProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useProgress() from the server but useProgress is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs", "useProgress");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$progress$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$progress$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/progress/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$progress$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Input",
    ()=>Input,
    "Textarea",
    ()=>Textarea,
    "useInput",
    ()=>useInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Input = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Input() from the server but Input is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs <module evaluation>", "Input");
const Textarea = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Textarea() from the server but Textarea is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs <module evaluation>", "Textarea");
const useInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useInput() from the server but useInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs <module evaluation>", "useInput");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Input",
    ()=>Input,
    "Textarea",
    ()=>Textarea,
    "useInput",
    ()=>useInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Input = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Input() from the server but Input is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs", "Input");
const Textarea = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Textarea() from the server but Textarea is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs", "Textarea");
const useInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useInput() from the server but useInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs", "useInput");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/input/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "FreeSoloPopover",
    ()=>FreeSoloPopover,
    "Popover",
    ()=>Popover,
    "PopoverContent",
    ()=>PopoverContent,
    "PopoverProvider",
    ()=>PopoverProvider,
    "PopoverTrigger",
    ()=>PopoverTrigger,
    "usePopover",
    ()=>usePopover,
    "usePopoverContext",
    ()=>usePopoverContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const FreeSoloPopover = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call FreeSoloPopover() from the server but FreeSoloPopover is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs <module evaluation>", "FreeSoloPopover");
const Popover = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Popover() from the server but Popover is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs <module evaluation>", "Popover");
const PopoverContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PopoverContent() from the server but PopoverContent is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs <module evaluation>", "PopoverContent");
const PopoverProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PopoverProvider() from the server but PopoverProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs <module evaluation>", "PopoverProvider");
const PopoverTrigger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PopoverTrigger() from the server but PopoverTrigger is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs <module evaluation>", "PopoverTrigger");
const usePopover = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call usePopover() from the server but usePopover is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs <module evaluation>", "usePopover");
const usePopoverContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call usePopoverContext() from the server but usePopoverContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs <module evaluation>", "usePopoverContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "FreeSoloPopover",
    ()=>FreeSoloPopover,
    "Popover",
    ()=>Popover,
    "PopoverContent",
    ()=>PopoverContent,
    "PopoverProvider",
    ()=>PopoverProvider,
    "PopoverTrigger",
    ()=>PopoverTrigger,
    "usePopover",
    ()=>usePopover,
    "usePopoverContext",
    ()=>usePopoverContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const FreeSoloPopover = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call FreeSoloPopover() from the server but FreeSoloPopover is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs", "FreeSoloPopover");
const Popover = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Popover() from the server but Popover is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs", "Popover");
const PopoverContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PopoverContent() from the server but PopoverContent is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs", "PopoverContent");
const PopoverProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PopoverProvider() from the server but PopoverProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs", "PopoverProvider");
const PopoverTrigger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PopoverTrigger() from the server but PopoverTrigger is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs", "PopoverTrigger");
const usePopover = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call usePopover() from the server but usePopover is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs", "usePopover");
const usePopoverContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call usePopoverContext() from the server but usePopoverContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs", "usePopoverContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/popover/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Dropdown",
    ()=>Dropdown,
    "DropdownItem",
    ()=>DropdownItem,
    "DropdownMenu",
    ()=>DropdownMenu,
    "DropdownSection",
    ()=>DropdownSection,
    "DropdownTrigger",
    ()=>DropdownTrigger,
    "useDropdown",
    ()=>useDropdown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Dropdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Dropdown() from the server but Dropdown is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs <module evaluation>", "Dropdown");
const DropdownItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DropdownItem() from the server but DropdownItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs <module evaluation>", "DropdownItem");
const DropdownMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DropdownMenu() from the server but DropdownMenu is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs <module evaluation>", "DropdownMenu");
const DropdownSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DropdownSection() from the server but DropdownSection is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs <module evaluation>", "DropdownSection");
const DropdownTrigger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DropdownTrigger() from the server but DropdownTrigger is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs <module evaluation>", "DropdownTrigger");
const useDropdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDropdown() from the server but useDropdown is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs <module evaluation>", "useDropdown");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Dropdown",
    ()=>Dropdown,
    "DropdownItem",
    ()=>DropdownItem,
    "DropdownMenu",
    ()=>DropdownMenu,
    "DropdownSection",
    ()=>DropdownSection,
    "DropdownTrigger",
    ()=>DropdownTrigger,
    "useDropdown",
    ()=>useDropdown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Dropdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Dropdown() from the server but Dropdown is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs", "Dropdown");
const DropdownItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DropdownItem() from the server but DropdownItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs", "DropdownItem");
const DropdownMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DropdownMenu() from the server but DropdownMenu is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs", "DropdownMenu");
const DropdownSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DropdownSection() from the server but DropdownSection is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs", "DropdownSection");
const DropdownTrigger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DropdownTrigger() from the server but DropdownTrigger is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs", "DropdownTrigger");
const useDropdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDropdown() from the server but useDropdown is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs", "useDropdown");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/dropdown/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/image/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Image",
    ()=>Image,
    "useImage",
    ()=>useImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Image = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Image() from the server but Image is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/image/dist/index.mjs <module evaluation>", "Image");
const useImage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useImage() from the server but useImage is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/image/dist/index.mjs <module evaluation>", "useImage");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/image/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Image",
    ()=>Image,
    "useImage",
    ()=>useImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Image = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Image() from the server but Image is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/image/dist/index.mjs", "Image");
const useImage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useImage() from the server but useImage is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/image/dist/index.mjs", "useImage");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/image/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$image$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/image/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$image$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/image/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$image$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Modal",
    ()=>Modal,
    "ModalBody",
    ()=>ModalBody,
    "ModalContent",
    ()=>ModalContent,
    "ModalFooter",
    ()=>ModalFooter,
    "ModalHeader",
    ()=>ModalHeader,
    "ModalProvider",
    ()=>ModalProvider,
    "useDisclosure",
    ()=>useDisclosure,
    "useDraggable",
    ()=>useDraggable,
    "useModal",
    ()=>useModal,
    "useModalContext",
    ()=>useModalContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Modal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Modal() from the server but Modal is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs <module evaluation>", "Modal");
const ModalBody = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ModalBody() from the server but ModalBody is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs <module evaluation>", "ModalBody");
const ModalContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ModalContent() from the server but ModalContent is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs <module evaluation>", "ModalContent");
const ModalFooter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ModalFooter() from the server but ModalFooter is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs <module evaluation>", "ModalFooter");
const ModalHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ModalHeader() from the server but ModalHeader is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs <module evaluation>", "ModalHeader");
const ModalProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ModalProvider() from the server but ModalProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs <module evaluation>", "ModalProvider");
const useDisclosure = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDisclosure() from the server but useDisclosure is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs <module evaluation>", "useDisclosure");
const useDraggable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDraggable() from the server but useDraggable is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs <module evaluation>", "useDraggable");
const useModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useModal() from the server but useModal is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs <module evaluation>", "useModal");
const useModalContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useModalContext() from the server but useModalContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs <module evaluation>", "useModalContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Modal",
    ()=>Modal,
    "ModalBody",
    ()=>ModalBody,
    "ModalContent",
    ()=>ModalContent,
    "ModalFooter",
    ()=>ModalFooter,
    "ModalHeader",
    ()=>ModalHeader,
    "ModalProvider",
    ()=>ModalProvider,
    "useDisclosure",
    ()=>useDisclosure,
    "useDraggable",
    ()=>useDraggable,
    "useModal",
    ()=>useModal,
    "useModalContext",
    ()=>useModalContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Modal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Modal() from the server but Modal is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs", "Modal");
const ModalBody = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ModalBody() from the server but ModalBody is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs", "ModalBody");
const ModalContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ModalContent() from the server but ModalContent is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs", "ModalContent");
const ModalFooter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ModalFooter() from the server but ModalFooter is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs", "ModalFooter");
const ModalHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ModalHeader() from the server but ModalHeader is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs", "ModalHeader");
const ModalProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ModalProvider() from the server but ModalProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs", "ModalProvider");
const useDisclosure = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDisclosure() from the server but useDisclosure is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs", "useDisclosure");
const useDraggable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDraggable() from the server but useDraggable is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs", "useDraggable");
const useModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useModal() from the server but useModal is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs", "useModal");
const useModalContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useModalContext() from the server but useModalContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs", "useModalContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/modal/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Navbar",
    ()=>Navbar,
    "NavbarBrand",
    ()=>NavbarBrand,
    "NavbarContent",
    ()=>NavbarContent,
    "NavbarItem",
    ()=>NavbarItem,
    "NavbarMenu",
    ()=>NavbarMenu,
    "NavbarMenuItem",
    ()=>NavbarMenuItem,
    "NavbarMenuToggle",
    ()=>NavbarMenuToggle,
    "NavbarProvider",
    ()=>NavbarProvider,
    "useNavbar",
    ()=>useNavbar,
    "useNavbarContext",
    ()=>useNavbarContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Navbar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Navbar() from the server but Navbar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs <module evaluation>", "Navbar");
const NavbarBrand = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarBrand() from the server but NavbarBrand is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs <module evaluation>", "NavbarBrand");
const NavbarContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarContent() from the server but NavbarContent is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs <module evaluation>", "NavbarContent");
const NavbarItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarItem() from the server but NavbarItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs <module evaluation>", "NavbarItem");
const NavbarMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarMenu() from the server but NavbarMenu is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs <module evaluation>", "NavbarMenu");
const NavbarMenuItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarMenuItem() from the server but NavbarMenuItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs <module evaluation>", "NavbarMenuItem");
const NavbarMenuToggle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarMenuToggle() from the server but NavbarMenuToggle is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs <module evaluation>", "NavbarMenuToggle");
const NavbarProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarProvider() from the server but NavbarProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs <module evaluation>", "NavbarProvider");
const useNavbar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useNavbar() from the server but useNavbar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs <module evaluation>", "useNavbar");
const useNavbarContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useNavbarContext() from the server but useNavbarContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs <module evaluation>", "useNavbarContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Navbar",
    ()=>Navbar,
    "NavbarBrand",
    ()=>NavbarBrand,
    "NavbarContent",
    ()=>NavbarContent,
    "NavbarItem",
    ()=>NavbarItem,
    "NavbarMenu",
    ()=>NavbarMenu,
    "NavbarMenuItem",
    ()=>NavbarMenuItem,
    "NavbarMenuToggle",
    ()=>NavbarMenuToggle,
    "NavbarProvider",
    ()=>NavbarProvider,
    "useNavbar",
    ()=>useNavbar,
    "useNavbarContext",
    ()=>useNavbarContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Navbar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Navbar() from the server but Navbar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs", "Navbar");
const NavbarBrand = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarBrand() from the server but NavbarBrand is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs", "NavbarBrand");
const NavbarContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarContent() from the server but NavbarContent is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs", "NavbarContent");
const NavbarItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarItem() from the server but NavbarItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs", "NavbarItem");
const NavbarMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarMenu() from the server but NavbarMenu is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs", "NavbarMenu");
const NavbarMenuItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarMenuItem() from the server but NavbarMenuItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs", "NavbarMenuItem");
const NavbarMenuToggle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarMenuToggle() from the server but NavbarMenuToggle is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs", "NavbarMenuToggle");
const NavbarProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarProvider() from the server but NavbarProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs", "NavbarProvider");
const useNavbar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useNavbar() from the server but useNavbar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs", "useNavbar");
const useNavbarContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useNavbarContext() from the server but useNavbarContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs", "useNavbarContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$navbar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$navbar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/navbar/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$navbar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Table",
    ()=>Table,
    "TableBody",
    ()=>TableBody,
    "TableCell",
    ()=>TableCell,
    "TableColumn",
    ()=>TableColumn,
    "TableHeader",
    ()=>TableHeader,
    "TableRow",
    ()=>TableRow,
    "getKeyValue",
    ()=>getKeyValue,
    "useTable",
    ()=>useTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Table = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Table() from the server but Table is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs <module evaluation>", "Table");
const TableBody = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TableBody() from the server but TableBody is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs <module evaluation>", "TableBody");
const TableCell = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TableCell() from the server but TableCell is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs <module evaluation>", "TableCell");
const TableColumn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TableColumn() from the server but TableColumn is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs <module evaluation>", "TableColumn");
const TableHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TableHeader() from the server but TableHeader is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs <module evaluation>", "TableHeader");
const TableRow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TableRow() from the server but TableRow is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs <module evaluation>", "TableRow");
const getKeyValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call getKeyValue() from the server but getKeyValue is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs <module evaluation>", "getKeyValue");
const useTable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useTable() from the server but useTable is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs <module evaluation>", "useTable");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Table",
    ()=>Table,
    "TableBody",
    ()=>TableBody,
    "TableCell",
    ()=>TableCell,
    "TableColumn",
    ()=>TableColumn,
    "TableHeader",
    ()=>TableHeader,
    "TableRow",
    ()=>TableRow,
    "getKeyValue",
    ()=>getKeyValue,
    "useTable",
    ()=>useTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Table = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Table() from the server but Table is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs", "Table");
const TableBody = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TableBody() from the server but TableBody is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs", "TableBody");
const TableCell = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TableCell() from the server but TableCell is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs", "TableCell");
const TableColumn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TableColumn() from the server but TableColumn is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs", "TableColumn");
const TableHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TableHeader() from the server but TableHeader is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs", "TableHeader");
const TableRow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TableRow() from the server but TableRow is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs", "TableRow");
const getKeyValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call getKeyValue() from the server but getKeyValue is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs", "getKeyValue");
const useTable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useTable() from the server but useTable is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs", "useTable");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$table$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$table$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/table/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$table$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/chunk-CH7FQ62Q.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/utils.ts
__turbopack_context__.s([
    "spacing",
    ()=>spacing
]);
var spacing = {
    px: "1px",
    0: "0px",
    0.5: "0.125rem",
    1: "0.25rem",
    1.5: "0.375rem",
    2: "0.5rem",
    2.5: "0.625rem",
    3: "0.75rem",
    3.5: "0.875rem",
    4: "1rem",
    5: "1.25rem",
    6: "1.5rem",
    7: "1.75rem",
    8: "2rem",
    9: "2.25rem",
    10: "2.5rem",
    11: "2.75rem",
    12: "3rem",
    14: "3.5rem",
    16: "4rem",
    20: "5rem",
    24: "6rem",
    28: "7rem",
    32: "8rem",
    36: "9rem",
    40: "10rem",
    44: "11rem",
    48: "12rem",
    52: "13rem",
    56: "14rem",
    60: "15rem",
    64: "16rem",
    72: "18rem",
    80: "20rem",
    96: "24rem"
};
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/chunk-BRFD4NXM.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getMargin",
    ()=>getMargin,
    "useSpacer",
    ()=>useSpacer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$chunk$2d$CH7FQ62Q$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/chunk-CH7FQ62Q.mjs [app-rsc] (ecmascript)");
// src/use-spacer.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/system-rsc/dist/chunk-YFAKJTDR.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$chunk$2d$SBOMX3YT$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/theme/dist/chunk-SBOMX3YT.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$shared$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/shared-utils/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
;
;
;
;
var getMargin = (value)=>{
    var _a;
    return (_a = __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$chunk$2d$CH7FQ62Q$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["spacing"][value]) != null ? _a : value;
};
function useSpacer(originalProps) {
    const [props, variantProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mapPropsVariants"])(originalProps, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$chunk$2d$SBOMX3YT$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["spacer"].variantKeys);
    const { as, className, x = 1, y = 1, ...otherProps } = props;
    const Component = as || "span";
    const styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$chunk$2d$SBOMX3YT$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["spacer"])({
            ...variantProps,
            className
        }), [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$shared$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["objectToDeps"])(variantProps),
        className
    ]);
    const marginLeft = getMargin(x);
    const marginTop = getMargin(y);
    const getSpacerProps = (props2 = {})=>({
            ...props2,
            ...otherProps,
            "aria-hidden": (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$shared$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["dataAttr"])(true),
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$shared$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["clsx"])(styles, props2.className),
            style: {
                ...props2.style,
                ...otherProps.style,
                marginLeft,
                marginTop
            }
        });
    return {
        Component,
        getSpacerProps
    };
}
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/chunk-AWMMSYR4.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "spacer_default",
    ()=>spacer_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$chunk$2d$BRFD4NXM$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/chunk-BRFD4NXM.mjs [app-rsc] (ecmascript)");
// src/spacer.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/system-rsc/dist/chunk-YFAKJTDR.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-runtime.js [app-rsc] (ecmascript)");
;
;
;
var Spacer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])((props, ref)=>{
    const { Component, getSpacerProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$chunk$2d$BRFD4NXM$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useSpacer"])({
        ...props
    });
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref,
        ...getSpacerProps()
    });
});
Spacer.displayName = "HeroUI.Spacer";
var spacer_default = Spacer;
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/index.mjs [app-rsc] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$chunk$2d$AWMMSYR4$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/chunk-AWMMSYR4.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$chunk$2d$BRFD4NXM$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/chunk-BRFD4NXM.mjs [app-rsc] (ecmascript)");
;
;
;
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Spacer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$chunk$2d$AWMMSYR4$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["spacer_default"],
    "useSpacer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$chunk$2d$BRFD4NXM$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useSpacer"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$chunk$2d$AWMMSYR4$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/chunk-AWMMSYR4.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$spacer$2f$dist$2f$chunk$2d$BRFD4NXM$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/spacer/dist/chunk-BRFD4NXM.mjs [app-rsc] (ecmascript)");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/react-rsc-utils/dist/chunk-RFWDHYLZ.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/dom-props.ts
__turbopack_context__.s([
    "DOMEventNames",
    ()=>DOMEventNames,
    "DOMPropNames",
    ()=>DOMPropNames
]);
var DOMPropNames = /* @__PURE__ */ new Set([
    "id",
    "type",
    "style",
    "title",
    "role",
    "tabIndex",
    "htmlFor",
    "width",
    "height",
    "abbr",
    "accept",
    "acceptCharset",
    "accessKey",
    "action",
    "allowFullScreen",
    "allowTransparency",
    "alt",
    "async",
    "autoComplete",
    "autoFocus",
    "autoPlay",
    "cellPadding",
    "cellSpacing",
    "challenge",
    "charset",
    "checked",
    "cite",
    "class",
    "className",
    "cols",
    "colSpan",
    "command",
    "content",
    "contentEditable",
    "contextMenu",
    "controls",
    "coords",
    "crossOrigin",
    "data",
    "dateTime",
    "default",
    "defer",
    "dir",
    "disabled",
    "download",
    "draggable",
    "dropzone",
    "encType",
    "enterKeyHint",
    "for",
    "form",
    "formAction",
    "formEncType",
    "formMethod",
    "formNoValidate",
    "formTarget",
    "frameBorder",
    "headers",
    "hidden",
    "high",
    "href",
    "hrefLang",
    "httpEquiv",
    "icon",
    "inputMode",
    "isMap",
    "itemId",
    "itemProp",
    "itemRef",
    "itemScope",
    "itemType",
    "kind",
    "label",
    "lang",
    "list",
    "loop",
    "manifest",
    "max",
    "maxLength",
    "media",
    "mediaGroup",
    "method",
    "min",
    "minLength",
    "multiple",
    "muted",
    "name",
    "noValidate",
    "open",
    "optimum",
    "pattern",
    "ping",
    "placeholder",
    "poster",
    "preload",
    "radioGroup",
    "referrerPolicy",
    "readOnly",
    "rel",
    "required",
    "rows",
    "rowSpan",
    "sandbox",
    "scope",
    "scoped",
    "scrolling",
    "seamless",
    "selected",
    "shape",
    "size",
    "sizes",
    "slot",
    "sortable",
    "span",
    "spellCheck",
    "src",
    "srcDoc",
    "srcSet",
    "start",
    "step",
    "target",
    "translate",
    "typeMustMatch",
    "useMap",
    "value",
    "wmode",
    "wrap"
]);
var DOMEventNames = /* @__PURE__ */ new Set([
    "onCopy",
    "onCut",
    "onPaste",
    "onLoad",
    "onError",
    "onWheel",
    "onScroll",
    "onCompositionEnd",
    "onCompositionStart",
    "onCompositionUpdate",
    "onKeyDown",
    "onKeyPress",
    "onKeyUp",
    "onFocus",
    "onBlur",
    "onChange",
    "onInput",
    "onSubmit",
    "onClick",
    "onContextMenu",
    "onDoubleClick",
    "onDrag",
    "onDragEnd",
    "onDragEnter",
    "onDragExit",
    "onDragLeave",
    "onDragOver",
    "onDragStart",
    "onDrop",
    "onMouseDown",
    "onMouseEnter",
    "onMouseLeave",
    "onMouseMove",
    "onMouseOut",
    "onMouseOver",
    "onMouseUp",
    "onPointerDown",
    "onPointerEnter",
    "onPointerLeave",
    "onPointerUp",
    "onSelect",
    "onTouchCancel",
    "onTouchEnd",
    "onTouchMove",
    "onTouchStart",
    "onAnimationStart",
    "onAnimationEnd",
    "onAnimationIteration",
    "onTransitionEnd"
]);
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/react-rsc-utils/dist/chunk-RJKRL3AU.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "filterDOMProps",
    ()=>filterDOMProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$react$2d$rsc$2d$utils$2f$dist$2f$chunk$2d$RFWDHYLZ$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/react-rsc-utils/dist/chunk-RFWDHYLZ.mjs [app-rsc] (ecmascript)");
;
// src/filter-dom-props.ts
var propRe = /^(data-.*)$/;
var ariaRe = /^(aria-.*)$/;
var funcRe = /^(on[A-Z].*)$/;
function filterDOMProps(props, opts = {}) {
    let { labelable = true, enabled = true, propNames, omitPropNames, omitEventNames, omitDataProps, omitEventProps } = opts;
    let filteredProps = {};
    if (!enabled) {
        return props;
    }
    for(const prop in props){
        if (omitPropNames == null ? void 0 : omitPropNames.has(prop)) {
            continue;
        }
        if ((omitEventNames == null ? void 0 : omitEventNames.has(prop)) && funcRe.test(prop)) {
            continue;
        }
        if (funcRe.test(prop) && !__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$react$2d$rsc$2d$utils$2f$dist$2f$chunk$2d$RFWDHYLZ$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["DOMEventNames"].has(prop)) {
            continue;
        }
        if (omitDataProps && propRe.test(prop)) {
            continue;
        }
        if (omitEventProps && funcRe.test(prop)) {
            continue;
        }
        if (Object.prototype.hasOwnProperty.call(props, prop) && (__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$react$2d$rsc$2d$utils$2f$dist$2f$chunk$2d$RFWDHYLZ$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["DOMPropNames"].has(prop) || labelable && ariaRe.test(prop) || (propNames == null ? void 0 : propNames.has(prop)) || propRe.test(prop)) || funcRe.test(prop)) {
            filteredProps[prop] = props[prop];
        }
    }
    return filteredProps;
}
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/chunk-D2EG5U3Q.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/use-separator.ts
__turbopack_context__.s([
    "useSeparator",
    ()=>useSeparator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$react$2d$rsc$2d$utils$2f$dist$2f$chunk$2d$RJKRL3AU$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/react-rsc-utils/dist/chunk-RJKRL3AU.mjs [app-rsc] (ecmascript)");
;
function useSeparator(props) {
    let domProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$react$2d$rsc$2d$utils$2f$dist$2f$chunk$2d$RJKRL3AU$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["filterDOMProps"])(props, {
        enabled: typeof props.elementType === "string"
    });
    let ariaOrientation;
    if (props.orientation === "vertical") {
        ariaOrientation = "vertical";
    }
    if (props.elementType !== "hr") {
        return {
            separatorProps: {
                ...domProps,
                role: "separator",
                "aria-orientation": ariaOrientation
            }
        };
    }
    return {
        separatorProps: domProps
    };
}
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/chunk-TS7K35D7.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDivider",
    ()=>useDivider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$chunk$2d$D2EG5U3Q$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/chunk-D2EG5U3Q.mjs [app-rsc] (ecmascript)");
// src/use-divider.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$chunk$2d$O5X46N53$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/theme/dist/chunk-O5X46N53.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
;
;
function useDivider(props) {
    const { as, className, orientation, ...otherProps } = props;
    let Component = as || "hr";
    if (Component === "hr" && orientation === "vertical") {
        Component = "div";
    }
    const { separatorProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$chunk$2d$D2EG5U3Q$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useSeparator"])({
        elementType: typeof Component === "string" ? Component : "hr",
        orientation
    });
    const styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$chunk$2d$O5X46N53$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["divider"])({
            orientation,
            className
        }), [
        orientation,
        className
    ]);
    const getDividerProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCallback"])((props2 = {})=>({
            className: styles,
            role: "separator",
            "data-orientation": orientation,
            ...separatorProps,
            ...otherProps,
            ...props2
        }), [
        styles,
        orientation,
        separatorProps,
        otherProps
    ]);
    return {
        Component,
        getDividerProps
    };
}
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/chunk-IHO36JMK.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "divider_default",
    ()=>divider_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$chunk$2d$TS7K35D7$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/chunk-TS7K35D7.mjs [app-rsc] (ecmascript)");
// src/divider.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/system-rsc/dist/chunk-YFAKJTDR.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-runtime.js [app-rsc] (ecmascript)");
;
;
;
var Divider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])((props, ref)=>{
    const { Component, getDividerProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$chunk$2d$TS7K35D7$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useDivider"])({
        ...props
    });
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref,
        ...getDividerProps()
    });
});
Divider.displayName = "HeroUI.Divider";
var divider_default = Divider;
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/index.mjs [app-rsc] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$chunk$2d$IHO36JMK$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/chunk-IHO36JMK.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$chunk$2d$TS7K35D7$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/chunk-TS7K35D7.mjs [app-rsc] (ecmascript)");
;
;
;
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Divider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$chunk$2d$IHO36JMK$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["divider_default"],
    "useDivider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$chunk$2d$TS7K35D7$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useDivider"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$chunk$2d$IHO36JMK$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/chunk-IHO36JMK.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$divider$2f$dist$2f$chunk$2d$TS7K35D7$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/divider/dist/chunk-TS7K35D7.mjs [app-rsc] (ecmascript)");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/chunk-33JVVCIB.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/use-kbd.ts
__turbopack_context__.s([
    "useKbd",
    ()=>useKbd
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/system-rsc/dist/chunk-YFAKJTDR.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$chunk$2d$DJLZADVO$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/theme/dist/chunk-DJLZADVO.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$shared$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/shared-utils/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
;
;
;
function useKbd(originalProps) {
    const [props, variantProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mapPropsVariants"])(originalProps, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$chunk$2d$DJLZADVO$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["kbd"].variantKeys);
    const { as, children, className, keys, title, classNames, ...otherProps } = props;
    const Component = as || "kbd";
    const slots = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$theme$2f$dist$2f$chunk$2d$DJLZADVO$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["kbd"])({
            ...variantProps
        }), [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$shared$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["objectToDeps"])(variantProps)
    ]);
    const baseStyles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$shared$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["clsx"])(classNames == null ? void 0 : classNames.base, className);
    const keysToRender = typeof keys === "string" ? [
        keys
    ] : Array.isArray(keys) ? keys : [];
    const getKbdProps = (props2 = {})=>({
            ...otherProps,
            ...props2,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$shared$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["clsx"])(slots.base({
                class: (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$shared$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["clsx"])(baseStyles, props2.className)
            }))
        });
    return {
        Component,
        slots,
        classNames,
        title,
        children,
        keysToRender,
        getKbdProps
    };
}
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/chunk-ZWTE5ZFD.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/utils.ts
__turbopack_context__.s([
    "kbdKeysLabelMap",
    ()=>kbdKeysLabelMap,
    "kbdKeysMap",
    ()=>kbdKeysMap
]);
var kbdKeysMap = {
    command: "\u2318",
    shift: "\u21E7",
    ctrl: "\u2303",
    option: "\u2325",
    enter: "\u21B5",
    delete: "\u232B",
    escape: "\u238B",
    tab: "\u21E5",
    capslock: "\u21EA",
    up: "\u2191",
    right: "\u2192",
    down: "\u2193",
    left: "\u2190",
    pageup: "\u21DE",
    pagedown: "\u21DF",
    home: "\u2196",
    end: "\u2198",
    help: "?",
    space: "\u2423",
    fn: "Fn",
    win: "\u2318",
    alt: "\u2325"
};
var kbdKeysLabelMap = {
    command: "Command",
    shift: "Shift",
    ctrl: "Control",
    option: "Option",
    enter: "Enter",
    delete: "Delete",
    escape: "Escape",
    tab: "Tab",
    capslock: "Caps Lock",
    up: "Up",
    right: "Right",
    down: "Down",
    left: "Left",
    pageup: "Page Up",
    pagedown: "Page Down",
    home: "Home",
    end: "End",
    help: "Help",
    space: "Space",
    fn: "Fn",
    win: "Win",
    alt: "Alt"
};
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/chunk-EZX35FZF.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "kbd_default",
    ()=>kbd_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$chunk$2d$33JVVCIB$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/chunk-33JVVCIB.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$chunk$2d$ZWTE5ZFD$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/chunk-ZWTE5ZFD.mjs [app-rsc] (ecmascript)");
// src/kbd.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/system-rsc/dist/chunk-YFAKJTDR.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-runtime.js [app-rsc] (ecmascript)");
;
;
;
;
;
var Kbd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$system$2d$rsc$2f$dist$2f$chunk$2d$YFAKJTDR$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])((props, ref)=>{
    const { Component, children, slots, classNames, keysToRender, getKbdProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$chunk$2d$33JVVCIB$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useKbd"])({
        ...props
    });
    const keysContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        return keysToRender.map((key)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])("abbr", {
                className: slots.abbr({
                    class: classNames == null ? void 0 : classNames.abbr
                }),
                title: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$chunk$2d$ZWTE5ZFD$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["kbdKeysLabelMap"][key],
                children: __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$chunk$2d$ZWTE5ZFD$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["kbdKeysMap"][key]
            }, key));
    }, [
        keysToRender
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxs"])(Component, {
        ref,
        ...getKbdProps(),
        children: [
            keysContent,
            children && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsx"])("span", {
                className: slots.content({
                    class: classNames == null ? void 0 : classNames.content
                }),
                children
            })
        ]
    });
});
Kbd.displayName = "HeroUI.Kbd";
var kbd_default = Kbd;
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/index.mjs [app-rsc] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$chunk$2d$EZX35FZF$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/chunk-EZX35FZF.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$chunk$2d$33JVVCIB$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/chunk-33JVVCIB.mjs [app-rsc] (ecmascript)");
;
;
;
;
}),
"[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Kbd",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$chunk$2d$EZX35FZF$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["kbd_default"],
    "useKbd",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$chunk$2d$33JVVCIB$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useKbd"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$chunk$2d$EZX35FZF$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/chunk-EZX35FZF.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$kbd$2f$dist$2f$chunk$2d$33JVVCIB$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/kbd/dist/chunk-33JVVCIB.mjs [app-rsc] (ecmascript)");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Tab",
    ()=>Tab,
    "Tabs",
    ()=>Tabs,
    "useTabs",
    ()=>useTabs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Tab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Tab() from the server but Tab is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs <module evaluation>", "Tab");
const Tabs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Tabs() from the server but Tabs is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs <module evaluation>", "Tabs");
const useTabs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useTabs() from the server but useTabs is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs <module evaluation>", "useTabs");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Tab",
    ()=>Tab,
    "Tabs",
    ()=>Tabs,
    "useTabs",
    ()=>useTabs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Tab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Tab() from the server but Tab is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs", "Tab");
const Tabs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Tabs() from the server but Tabs is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs", "Tabs");
const useTabs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useTabs() from the server but useTabs is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs", "useTabs");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/tabs/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/skeleton/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Skeleton",
    ()=>Skeleton,
    "useSkeleton",
    ()=>useSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Skeleton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Skeleton() from the server but Skeleton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/skeleton/dist/index.mjs <module evaluation>", "Skeleton");
const useSkeleton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSkeleton() from the server but useSkeleton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/skeleton/dist/index.mjs <module evaluation>", "useSkeleton");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/skeleton/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Skeleton",
    ()=>Skeleton,
    "useSkeleton",
    ()=>useSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Skeleton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Skeleton() from the server but Skeleton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/skeleton/dist/index.mjs", "Skeleton");
const useSkeleton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSkeleton() from the server but useSkeleton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/skeleton/dist/index.mjs", "useSkeleton");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/skeleton/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$skeleton$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/skeleton/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$skeleton$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/skeleton/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$skeleton$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/scroll-shadow/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "ScrollShadow",
    ()=>ScrollShadow,
    "useScrollShadow",
    ()=>useScrollShadow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const ScrollShadow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ScrollShadow() from the server but ScrollShadow is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/scroll-shadow/dist/index.mjs <module evaluation>", "ScrollShadow");
const useScrollShadow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useScrollShadow() from the server but useScrollShadow is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/scroll-shadow/dist/index.mjs <module evaluation>", "useScrollShadow");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/scroll-shadow/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "ScrollShadow",
    ()=>ScrollShadow,
    "useScrollShadow",
    ()=>useScrollShadow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const ScrollShadow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ScrollShadow() from the server but ScrollShadow is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/scroll-shadow/dist/index.mjs", "ScrollShadow");
const useScrollShadow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useScrollShadow() from the server but useScrollShadow is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/scroll-shadow/dist/index.mjs", "useScrollShadow");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/scroll-shadow/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$scroll$2d$shadow$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/scroll-shadow/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$scroll$2d$shadow$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/scroll-shadow/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$scroll$2d$shadow$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "HiddenSelect",
    ()=>HiddenSelect,
    "Select",
    ()=>Select,
    "SelectItem",
    ()=>SelectItem,
    "SelectSection",
    ()=>SelectSection,
    "useSelect",
    ()=>useSelect
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const HiddenSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call HiddenSelect() from the server but HiddenSelect is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs <module evaluation>", "HiddenSelect");
const Select = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Select() from the server but Select is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs <module evaluation>", "Select");
const SelectItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call SelectItem() from the server but SelectItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs <module evaluation>", "SelectItem");
const SelectSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call SelectSection() from the server but SelectSection is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs <module evaluation>", "SelectSection");
const useSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSelect() from the server but useSelect is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs <module evaluation>", "useSelect");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "HiddenSelect",
    ()=>HiddenSelect,
    "Select",
    ()=>Select,
    "SelectItem",
    ()=>SelectItem,
    "SelectSection",
    ()=>SelectSection,
    "useSelect",
    ()=>useSelect
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const HiddenSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call HiddenSelect() from the server but HiddenSelect is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs", "HiddenSelect");
const Select = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Select() from the server but Select is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs", "Select");
const SelectItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call SelectItem() from the server but SelectItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs", "SelectItem");
const SelectSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call SelectSection() from the server but SelectSection is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs", "SelectSection");
const useSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSelect() from the server but useSelect is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs", "useSelect");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/select/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Listbox",
    ()=>Listbox,
    "ListboxItem",
    ()=>ListboxItem,
    "ListboxSection",
    ()=>ListboxSection,
    "useListbox",
    ()=>useListbox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Listbox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Listbox() from the server but Listbox is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs <module evaluation>", "Listbox");
const ListboxItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ListboxItem() from the server but ListboxItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs <module evaluation>", "ListboxItem");
const ListboxSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ListboxSection() from the server but ListboxSection is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs <module evaluation>", "ListboxSection");
const useListbox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useListbox() from the server but useListbox is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs <module evaluation>", "useListbox");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Listbox",
    ()=>Listbox,
    "ListboxItem",
    ()=>ListboxItem,
    "ListboxSection",
    ()=>ListboxSection,
    "useListbox",
    ()=>useListbox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Listbox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Listbox() from the server but Listbox is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs", "Listbox");
const ListboxItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ListboxItem() from the server but ListboxItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs", "ListboxItem");
const ListboxSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ListboxSection() from the server but ListboxSection is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs", "ListboxSection");
const useListbox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useListbox() from the server but useListbox is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs", "useListbox");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$listbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$listbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/listbox/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$listbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Menu",
    ()=>Menu,
    "MenuItem",
    ()=>MenuItem,
    "MenuSection",
    ()=>MenuSection,
    "useMenu",
    ()=>useMenu
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Menu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Menu() from the server but Menu is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs <module evaluation>", "Menu");
const MenuItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call MenuItem() from the server but MenuItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs <module evaluation>", "MenuItem");
const MenuSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call MenuSection() from the server but MenuSection is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs <module evaluation>", "MenuSection");
const useMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useMenu() from the server but useMenu is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs <module evaluation>", "useMenu");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Menu",
    ()=>Menu,
    "MenuItem",
    ()=>MenuItem,
    "MenuSection",
    ()=>MenuSection,
    "useMenu",
    ()=>useMenu
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Menu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Menu() from the server but Menu is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs", "Menu");
const MenuItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call MenuItem() from the server but MenuItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs", "MenuItem");
const MenuSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call MenuSection() from the server but MenuSection is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs", "MenuSection");
const useMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useMenu() from the server but useMenu is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs", "useMenu");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/menu/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/ripple/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Ripple",
    ()=>Ripple,
    "useRipple",
    ()=>useRipple
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Ripple = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Ripple() from the server but Ripple is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/ripple/dist/index.mjs <module evaluation>", "Ripple");
const useRipple = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useRipple() from the server but useRipple is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/ripple/dist/index.mjs <module evaluation>", "useRipple");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/ripple/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Ripple",
    ()=>Ripple,
    "useRipple",
    ()=>useRipple
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Ripple = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Ripple() from the server but Ripple is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/ripple/dist/index.mjs", "Ripple");
const useRipple = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useRipple() from the server but useRipple is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/ripple/dist/index.mjs", "useRipple");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/ripple/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$ripple$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/ripple/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$ripple$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/ripple/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$ripple$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/slider/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Slider",
    ()=>Slider,
    "useSlider",
    ()=>useSlider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Slider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Slider() from the server but Slider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/slider/dist/index.mjs <module evaluation>", "Slider");
const useSlider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSlider() from the server but useSlider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/slider/dist/index.mjs <module evaluation>", "useSlider");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/slider/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Slider",
    ()=>Slider,
    "useSlider",
    ()=>useSlider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Slider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Slider() from the server but Slider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/slider/dist/index.mjs", "Slider");
const useSlider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSlider() from the server but useSlider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/slider/dist/index.mjs", "useSlider");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/slider/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$slider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/slider/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$slider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/slider/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$slider$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "BreadcrumbItem",
    ()=>BreadcrumbItem,
    "Breadcrumbs",
    ()=>Breadcrumbs,
    "useBreadcrumbItem",
    ()=>useBreadcrumbItem,
    "useBreadcrumbs",
    ()=>useBreadcrumbs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const BreadcrumbItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call BreadcrumbItem() from the server but BreadcrumbItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs <module evaluation>", "BreadcrumbItem");
const Breadcrumbs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Breadcrumbs() from the server but Breadcrumbs is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs <module evaluation>", "Breadcrumbs");
const useBreadcrumbItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useBreadcrumbItem() from the server but useBreadcrumbItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs <module evaluation>", "useBreadcrumbItem");
const useBreadcrumbs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useBreadcrumbs() from the server but useBreadcrumbs is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs <module evaluation>", "useBreadcrumbs");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "BreadcrumbItem",
    ()=>BreadcrumbItem,
    "Breadcrumbs",
    ()=>Breadcrumbs,
    "useBreadcrumbItem",
    ()=>useBreadcrumbItem,
    "useBreadcrumbs",
    ()=>useBreadcrumbs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const BreadcrumbItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call BreadcrumbItem() from the server but BreadcrumbItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs", "BreadcrumbItem");
const Breadcrumbs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Breadcrumbs() from the server but Breadcrumbs is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs", "Breadcrumbs");
const useBreadcrumbItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useBreadcrumbItem() from the server but useBreadcrumbItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs", "useBreadcrumbItem");
const useBreadcrumbs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useBreadcrumbs() from the server but useBreadcrumbs is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs", "useBreadcrumbs");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$breadcrumbs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$breadcrumbs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/breadcrumbs/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$breadcrumbs$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Autocomplete",
    ()=>Autocomplete,
    "AutocompleteItem",
    ()=>AutocompleteItem,
    "AutocompleteSection",
    ()=>AutocompleteSection,
    "useAutocomplete",
    ()=>useAutocomplete
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Autocomplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Autocomplete() from the server but Autocomplete is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs <module evaluation>", "Autocomplete");
const AutocompleteItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AutocompleteItem() from the server but AutocompleteItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs <module evaluation>", "AutocompleteItem");
const AutocompleteSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AutocompleteSection() from the server but AutocompleteSection is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs <module evaluation>", "AutocompleteSection");
const useAutocomplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAutocomplete() from the server but useAutocomplete is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs <module evaluation>", "useAutocomplete");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Autocomplete",
    ()=>Autocomplete,
    "AutocompleteItem",
    ()=>AutocompleteItem,
    "AutocompleteSection",
    ()=>AutocompleteSection,
    "useAutocomplete",
    ()=>useAutocomplete
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Autocomplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Autocomplete() from the server but Autocomplete is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs", "Autocomplete");
const AutocompleteItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AutocompleteItem() from the server but AutocompleteItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs", "AutocompleteItem");
const AutocompleteSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call AutocompleteSection() from the server but AutocompleteSection is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs", "AutocompleteSection");
const useAutocomplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAutocomplete() from the server but useAutocomplete is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs", "useAutocomplete");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$autocomplete$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$autocomplete$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/autocomplete/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$autocomplete$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Calendar",
    ()=>Calendar,
    "CalendarProvider",
    ()=>CalendarProvider,
    "RangeCalendar",
    ()=>RangeCalendar,
    "useCalendar",
    ()=>useCalendar,
    "useCalendarContext",
    ()=>useCalendarContext,
    "useRangeCalendar",
    ()=>useRangeCalendar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Calendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Calendar() from the server but Calendar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs <module evaluation>", "Calendar");
const CalendarProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CalendarProvider() from the server but CalendarProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs <module evaluation>", "CalendarProvider");
const RangeCalendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call RangeCalendar() from the server but RangeCalendar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs <module evaluation>", "RangeCalendar");
const useCalendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCalendar() from the server but useCalendar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs <module evaluation>", "useCalendar");
const useCalendarContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCalendarContext() from the server but useCalendarContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs <module evaluation>", "useCalendarContext");
const useRangeCalendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useRangeCalendar() from the server but useRangeCalendar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs <module evaluation>", "useRangeCalendar");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Calendar",
    ()=>Calendar,
    "CalendarProvider",
    ()=>CalendarProvider,
    "RangeCalendar",
    ()=>RangeCalendar,
    "useCalendar",
    ()=>useCalendar,
    "useCalendarContext",
    ()=>useCalendarContext,
    "useRangeCalendar",
    ()=>useRangeCalendar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Calendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Calendar() from the server but Calendar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs", "Calendar");
const CalendarProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CalendarProvider() from the server but CalendarProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs", "CalendarProvider");
const RangeCalendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call RangeCalendar() from the server but RangeCalendar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs", "RangeCalendar");
const useCalendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCalendar() from the server but useCalendar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs", "useCalendar");
const useCalendarContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useCalendarContext() from the server but useCalendarContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs", "useCalendarContext");
const useRangeCalendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useRangeCalendar() from the server but useRangeCalendar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs", "useRangeCalendar");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$calendar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$calendar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/calendar/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$calendar$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "DateInput",
    ()=>DateInput,
    "DateInputField",
    ()=>DateInputField,
    "DateInputGroup",
    ()=>DateInputGroup,
    "DateInputSegment",
    ()=>DateInputSegment,
    "TimeInput",
    ()=>TimeInput,
    "useDateInput",
    ()=>useDateInput,
    "useTimeInput",
    ()=>useTimeInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const DateInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateInput() from the server but DateInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs <module evaluation>", "DateInput");
const DateInputField = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateInputField() from the server but DateInputField is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs <module evaluation>", "DateInputField");
const DateInputGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateInputGroup() from the server but DateInputGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs <module evaluation>", "DateInputGroup");
const DateInputSegment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateInputSegment() from the server but DateInputSegment is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs <module evaluation>", "DateInputSegment");
const TimeInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TimeInput() from the server but TimeInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs <module evaluation>", "TimeInput");
const useDateInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDateInput() from the server but useDateInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs <module evaluation>", "useDateInput");
const useTimeInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useTimeInput() from the server but useTimeInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs <module evaluation>", "useTimeInput");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "DateInput",
    ()=>DateInput,
    "DateInputField",
    ()=>DateInputField,
    "DateInputGroup",
    ()=>DateInputGroup,
    "DateInputSegment",
    ()=>DateInputSegment,
    "TimeInput",
    ()=>TimeInput,
    "useDateInput",
    ()=>useDateInput,
    "useTimeInput",
    ()=>useTimeInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const DateInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateInput() from the server but DateInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs", "DateInput");
const DateInputField = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateInputField() from the server but DateInputField is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs", "DateInputField");
const DateInputGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateInputGroup() from the server but DateInputGroup is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs", "DateInputGroup");
const DateInputSegment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateInputSegment() from the server but DateInputSegment is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs", "DateInputSegment");
const TimeInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call TimeInput() from the server but TimeInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs", "TimeInput");
const useDateInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDateInput() from the server but useDateInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs", "useDateInput");
const useTimeInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useTimeInput() from the server but useTimeInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs", "useTimeInput");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$date$2d$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$date$2d$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/date-input/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$date$2d$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "DatePicker",
    ()=>DatePicker,
    "DateRangePicker",
    ()=>DateRangePicker,
    "DateRangePickerField",
    ()=>DateRangePickerField,
    "useDatePicker",
    ()=>useDatePicker,
    "useDateRangePicker",
    ()=>useDateRangePicker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const DatePicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DatePicker() from the server but DatePicker is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs <module evaluation>", "DatePicker");
const DateRangePicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateRangePicker() from the server but DateRangePicker is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs <module evaluation>", "DateRangePicker");
const DateRangePickerField = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateRangePickerField() from the server but DateRangePickerField is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs <module evaluation>", "DateRangePickerField");
const useDatePicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDatePicker() from the server but useDatePicker is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs <module evaluation>", "useDatePicker");
const useDateRangePicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDateRangePicker() from the server but useDateRangePicker is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs <module evaluation>", "useDateRangePicker");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "DatePicker",
    ()=>DatePicker,
    "DateRangePicker",
    ()=>DateRangePicker,
    "DateRangePickerField",
    ()=>DateRangePickerField,
    "useDatePicker",
    ()=>useDatePicker,
    "useDateRangePicker",
    ()=>useDateRangePicker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const DatePicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DatePicker() from the server but DatePicker is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs", "DatePicker");
const DateRangePicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateRangePicker() from the server but DateRangePicker is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs", "DateRangePicker");
const DateRangePickerField = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DateRangePickerField() from the server but DateRangePickerField is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs", "DateRangePickerField");
const useDatePicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDatePicker() from the server but useDatePicker is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs", "useDatePicker");
const useDateRangePicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDateRangePicker() from the server but useDateRangePicker is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs", "useDateRangePicker");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$date$2d$picker$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$date$2d$picker$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/date-picker/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$date$2d$picker$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Form",
    ()=>Form,
    "FormContext",
    ()=>FormContext,
    "useSlottedContext",
    ()=>useSlottedContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Form = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Form() from the server but Form is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs <module evaluation>", "Form");
const FormContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call FormContext() from the server but FormContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs <module evaluation>", "FormContext");
const useSlottedContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSlottedContext() from the server but useSlottedContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs <module evaluation>", "useSlottedContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Form",
    ()=>Form,
    "FormContext",
    ()=>FormContext,
    "useSlottedContext",
    ()=>useSlottedContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Form = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Form() from the server but Form is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs", "Form");
const FormContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call FormContext() from the server but FormContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs", "FormContext");
const useSlottedContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useSlottedContext() from the server but useSlottedContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs", "useSlottedContext");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$form$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$form$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/form/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$form$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/alert/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Alert",
    ()=>Alert,
    "useAlert",
    ()=>useAlert
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Alert = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Alert() from the server but Alert is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/alert/dist/index.mjs <module evaluation>", "Alert");
const useAlert = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAlert() from the server but useAlert is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/alert/dist/index.mjs <module evaluation>", "useAlert");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/alert/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Alert",
    ()=>Alert,
    "useAlert",
    ()=>useAlert
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Alert = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Alert() from the server but Alert is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/alert/dist/index.mjs", "Alert");
const useAlert = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useAlert() from the server but useAlert is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/alert/dist/index.mjs", "useAlert");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/alert/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$alert$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/alert/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$alert$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/alert/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$alert$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Drawer",
    ()=>Drawer,
    "DrawerBody",
    ()=>DrawerBody,
    "DrawerContent",
    ()=>DrawerContent,
    "DrawerFooter",
    ()=>DrawerFooter,
    "DrawerHeader",
    ()=>DrawerHeader,
    "useDrawer",
    ()=>useDrawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Drawer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Drawer() from the server but Drawer is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs <module evaluation>", "Drawer");
const DrawerBody = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DrawerBody() from the server but DrawerBody is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs <module evaluation>", "DrawerBody");
const DrawerContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DrawerContent() from the server but DrawerContent is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs <module evaluation>", "DrawerContent");
const DrawerFooter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DrawerFooter() from the server but DrawerFooter is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs <module evaluation>", "DrawerFooter");
const DrawerHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DrawerHeader() from the server but DrawerHeader is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs <module evaluation>", "DrawerHeader");
const useDrawer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDrawer() from the server but useDrawer is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs <module evaluation>", "useDrawer");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Drawer",
    ()=>Drawer,
    "DrawerBody",
    ()=>DrawerBody,
    "DrawerContent",
    ()=>DrawerContent,
    "DrawerFooter",
    ()=>DrawerFooter,
    "DrawerHeader",
    ()=>DrawerHeader,
    "useDrawer",
    ()=>useDrawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Drawer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Drawer() from the server but Drawer is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs", "Drawer");
const DrawerBody = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DrawerBody() from the server but DrawerBody is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs", "DrawerBody");
const DrawerContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DrawerContent() from the server but DrawerContent is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs", "DrawerContent");
const DrawerFooter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DrawerFooter() from the server but DrawerFooter is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs", "DrawerFooter");
const DrawerHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call DrawerHeader() from the server but DrawerHeader is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs", "DrawerHeader");
const useDrawer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useDrawer() from the server but useDrawer is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs", "useDrawer");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$drawer$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$drawer$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/drawer/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$drawer$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "InputOtp",
    ()=>InputOtp,
    "REGEXP_ONLY_CHARS",
    ()=>REGEXP_ONLY_CHARS,
    "REGEXP_ONLY_DIGITS",
    ()=>REGEXP_ONLY_DIGITS,
    "REGEXP_ONLY_DIGITS_AND_CHARS",
    ()=>REGEXP_ONLY_DIGITS_AND_CHARS,
    "useInputOtp",
    ()=>useInputOtp
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const InputOtp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call InputOtp() from the server but InputOtp is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs <module evaluation>", "InputOtp");
const REGEXP_ONLY_CHARS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call REGEXP_ONLY_CHARS() from the server but REGEXP_ONLY_CHARS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs <module evaluation>", "REGEXP_ONLY_CHARS");
const REGEXP_ONLY_DIGITS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call REGEXP_ONLY_DIGITS() from the server but REGEXP_ONLY_DIGITS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs <module evaluation>", "REGEXP_ONLY_DIGITS");
const REGEXP_ONLY_DIGITS_AND_CHARS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call REGEXP_ONLY_DIGITS_AND_CHARS() from the server but REGEXP_ONLY_DIGITS_AND_CHARS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs <module evaluation>", "REGEXP_ONLY_DIGITS_AND_CHARS");
const useInputOtp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useInputOtp() from the server but useInputOtp is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs <module evaluation>", "useInputOtp");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "InputOtp",
    ()=>InputOtp,
    "REGEXP_ONLY_CHARS",
    ()=>REGEXP_ONLY_CHARS,
    "REGEXP_ONLY_DIGITS",
    ()=>REGEXP_ONLY_DIGITS,
    "REGEXP_ONLY_DIGITS_AND_CHARS",
    ()=>REGEXP_ONLY_DIGITS_AND_CHARS,
    "useInputOtp",
    ()=>useInputOtp
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const InputOtp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call InputOtp() from the server but InputOtp is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs", "InputOtp");
const REGEXP_ONLY_CHARS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call REGEXP_ONLY_CHARS() from the server but REGEXP_ONLY_CHARS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs", "REGEXP_ONLY_CHARS");
const REGEXP_ONLY_DIGITS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call REGEXP_ONLY_DIGITS() from the server but REGEXP_ONLY_DIGITS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs", "REGEXP_ONLY_DIGITS");
const REGEXP_ONLY_DIGITS_AND_CHARS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call REGEXP_ONLY_DIGITS_AND_CHARS() from the server but REGEXP_ONLY_DIGITS_AND_CHARS is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs", "REGEXP_ONLY_DIGITS_AND_CHARS");
const useInputOtp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useInputOtp() from the server but useInputOtp is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs", "useInputOtp");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$input$2d$otp$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$input$2d$otp$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/input-otp/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$input$2d$otp$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/number-input/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "NumberInput",
    ()=>NumberInput,
    "useNumberInput",
    ()=>useNumberInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const NumberInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NumberInput() from the server but NumberInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/number-input/dist/index.mjs <module evaluation>", "NumberInput");
const useNumberInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useNumberInput() from the server but useNumberInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/number-input/dist/index.mjs <module evaluation>", "useNumberInput");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/number-input/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "NumberInput",
    ()=>NumberInput,
    "useNumberInput",
    ()=>useNumberInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const NumberInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NumberInput() from the server but NumberInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/number-input/dist/index.mjs", "NumberInput");
const useNumberInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useNumberInput() from the server but useNumberInput is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/number-input/dist/index.mjs", "useNumberInput");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/number-input/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$number$2d$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/number-input/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$number$2d$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/number-input/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$number$2d$input$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Toast",
    ()=>Toast,
    "ToastProvider",
    ()=>ToastProvider,
    "addToast",
    ()=>addToast,
    "closeAll",
    ()=>closeAll,
    "closeToast",
    ()=>closeToast,
    "getToastQueue",
    ()=>getToastQueue,
    "isToastClosing",
    ()=>isToastClosing,
    "useToast",
    ()=>useToast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Toast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Toast() from the server but Toast is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs <module evaluation>", "Toast");
const ToastProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ToastProvider() from the server but ToastProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs <module evaluation>", "ToastProvider");
const addToast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call addToast() from the server but addToast is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs <module evaluation>", "addToast");
const closeAll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call closeAll() from the server but closeAll is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs <module evaluation>", "closeAll");
const closeToast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call closeToast() from the server but closeToast is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs <module evaluation>", "closeToast");
const getToastQueue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call getToastQueue() from the server but getToastQueue is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs <module evaluation>", "getToastQueue");
const isToastClosing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call isToastClosing() from the server but isToastClosing is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs <module evaluation>", "isToastClosing");
const useToast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useToast() from the server but useToast is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs <module evaluation>", "useToast");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Toast",
    ()=>Toast,
    "ToastProvider",
    ()=>ToastProvider,
    "addToast",
    ()=>addToast,
    "closeAll",
    ()=>closeAll,
    "closeToast",
    ()=>closeToast,
    "getToastQueue",
    ()=>getToastQueue,
    "isToastClosing",
    ()=>isToastClosing,
    "useToast",
    ()=>useToast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Toast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Toast() from the server but Toast is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs", "Toast");
const ToastProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ToastProvider() from the server but ToastProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs", "ToastProvider");
const addToast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call addToast() from the server but addToast is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs", "addToast");
const closeAll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call closeAll() from the server but closeAll is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs", "closeAll");
const closeToast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call closeToast() from the server but closeToast is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs", "closeToast");
const getToastQueue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call getToastQueue() from the server but getToastQueue is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs", "getToastQueue");
const isToastClosing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call isToastClosing() from the server but isToastClosing is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs", "isToastClosing");
const useToast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useToast() from the server but useToast is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs", "useToast");
}),
"[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/index.mjs [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$next$2d$admin$2d$dashboard$2f$node_modules$2f40$heroui$2f$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
];

//# sourceMappingURL=2e916_6a6339a3._.js.map