module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/data/sidebar/svgs.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccountsIcon",
    ()=>AccountsIcon,
    "AppealsIcon",
    ()=>AppealsIcon,
    "AssessmentIcon",
    ()=>AssessmentIcon,
    "BatchesIcon",
    ()=>BatchesIcon,
    "DashboardIcon",
    ()=>DashboardIcon,
    "NotificationBell",
    ()=>NotificationBell,
    "ResolutionIcon",
    ()=>ResolutionIcon,
    "SummaryIcon",
    ()=>SummaryIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function DashboardIcon() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                opacity: "0.4",
                d: "M15.5583 1.66666H13.975C12.1583 1.66666 11.2 2.62499 11.2 4.44166V6.02499C11.2 7.84166 12.1583 8.79999 13.975 8.79999H15.5583C17.375 8.79999 18.3333 7.84166 18.3333 6.02499V4.44166C18.3333 2.62499 17.375 1.66666 15.5583 1.66666Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 6,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                opacity: "0.4",
                d: "M6.03329 11.1917H4.44996C2.62496 11.1917 1.66663 12.15 1.66663 13.9667V15.55C1.66663 17.375 2.62496 18.3333 4.44163 18.3333H6.02496C7.84163 18.3333 8.79996 17.375 8.79996 15.5583V13.975C8.80829 12.15 7.84996 11.1917 6.03329 11.1917Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 7,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M5.24163 8.81666C7.21604 8.81666 8.81663 7.21607 8.81663 5.24166C8.81663 3.26724 7.21604 1.66666 5.24163 1.66666C3.26721 1.66666 1.66663 3.26724 1.66663 5.24166C1.66663 7.21607 3.26721 8.81666 5.24163 8.81666Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 8,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M14.7583 18.3333C16.7328 18.3333 18.3334 16.7327 18.3334 14.7583C18.3334 12.7839 16.7328 11.1833 14.7583 11.1833C12.7839 11.1833 11.1833 12.7839 11.1833 14.7583C11.1833 16.7327 12.7839 18.3333 14.7583 18.3333Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/data/sidebar/svgs.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
function AccountsIcon() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M10 10C12.3012 10 14.1667 8.13452 14.1667 5.83334C14.1667 3.53215 12.3012 1.66667 10 1.66667C7.69885 1.66667 5.83337 3.53215 5.83337 5.83334C5.83337 8.13452 7.69885 10 10 10Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                opacity: "0.4",
                d: "M9.99995 12.0833C5.82495 12.0833 2.42493 14.8833 2.42493 18.3333C2.42493 18.5667 2.60826 18.75 2.84159 18.75H17.1583C17.3916 18.75 17.575 18.5667 17.575 18.3333C17.575 14.8833 14.1749 12.0833 9.99995 12.0833Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M18.975 17.2333L18.3417 16.6C18.675 16.1 18.8667 15.5 18.8667 14.8583C18.8667 13.1 17.4417 11.675 15.6833 11.675C13.925 11.675 12.5 13.1 12.5 14.8583C12.5 16.6167 13.925 18.0417 15.6833 18.0417C16.325 18.0417 16.925 17.85 17.425 17.5167L18.0583 18.15C18.1833 18.275 18.35 18.3417 18.5166 18.3417C18.6833 18.3417 18.85 18.275 18.975 18.15C19.2333 17.8917 19.2333 17.4833 18.975 17.2333Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/data/sidebar/svgs.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
function BatchesIcon() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                opacity: "0.4",
                d: "M14.0167 1.66667H5.98339C4.20839 1.66667 2.76672 3.11667 2.76672 4.88334V16.625C2.76672 18.125 3.84172 18.7583 5.15839 18.0333L9.22506 15.775C9.65839 15.5333 10.3584 15.5333 10.7834 15.775L14.8501 18.0333C16.1667 18.7667 17.2417 18.1333 17.2417 16.625V4.88334C17.2334 3.11667 15.7917 1.66667 14.0167 1.66667Z",
                fill: "currentcolor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M10 8.56666C9.15 8.56666 8.3 8.41666 7.49167 8.125C7.16667 8.00833 7 7.65 7.11667 7.325C7.24167 7 7.6 6.83333 7.925 6.95C9.26667 7.43333 10.7417 7.43333 12.0833 6.95C12.4083 6.83333 12.7667 7 12.8833 7.325C13 7.65 12.8333 8.00833 12.5083 8.125C11.7 8.41666 10.85 8.56666 10 8.56666Z",
                fill: "currentcolor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/data/sidebar/svgs.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
function ResolutionIcon() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M15.919 6.65883C15.919 6.70027 15.9025 6.74001 15.8732 6.76931C15.8439 6.79861 15.8041 6.81508 15.7627 6.81508H13.2483C12.4167 6.81508 11.664 7.15824 11.1233 7.70992V11.1117C11.3879 11.1805 11.6455 11.2737 11.8929 11.39V9.79207C11.8929 9.04472 12.5009 8.43672 13.2483 8.43672H15.7627C15.8041 8.43672 15.8439 8.45318 15.8732 8.48248C15.9025 8.51178 15.919 8.55153 15.919 8.59297V9.84738L19.5447 7.6259L15.919 5.40414V6.65883ZM8.87669 11.1117V7.70992C8.33599 7.15824 7.58333 6.81508 6.75165 6.81508H4.23728C4.19584 6.81508 4.15609 6.79861 4.12679 6.76931C4.09749 6.74001 4.08103 6.70027 4.08103 6.65883V5.4041L0.455322 7.62586L4.08103 9.84734V8.59297C4.08103 8.55153 4.09749 8.51178 4.12679 8.48248C4.15609 8.45318 4.19584 8.43672 4.23728 8.43672H6.75165C7.49903 8.43672 8.10708 9.04472 8.10708 9.79207V11.3901C8.35239 11.2748 8.60966 11.1811 8.87669 11.1117Z",
                fill: "currentcolor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M9.18922 11.0425C9.45223 10.9941 9.7232 10.9685 10 10.9685C10.2769 10.9685 10.5478 10.9941 10.8109 11.0425V4.33394C10.8109 4.2925 10.8273 4.25276 10.8566 4.22345C10.8859 4.19415 10.9257 4.17769 10.9671 4.17769H12.2216L10 0.551987L7.77832 4.17769H9.03297C9.07441 4.17769 9.11415 4.19415 9.14345 4.22345C9.17276 4.25276 9.18922 4.2925 9.18922 4.33394V11.0425Z",
                fill: "#8095A7"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M9.99998 11.2811C7.70896 11.2811 5.84509 13.1449 5.84509 15.4359C5.84509 17.7269 7.70896 19.5908 9.99998 19.5908C12.291 19.5908 14.1549 17.7269 14.1549 15.4359C14.1549 13.1449 12.291 11.2811 9.99998 11.2811ZM9.99998 18.7621C9.68279 18.7621 9.42474 18.5041 9.42474 18.1869C9.42474 17.8698 9.68279 17.6117 9.99998 17.6117C10.3172 17.6117 10.5752 17.8697 10.5752 18.1869C10.5752 18.5041 10.3172 18.7621 9.99998 18.7621ZM10.673 15.9184C10.6146 15.9407 10.587 15.9609 10.5752 15.9718V16.9301C10.5752 17.2473 10.3172 17.5053 9.99998 17.5053C9.68279 17.5053 9.42474 17.2473 9.42474 16.9301V15.9805C9.40498 15.6098 9.61244 15.0915 10.2634 14.8435C10.5974 14.7162 10.8133 14.4139 10.8133 14.0734C10.8133 13.625 10.4485 13.2602 9.99998 13.2602C9.55154 13.2602 9.18669 13.625 9.18669 14.0734C9.18669 14.3906 8.92869 14.6486 8.61154 14.6486C8.29439 14.6486 8.03634 14.3906 8.03634 14.0734C8.03634 12.9907 8.9172 12.1098 9.99998 12.1098C11.0827 12.1098 11.9636 12.9907 11.9636 14.0734C11.9636 14.8954 11.457 15.6196 10.673 15.9184Z",
                fill: "currentcolor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M10 12.4223C9.08958 12.4223 8.34888 13.163 8.34888 14.0734C8.34888 14.2182 8.46673 14.3361 8.61157 14.3361C8.75642 14.3361 8.87423 14.2182 8.87423 14.0734C8.87423 13.4527 9.37927 12.9477 10 12.9477C10.6208 12.9477 11.1258 13.4527 11.1258 14.0734C11.1258 14.5447 10.831 14.9616 10.3747 15.1355C9.72196 15.3842 9.73353 15.908 9.737 15.967C9.73716 15.97 9.73728 15.973 9.73728 15.9761V16.9301C9.73736 16.9998 9.76507 17.0665 9.81432 17.1158C9.86358 17.165 9.93036 17.1927 10 17.1928C10.0697 17.1927 10.1364 17.165 10.1857 17.1158C10.2349 17.0665 10.2626 16.9998 10.2627 16.9301V15.9606C10.2627 15.9563 10.2626 15.952 10.2624 15.9477C10.262 15.939 10.2623 15.9303 10.2633 15.9217C10.2716 15.8507 10.3215 15.7179 10.5618 15.6264C11.2235 15.3742 11.6511 14.7646 11.6511 14.0734C11.6511 13.163 10.9104 12.4223 10 12.4223ZM10 17.9242C9.85517 17.9242 9.73728 18.0421 9.73728 18.1869C9.73728 18.3318 9.85513 18.4496 10 18.4496C10.1449 18.4496 10.2627 18.3318 10.2627 18.1869C10.2627 18.0421 10.1449 17.9242 10 17.9242Z",
                fill: "#8095A7"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M19.9254 7.49269L15.8444 4.99191C15.8207 4.97741 15.7936 4.96948 15.7658 4.96894C15.738 4.9684 15.7106 4.97527 15.6864 4.98884C15.6622 5.00241 15.642 5.0222 15.628 5.04616C15.6139 5.07012 15.6065 5.09738 15.6065 5.12515V6.50261H13.2484C12.4388 6.50261 11.6971 6.79718 11.1234 7.28394V4.49019H12.501C12.5866 4.48863 12.6576 4.42035 12.6576 4.33394C12.6576 4.29883 12.646 4.2664 12.6264 4.24027L10.1333 0.171287C10.1193 0.148484 10.0997 0.129648 10.0764 0.11658C10.0531 0.103512 10.0268 0.0966492 10 0.0966492C9.97329 0.0966492 9.947 0.103512 9.92367 0.11658C9.90034 0.129648 9.88076 0.148484 9.86679 0.171287L7.36609 4.25234C7.35157 4.27602 7.34363 4.30314 7.34309 4.33091C7.34254 4.35868 7.34941 4.3861 7.36298 4.41033C7.37656 4.43456 7.39635 4.45473 7.42031 4.46877C7.44428 4.48281 7.47155 4.4902 7.49933 4.49019H8.87671V7.28394C8.303 6.79715 7.56128 6.50261 6.75167 6.50261H4.39355V5.12515C4.39355 5.09738 4.38614 5.07012 4.3721 5.04616C4.35806 5.0222 4.33789 5.00241 4.31366 4.98884C4.28943 4.97527 4.26203 4.9684 4.23426 4.96894C4.2065 4.96948 4.17938 4.97741 4.1557 4.99191L0.0746415 7.49269C0.0518386 7.50666 0.033001 7.52624 0.019932 7.54956C0.00686298 7.57289 0 7.59918 0 7.62592C0 7.65265 0.00686298 7.67894 0.019932 7.70227C0.033001 7.7256 0.0518386 7.74518 0.0746415 7.75914L4.1557 10.2596C4.17938 10.2741 4.2065 10.2821 4.23427 10.2826C4.26204 10.2832 4.28945 10.2763 4.31368 10.2627C4.33791 10.2491 4.35809 10.2293 4.37213 10.2054C4.38616 10.1814 4.39356 10.1541 4.39355 10.1264V8.74922H6.75167C7.32675 8.74922 7.7946 9.21703 7.7946 9.79207V11.5521C6.44476 12.3216 5.53261 13.7741 5.53261 15.4359C5.53261 17.8993 7.53667 19.9033 9.99999 19.9033C12.4633 19.9033 14.4674 17.8993 14.4674 15.4359C14.4674 13.7741 13.5552 12.3215 12.2054 11.552V9.79203C12.2054 9.21699 12.6732 8.74918 13.2483 8.74918H15.6064V10.1263C15.6064 10.1541 15.6138 10.1814 15.6279 10.2053C15.6419 10.2293 15.6621 10.2491 15.6863 10.2626C15.7106 10.2762 15.738 10.2831 15.7657 10.2825C15.7935 10.282 15.8206 10.2741 15.8443 10.2596L19.9253 7.7591C19.9481 7.74513 19.967 7.72556 19.98 7.70224C19.9931 7.67892 20 7.65265 20 7.62592C20 7.59919 19.9931 7.57291 19.9801 7.54958C19.967 7.52626 19.9482 7.50667 19.9254 7.49269ZM15.919 9.84738V8.59297C15.919 8.55153 15.9025 8.51178 15.8732 8.48248C15.8439 8.45318 15.8042 8.43672 15.7627 8.43672H13.2484C12.501 8.43672 11.8929 9.04472 11.8929 9.79207V11.39C11.6455 11.2737 11.3879 11.1805 11.1234 11.1117V7.70992C11.664 7.15824 12.4167 6.81508 13.2484 6.81508H15.7627C15.8042 6.81508 15.8439 6.79861 15.8732 6.76931C15.9025 6.74001 15.919 6.70027 15.919 6.65883V5.4041L19.5447 7.62586L15.919 9.84738ZM10 19.5908C7.70902 19.5908 5.84515 17.727 5.84515 15.4359C5.84515 13.1449 7.70902 11.2811 10 11.2811C12.291 11.2811 14.1549 13.1449 14.1549 15.4359C14.1549 17.727 12.291 19.5908 10 19.5908ZM6.75167 8.43672H4.2373C4.19586 8.43672 4.15612 8.45318 4.12681 8.48248C4.09751 8.51178 4.08105 8.55153 4.08105 8.59297V9.84738L0.455345 7.6259L4.08105 5.40414V6.65886C4.08105 6.7003 4.09751 6.74005 4.12681 6.76935C4.15612 6.79865 4.19586 6.81511 4.2373 6.81511H6.75167C7.58335 6.81511 8.33601 7.15828 8.87671 7.70996V11.1117C8.61215 11.1806 8.35451 11.2738 8.1071 11.3901V9.79207C8.10714 9.04472 7.4991 8.43672 6.75167 8.43672ZM9.18921 4.33394C9.18921 4.2925 9.17275 4.25276 9.14345 4.22346C9.11415 4.19416 9.0744 4.17769 9.03296 4.17769H7.77831L10 0.55199L12.2216 4.17769H10.9671C10.9257 4.17769 10.8859 4.19416 10.8566 4.22346C10.8273 4.25276 10.8109 4.2925 10.8109 4.33394V11.0425C10.5478 10.9941 10.2769 10.9686 10 10.9686C9.7232 10.9686 9.45226 10.9941 9.18921 11.0425V4.33394Z",
                fill: "#8095A7"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 49,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M10 12.1098C8.91728 12.1098 8.03638 12.9907 8.03638 14.0734C8.03638 14.3906 8.29438 14.6486 8.61157 14.6486C8.92876 14.6486 9.18673 14.3906 9.18673 14.0734C9.18673 13.625 9.55157 13.2602 10 13.2602C10.4484 13.2602 10.8133 13.625 10.8133 14.0734C10.8133 14.4139 10.5975 14.7162 10.2634 14.8435C9.61247 15.0915 9.40501 15.6098 9.42478 15.9805V16.9301C9.42478 17.2473 9.68282 17.5053 10 17.5053C10.3172 17.5053 10.5752 17.2473 10.5752 16.9301V15.9718C10.587 15.9609 10.6147 15.9407 10.6731 15.9184C11.457 15.6196 11.9636 14.8954 11.9636 14.0734C11.9636 12.9907 11.0827 12.1098 10 12.1098ZM11.6511 14.0734C11.6511 14.7646 11.2235 15.3742 10.5618 15.6264C10.3215 15.7179 10.2716 15.8507 10.2633 15.9217C10.2623 15.9303 10.262 15.939 10.2624 15.9477C10.2626 15.952 10.2627 15.9563 10.2627 15.9606V16.9301C10.2627 17.075 10.1449 17.1928 10 17.1928C9.85517 17.1928 9.73728 17.075 9.73728 16.9301V15.9761C9.73728 15.973 9.7372 15.97 9.737 15.967C9.73353 15.908 9.72196 15.3842 10.3747 15.1355C10.831 14.9616 11.1258 14.5446 11.1258 14.0734C11.1258 13.4527 10.6208 12.9477 10 12.9477C9.37927 12.9477 8.87423 13.4527 8.87423 14.0734C8.87415 14.143 8.84645 14.2098 8.79721 14.259C8.74797 14.3083 8.68121 14.336 8.61157 14.3361C8.54193 14.336 8.47516 14.3083 8.42591 14.2591C8.37666 14.2098 8.34896 14.143 8.34888 14.0734C8.34888 13.163 9.08954 12.4223 10 12.4223C10.9105 12.4223 11.6511 13.163 11.6511 14.0734ZM10 17.6117C9.68282 17.6117 9.42478 17.8697 9.42478 18.1869C9.42478 18.5041 9.68282 18.7621 10 18.7621C10.3172 18.7621 10.5752 18.5041 10.5752 18.1869C10.5752 17.8697 10.3172 17.6117 10 17.6117ZM10 18.4496C9.85517 18.4496 9.73728 18.3318 9.73728 18.187C9.73728 18.0421 9.85513 17.9243 10 17.9243C10.1449 17.9243 10.2627 18.0421 10.2627 18.187C10.2627 18.3318 10.1449 18.4496 10 18.4496Z",
                fill: "#8095A7"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/data/sidebar/svgs.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, this);
}
function AssessmentIcon() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M20 8.25V18C20 21 18.21 22 16 22H8C5.79 22 4 21 4 18V8.25C4 5 5.79 4.25 8 4.25C8 4.87 8.24997 5.43 8.65997 5.84C9.06997 6.25 9.63 6.5 10.25 6.5H13.75C14.99 6.5 16 5.49 16 4.25C18.21 4.25 20 5 20 8.25Z",
                fill: "#8095A7",
                stroke: "#8095A7",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M16 4.25C16 5.49 14.99 6.5 13.75 6.5H10.25C9.63 6.5 9.06997 6.25 8.65997 5.84C8.24997 5.43 8 4.87 8 4.25C8 3.01 9.01 2 10.25 2H13.75C14.37 2 14.93 2.25 15.34 2.66C15.75 3.07 16 3.63 16 4.25Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M8 13H12",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M8 17H16",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/data/sidebar/svgs.tsx",
        lineNumber: 62,
        columnNumber: 5
    }, this);
}
function AppealsIcon() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                opacity: "0.4",
                d: "M14.5167 1.15001C14.3417 1.03335 14.125 1.00833 13.9333 1.08333C12.7417 1.55833 11.425 1.55833 10.2333 1.08333C10.0417 1.00833 9.825 1.03335 9.65 1.15001C9.475 1.26668 9.375 1.45834 9.375 1.66668V4.16668V6.66668C9.375 7.00834 9.65833 7.29168 10 7.29168C10.3417 7.29168 10.625 7.00834 10.625 6.66668V5.01669C11.1083 5.13336 11.5917 5.2 12.0833 5.2C12.8667 5.2 13.65 5.05002 14.4 4.75002C14.6333 4.65835 14.7917 4.42501 14.7917 4.16668V1.66668C14.7917 1.45834 14.6917 1.26668 14.5167 1.15001Z",
                fill: "currentcolor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M18.3333 17.7083H17.2916V9.16667C17.2916 7.15 16.1833 6.04167 14.1666 6.04167H5.83329C3.81663 6.04167 2.70829 7.15 2.70829 9.16667V17.7083H1.66663C1.32496 17.7083 1.04163 17.9917 1.04163 18.3333C1.04163 18.675 1.32496 18.9583 1.66663 18.9583H3.33329H16.6666H18.3333C18.675 18.9583 18.9583 18.675 18.9583 18.3333C18.9583 17.9917 18.675 17.7083 18.3333 17.7083ZM16.0416 10.625V17.7083H13.95V10.625H16.0416ZM9.36663 17.7083H7.28329V10.625H9.36663V17.7083ZM10.6166 10.625H12.7V17.7083H10.6166V10.625ZM3.95829 10.625H6.03329V17.7083H3.95829V10.625Z",
                fill: "currentcolor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/data/sidebar/svgs.tsx",
        lineNumber: 73,
        columnNumber: 5
    }, this);
}
function SummaryIcon() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z",
                fill: "#8095A7",
                stroke: "#8095A7",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 83,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M12.37 8.88H17.62",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 84,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M6.38 8.88L7.13 9.63L9.38 7.38",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M12.37 15.88H17.62",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 86,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M6.38 15.88L7.13 16.63L9.38 14.38",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/data/sidebar/svgs.tsx",
        lineNumber: 82,
        columnNumber: 5
    }, this);
}
function NotificationBell() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M20.4 16.33C20.12 17.08 19.53 17.65 18.76 17.91C17.68 18.27 16.57 18.54 15.45 18.73C15.34 18.75 15.23 18.77 15.12 18.78C14.94 18.81 14.76 18.83 14.58 18.85C14.36 18.88 14.13 18.9 13.9 18.92C13.27 18.97 12.65 19 12.02 19C11.38 19 10.74 18.97 10.11 18.91C9.84 18.89 9.58 18.86 9.32 18.82C9.17 18.8 9.02 18.78 8.88 18.76C8.77 18.74 8.66 18.73 8.55 18.71C7.44 18.53 6.34 18.26 5.27 17.9C4.47 17.63 3.86 17.06 3.59 16.33C3.32 15.61 3.42 14.77 3.85 14.05L4.98 12.17C5.22 11.76 5.44 10.97 5.44 10.49V8.62999C5.44 4.99999 8.39 2.04999 12.02 2.04999C15.64 2.04999 18.59 4.99999 18.59 8.62999V10.49C18.59 10.97 18.81 11.76 19.06 12.17L20.19 14.05C20.6 14.75 20.68 15.57 20.4 16.33Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 95,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M11.76 10.62C11.34 10.62 11 10.28 11 9.86V6.76C11 6.34 11.34 6 11.76 6C12.18 6 12.52 6.34 12.52 6.76V9.86C12.51 10.28 12.17 10.62 11.76 10.62Z",
                fill: "white"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 99,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M14.83 20.01C14.41 21.17 13.3 22 12 22C11.21 22 10.43 21.68 9.88 21.11C9.56 20.81 9.32 20.41 9.18 20C9.31 20.02 9.44 20.03 9.58 20.05C9.81 20.08 10.05 20.11 10.29 20.13C10.86 20.18 11.44 20.21 12.02 20.21C12.59 20.21 13.16 20.18 13.72 20.13C13.93 20.11 14.14 20.1 14.34 20.07C14.5 20.05 14.66 20.03 14.83 20.01Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/data/sidebar/svgs.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/data/sidebar/svgs.tsx",
        lineNumber: 94,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/data/sidebar/sidebarData.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sidebarItems",
    ()=>sidebarItems
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$svgs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/sidebar/svgs.tsx [app-ssr] (ecmascript)");
;
const sidebarItems = [
    {
        label: "Dashboard",
        href: "/",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$svgs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DashboardIcon"]
    },
    {
        label: "Accounts",
        href: "/accounts",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$svgs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AccountsIcon"]
    },
    {
        label: "Batches",
        href: "/batches",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$svgs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BatchesIcon"]
    },
    {
        label: "Resolution",
        href: "/resolution",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$svgs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ResolutionIcon"]
    },
    {
        label: "Assessments",
        href: "/assessments",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$svgs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AssessmentIcon"]
    },
    {
        label: "Appeal Letter",
        href: "/appeal-letter",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$svgs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AppealsIcon"]
    },
    {
        label: "Summary",
        href: "/summary",
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$svgs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SummaryIcon"]
    }
];
}),
"[project]/src/app/components/DashboardShell.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DashboardShell
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/button/dist/chunk-WBUKVQRU.mjs [app-ssr] (ecmascript) <export button_default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$XHRYXXZA$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__dropdown_default__as__Dropdown$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/dropdown/dist/chunk-XHRYXXZA.mjs [app-ssr] (ecmascript) <export dropdown_default as Dropdown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$chunk$2d$BIY4SM4Z$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__menu_item_base_default__as__DropdownItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/menu/dist/chunk-BIY4SM4Z.mjs [app-ssr] (ecmascript) <export menu_item_base_default as DropdownItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$UIQ4674R$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__dropdown_menu_default__as__DropdownMenu$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/dropdown/dist/chunk-UIQ4674R.mjs [app-ssr] (ecmascript) <export dropdown_menu_default as DropdownMenu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$4LJ2IKXJ$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__dropdown_trigger_default__as__DropdownTrigger$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/dropdown/dist/chunk-4LJ2IKXJ.mjs [app-ssr] (ecmascript) <export dropdown_trigger_default as DropdownTrigger>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$input$2f$dist$2f$chunk$2d$SSA7SXE4$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__input_default__as__Input$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/input/dist/chunk-SSA7SXE4.mjs [app-ssr] (ecmascript) <export input_default as Input>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$user$2f$dist$2f$chunk$2d$S574QCAN$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__user_default__as__User$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/user/dist/chunk-S574QCAN.mjs [app-ssr] (ecmascript) <export user_default as User>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$sidebarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/sidebar/sidebarData.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fa/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$tb$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/tb/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa6$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fa6/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$svgs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/sidebar/svgs.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$lu$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/lu/index.mjs [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
function DashboardShell({ children }) {
    const [isSidebarOpen, setIsSidebarOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCollapsed, setIsCollapsed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex bg-background text-foreground",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "main-header flex items-center justify-between px-4 py-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3 w-full",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__["Button"], {
                                "aria-label": "Toggle sidebar",
                                isIconOnly: true,
                                variant: "flat",
                                size: "sm",
                                className: "lg:hidden",
                                onPress: ()=>setIsSidebarOpen((v)=>!v),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiMenu"], {
                                    size: 18
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/DashboardShell.tsx",
                                    lineNumber: 26,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                lineNumber: 25,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between gap-2 w-100",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    src: "/logo.png",
                                    alt: "Logo",
                                    width: 150,
                                    height: 30,
                                    priority: true
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/DashboardShell.tsx",
                                    lineNumber: 29,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                lineNumber: 28,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/components/DashboardShell.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center w-full hidden md:flex",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$input$2f$dist$2f$chunk$2d$SSA7SXE4$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__input_default__as__Input$3e$__["Input"], {
                                variant: "bordered",
                                className: "input shadow-none me-5",
                                placeholder: "",
                                startContent: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$lu$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LuSearch"], {
                                    className: "text-default-400 pointer-events-none shrink-0"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/DashboardShell.tsx",
                                    lineNumber: 33,
                                    columnNumber: 101
                                }, void 0),
                                type: "text"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                lineNumber: 33,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$XHRYXXZA$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__dropdown_default__as__Dropdown$3e$__["Dropdown"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$4LJ2IKXJ$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__dropdown_trigger_default__as__DropdownTrigger$3e$__["DropdownTrigger"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__["Button"], {
                                            isIconOnly: true,
                                            className: "profile-dd",
                                            variant: "light",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$user$2f$dist$2f$chunk$2d$S574QCAN$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__user_default__as__User$3e$__["User"], {
                                                avatarProps: {
                                                    src: "https://i.pravatar.cc/150?u=a04258114e29026702d"
                                                },
                                                description: "",
                                                name: ""
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                                lineNumber: 37,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/components/DashboardShell.tsx",
                                            lineNumber: 36,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/DashboardShell.tsx",
                                        lineNumber: 35,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$UIQ4674R$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__dropdown_menu_default__as__DropdownMenu$3e$__["DropdownMenu"], {
                                        "aria-label": "Static Actions",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$chunk$2d$BIY4SM4Z$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__menu_item_base_default__as__DropdownItem$3e$__["DropdownItem"], {
                                                children: "New file"
                                            }, "new", false, {
                                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                                lineNumber: 47,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$chunk$2d$BIY4SM4Z$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__menu_item_base_default__as__DropdownItem$3e$__["DropdownItem"], {
                                                children: "Copy link"
                                            }, "copy", false, {
                                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                                lineNumber: 48,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$chunk$2d$BIY4SM4Z$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__menu_item_base_default__as__DropdownItem$3e$__["DropdownItem"], {
                                                children: "Edit file"
                                            }, "edit", false, {
                                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                                lineNumber: 49,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$chunk$2d$BIY4SM4Z$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__menu_item_base_default__as__DropdownItem$3e$__["DropdownItem"], {
                                                className: "text-danger",
                                                color: "danger",
                                                children: "Delete file"
                                            }, "delete", false, {
                                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                                lineNumber: 50,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/DashboardShell.tsx",
                                        lineNumber: 46,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                lineNumber: 34,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-6 border-l border-gray-300 mx-3"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                lineNumber: 55,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$svgs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NotificationBell"], {}, void 0, false, {
                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                lineNumber: 56,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-6 border-l border-gray-300 mx-3"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                lineNumber: 57,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$tb$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TbGridDots"], {
                                size: 25
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                lineNumber: 58,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/components/DashboardShell.tsx",
                        lineNumber: 32,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/components/DashboardShell.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            isSidebarOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "fixed inset-0 z-20 bg-black/40 lg:hidden",
                "aria-label": "Close sidebar overlay",
                onClick: ()=>setIsSidebarOpen(false)
            }, void 0, false, {
                fileName: "[project]/src/app/components/DashboardShell.tsx",
                lineNumber: 62,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                className: `sidebar ${isSidebarOpen ? "" : "closed"} ${isCollapsed ? "collapsed" : "expanded"}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                    className: "space-y-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__["Button"], {
                            className: "sidebar-collapse-btn hidden lg:block",
                            "aria-label": "Collapse sidebar",
                            isIconOnly: true,
                            variant: "flat",
                            size: "sm",
                            onPress: ()=>setIsCollapsed((v)=>!v),
                            children: isCollapsed ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa6$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FaChevronRight"], {
                                size: 16
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                lineNumber: 67,
                                columnNumber: 28
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FaChevronLeft"], {
                                size: 16
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                lineNumber: 67,
                                columnNumber: 59
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/DashboardShell.tsx",
                            lineNumber: 66,
                            columnNumber: 11
                        }, this),
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$sidebar$2f$sidebarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sidebarItems"].map(({ href, label, Icon })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: href,
                                className: "sidebar-link" + (pathname === href ? " active" : ""),
                                onClick: ()=>setIsSidebarOpen(false),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                        size: 18
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/DashboardShell.tsx",
                                        lineNumber: 71,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: isCollapsed ? "hidden lg:hidden" : "",
                                        children: label
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/DashboardShell.tsx",
                                        lineNumber: 72,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, href, true, {
                                fileName: "[project]/src/app/components/DashboardShell.tsx",
                                lineNumber: 70,
                                columnNumber: 13
                            }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/DashboardShell.tsx",
                    lineNumber: 65,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/components/DashboardShell.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 flex flex-col main-content",
                suppressHydrationWarning: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                    children: children
                }, void 0, false, {
                    fileName: "[project]/src/app/components/DashboardShell.tsx",
                    lineNumber: 79,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/components/DashboardShell.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/DashboardShell.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/store/appealsApi.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "appealsApi",
    ()=>appealsApi,
    "useAddAppealMutation",
    ()=>useAddAppealMutation,
    "useDeleteAppealMutation",
    ()=>useDeleteAppealMutation,
    "useGetAppealQuery",
    ()=>useGetAppealQuery,
    "useGetAppealsQuery",
    ()=>useGetAppealsQuery,
    "useUpdateAppealMutation",
    ()=>useUpdateAppealMutation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$query$2f$react$2f$rtk$2d$query$2d$react$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/query/react/rtk-query-react.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$query$2f$rtk$2d$query$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/query/rtk-query.modern.mjs [app-ssr] (ecmascript)");
;
const baseUrl = ("TURBOPACK compile-time value", "http://localhost:8001/");
const appealsApi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$query$2f$react$2f$rtk$2d$query$2d$react$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createApi"])({
    reducerPath: 'appealsApi',
    baseQuery: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$query$2f$rtk$2d$query$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchBaseQuery"])({
        baseUrl: baseUrl
    }),
    tagTypes: [
        'Appeals'
    ],
    endpoints: (builder)=>({
            getAppeals: builder.query({
                query: ()=>'appeals',
                providesTags: [
                    'Appeals'
                ]
            }),
            getAppeal: builder.query({
                query: (id)=>`appeals/${id}`,
                providesTags: (result, error, id)=>[
                        {
                            type: 'Appeals',
                            id
                        }
                    ]
            }),
            addAppeal: builder.mutation({
                query: (newAppeal)=>({
                        url: 'appeals',
                        method: 'POST',
                        body: newAppeal
                    }),
                invalidatesTags: [
                    'Appeals'
                ]
            }),
            updateAppeal: builder.mutation({
                query: ({ id, ...patch })=>({
                        url: `appeals/${id}`,
                        method: 'PUT',
                        body: patch
                    }),
                invalidatesTags: [
                    'Appeals'
                ]
            }),
            deleteAppeal: builder.mutation({
                query: (id)=>({
                        url: `appeals/${id}`,
                        method: 'DELETE'
                    }),
                invalidatesTags: [
                    'Appeals'
                ]
            })
        })
});
const { useGetAppealsQuery, useGetAppealQuery, useAddAppealMutation, useUpdateAppealMutation, useDeleteAppealMutation } = appealsApi;
}),
"[project]/src/store/calendarApi.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calendarApi",
    ()=>calendarApi,
    "useAddEventMutation",
    ()=>useAddEventMutation,
    "useDeleteEventMutation",
    ()=>useDeleteEventMutation,
    "useGetEventQuery",
    ()=>useGetEventQuery,
    "useGetEventsQuery",
    ()=>useGetEventsQuery,
    "useUpdateEventMutation",
    ()=>useUpdateEventMutation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$query$2f$react$2f$rtk$2d$query$2d$react$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/query/react/rtk-query-react.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$query$2f$rtk$2d$query$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/query/rtk-query.modern.mjs [app-ssr] (ecmascript)");
;
const baseUrl = ("TURBOPACK compile-time value", "http://localhost:8001/");
const calendarApi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$query$2f$react$2f$rtk$2d$query$2d$react$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createApi"])({
    reducerPath: 'calendarApi',
    baseQuery: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$query$2f$rtk$2d$query$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchBaseQuery"])({
        baseUrl: baseUrl
    }),
    tagTypes: [
        'Events'
    ],
    endpoints: (builder)=>({
            getEvents: builder.query({
                query: ()=>'events',
                providesTags: [
                    'Events'
                ]
            }),
            getEvent: builder.query({
                query: (id)=>`events/${id}`,
                providesTags: (result, error, id)=>[
                        {
                            type: 'Events',
                            id
                        }
                    ]
            }),
            addEvent: builder.mutation({
                query: (newEvent)=>({
                        url: 'events',
                        method: 'POST',
                        body: newEvent
                    }),
                invalidatesTags: [
                    'Events'
                ]
            }),
            updateEvent: builder.mutation({
                query: ({ id, ...patch })=>({
                        url: `events/${id}`,
                        method: 'PUT',
                        body: patch
                    }),
                invalidatesTags: [
                    'Events'
                ]
            }),
            deleteEvent: builder.mutation({
                query: (id)=>({
                        url: `events/${id}`,
                        method: 'DELETE'
                    }),
                invalidatesTags: [
                    'Events'
                ]
            })
        })
});
const { useGetEventsQuery, useGetEventQuery, useAddEventMutation, useUpdateEventMutation, useDeleteEventMutation } = calendarApi;
}),
"[project]/src/store/index.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "store",
    ()=>store
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$appealsApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/appealsApi.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$calendarApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/calendarApi.ts [app-ssr] (ecmascript)");
;
;
;
const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["configureStore"])({
    reducer: {
        [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$appealsApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["appealsApi"].reducerPath]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$appealsApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["appealsApi"].reducer,
        [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$calendarApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["calendarApi"].reducerPath]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$calendarApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["calendarApi"].reducer
    },
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware().concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$appealsApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["appealsApi"].middleware, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$calendarApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["calendarApi"].middleware)
});
}),
"[project]/src/app/providers.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Providers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
// import { ThemeProvider } from "next-themes";
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$system$2f$dist$2f$chunk$2d$3KFOFPK7$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@heroui/system/dist/chunk-3KFOFPK7.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/index.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function Providers({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Provider"], {
        store: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["store"],
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$system$2f$dist$2f$chunk$2d$3KFOFPK7$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HeroUIProvider"], {
            children: children
        }, void 0, false, {
            fileName: "[project]/src/app/providers.tsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/providers.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__6413671f._.js.map