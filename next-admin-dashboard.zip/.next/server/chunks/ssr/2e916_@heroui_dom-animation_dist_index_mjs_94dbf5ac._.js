module.exports = [
"[project]/next-admin-dashboard/node_modules/@heroui/dom-animation/dist/index.mjs [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/2e916_a67ffc47._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/next-admin-dashboard/node_modules/@heroui/dom-animation/dist/index.mjs [app-ssr] (ecmascript)");
    });
});
}),
];