module.exports = [
"[project]/next-admin-dashboard/node_modules/@heroui/dom-animation/dist/index.mjs [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/2e916_@heroui_dom-animation_dist_index_mjs_9d1bbd70._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/next-admin-dashboard/node_modules/@heroui/dom-animation/dist/index.mjs [app-ssr] (ecmascript)");
    });
});
}),
"[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/src-UW24ZMRV.mjs [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/2e916_@heroui_toast_dist_src-UW24ZMRV_mjs_ea3701ba._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/next-admin-dashboard/node_modules/@heroui/toast/dist/src-UW24ZMRV.mjs [app-ssr] (ecmascript)");
    });
});
}),
"[project]/next-admin-dashboard/node_modules/framer-motion/dist/es/index.mjs [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/2e916_4a981312._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/next-admin-dashboard/node_modules/framer-motion/dist/es/index.mjs [app-ssr] (ecmascript)");
    });
});
}),
];